"""Finite matched-wide SQTT diagnosis; reuses frozen capture/analysis code."""
from pathlib import Path
import copy,csv,fcntl,hashlib,json,re,shutil,sys,tarfile,time
D=Path(__file__).resolve().parent;ROOT=D.parents[1]
sys.path.insert(0,str(ROOT))
import plan,runtime as r,k64_profiles_campaign as capture

class Identities:
    @staticmethod
    def kernel_identity(case):
        assert case['M']==64 and case['expected'] in [6027,6029]
        name='DecodeNnCooperativeWidePhaseKernel' if case['expected']==6027 else 'DecodeNnCooperativeK64WideKernel'
        return name,name+'<4>'

def configure():
    capture.RULE=D/'capture_rule.json'
    capture.REGPLAN=D/'capture_plan.json'
    capture.CAPTURES=D/'captures.json'
    capture.ATTEMPTS=D/'attempts.json'
    capture.ANALYSIS=D/'analysis'
    capture.identities=Identities

def freeze():
    assert r.read(ROOT/'post_k64_build_status.json')['state']=='complete'
    assert r.read(ROOT/'k64_controller_status.json')['state']=='complete'
    assert (ROOT/'profile_delivery_batch10.json').is_file()
    registered=r.read(D/'registered_profile_plan.json')
    rows=r.read(ROOT/'k64_discovery_results.json');assert len(rows)==46
    row=next(x for x in rows if x['pair']=='k64_id805_wide')
    digest=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert digest==registered['pair_row_sha256'] and row==registered['formal_discovery_row']
    assert time.time()+120<r.read(ROOT/'session.json')['gpu_deadline_epoch']
    site=r.Site(ROOT);assert row['epoch']==site.epoch()
    assert row['binary_sha256']==site.manifest['benchmark_sha256']
    pair=copy.deepcopy(registered['pair'])
    pair.update(formal_base_ms=row['CK_base_ms'],formal_candidate_ms=row['CK_candidate_ms'],formal_delta_pct=row['delta_pct'],prior_accuracy_keys=row['keys'][:2],high_cv=row['high_cv'])
    rule=r.read(ROOT/'k64_profile_rule.json')
    rule.update(target_cu_order=registered['target_cu_attempts'],fixed_ids=[805],supplemental_direct_control=True)
    r.write(capture.RULE,rule)
    proposed=dict(epoch=site.epoch(),binary_sha256=site.manifest['benchmark_sha256'],pairs=[pair],registered_plan_sha256=plan.sha(D/'registered_profile_plan.json'),selection_is_not_final_adoption=True)
    proposed['sha256']=plan.digest(proposed);r.write(capture.REGPLAN,proposed)
    parent=copy.deepcopy(site.manifest);parent.pop('plan_sha256',None)
    parent['k64_wide_control_profile_plan_sha256']=proposed['sha256']
    for p in [Path(__file__),D/'registered_profile_plan.json',capture.RULE,capture.REGPLAN]:
        parent['runner_sha256'][str(p.relative_to(ROOT))]=plan.sha(p)
    parent['plan_sha256']=plan.digest(parent)
    r.write(ROOT/'manifests'/(parent['plan_sha256']+'.json'),parent);r.write(ROOT/'frozen_plan.json',parent)
    print('K64_WIDE_CONTROL_PROFILE_FROZEN',parent['plan_sha256'],flush=True)

def deliver():
    caps=r.read(capture.CAPTURES);assert len(caps)==2
    assert {x['role'] for x in caps}=={'base','candidate'} and len({x['active_CU_index'] for x in caps})==1
    codes={(x['ID'],x['arm']):x for x in r.read(capture.ANALYSIS/'profile_isa.json')}
    metrics={(x['ID'],x['arm']):x for x in r.read(capture.ANALYSIS/'profile_analysis.json')['rows']}
    target=ROOT/'delivery/batch10b_k64_wide_depth_control';assert not target.exists();target.mkdir()
    manifest=[];lines=['# 八波K32/K64直接控制SQTT','',
        '固定ID805，M64/N2048/K4096/G32，GPU4，同binary/epoch。base是实验K32D4八波6027，candidate是K64D2八波6029；两者均为完整M所有权/N128，不把base称为当前最佳CK。',
        '先完整解压保留原文件名及sidecar，分别打开下面perf，Result选择dispatch18、对应kernel、XCD0。GUI物理CU标签可能与active-CU索引不同。',
        'Summary比较实际VGPR/LDS；Source定位重复K循环的buffer_load、vmcnt、ds_read、lgkmcnt、barrier和MMAC；Wavefronts恢复完整范围，重点比较25%～75%稳态的空档。',
        'K64相对K32的三轮发现点估计约慢15%，不是七block确认。K和全局stage数/资源一同改变，不能把差异只归因一条wait。平均驻留和累计wait不是单独因果证明，也不能把跨wave累计时钟相加当kernel墙钟。',
        '这些perf/SQTT耗时仅用于诊断，不计正式性能成绩。本机仅检查文件、实际代码、dispatch和trace，未打开Windows XCompute。','']
    for cap in caps:
        code=codes[805,cap['arm']];metric=metrics[805,cap['arm']]
        assert code['unknown_lines']==0 and cap['raw_token_bytes']>=4096
        source=Path(next(x['path'] for x in cap['files'] if x['path'].endswith('.perf'))).parent
        relative=Path('captures')/source.name;shutil.copytree(source,target/relative)
        entry={k:v for k,v in cap.items() if k not in ['files','raw_log']}
        entry.update(files=[],kernel_name=code['captured_kernel'],machine_sha256=code['sha256'],phases=metric['geometry'],supplement_script_sha256=plan.sha(__file__))
        for item in cap['files']:
            p=target/relative/Path(item['path']).relative_to(source)
            assert p.stat().st_size==item['bytes'] and plan.sha(p)==item['sha256']
            entry['files'].append(dict(path=str(p.relative_to(target)),bytes=p.stat().st_size,sha256=plan.sha(p)))
        manifest.append(entry);perf=next(x for x in entry['files'] if x['path'].endswith('.perf'))
        lines += [f'## {cap["role"]} 实例{cap["actual_instance"]}','',f'- 文件 `{perf["path"]}`，dispatch18/XCD0/active-CU-index{cap["active_CU_index"]}。',f'- kernel `{code["captured_kernel"]}`。',f'- 资源 {metric["geometry"]}；平均驻留wave/CU {metric.get("mean_resident_waves_per_CU")}，wait/wavecycle {metric.get("wait_any_over_wave_cycles")}，HBM读取 {metric.get("hbm_read_bytes")}字节。',f'- 主循环PC `{code["main_loop_candidates"]}`。','']
    r.write(target/'profile_manifest.json',manifest)
    with (target/'profile_manifest.csv').open('w',newline='',encoding='utf-8-sig') as out:
        fields=['ID','M','N','K','G','role','actual_instance','physical_gpu','epoch','selected_dispatch','active_CU_index','perf_path','perf_sha256']
        w=csv.DictWriter(out,fields,lineterminator='\n');w.writeheader()
        for item in manifest:
            perf=next(x for x in item['files'] if x['path'].endswith('.perf'))
            row={k:item.get(k) for k in fields};row.update(item['shape']);row.update(perf_path=perf['path'],perf_sha256=perf['sha256']);w.writerow(row)
    for p in [D/'registered_profile_plan.json',capture.RULE,capture.REGPLAN,capture.ATTEMPTS,capture.ANALYSIS/'profile_analysis.json',capture.ANALYSIS/'h3_static_schedule.json']:
        shutil.copy2(p,target/p.name)
    (target/'XCOMPUTE_README.md').write_text('\n'.join(lines)+'\n')
    package=target.parent/'P6l_batch10b_k64_wide_depth_control_SQTT.tar.gz';assert not package.exists()
    with tarfile.open(package,'w:gz') as archive:archive.add(target,arcname=target.name)
    with tarfile.open(package) as archive:
        names=set(archive.getnames())
        assert all(target.name+'/'+x['path'] in names for item in manifest for x in item['files'])
        for item in manifest:
            for expected in item['files']:
                member=archive.getmember(target.name+'/'+expected['path'])
                assert member.size==expected['bytes'] and member.isfile()
                data=archive.extractfile(member).read()
                assert hashlib.sha256(data).hexdigest()==expected['sha256']
    receipt=dict(at=r.stamp(),path=str(package),bytes=package.stat().st_size,sha256=plan.sha(package),captures=2,gui_verified=False,local_integrity_checked=True,formal_timing=False)
    r.write(ROOT/'profile_delivery_batch10b.json',receipt);print('K64_WIDE_CONTROL_PROFILE_DELIVERY_PASS',json.dumps(receipt),flush=True)

def main():
    r.no_core();configure()
    with (D/'controller.lock').open('a') as own,(ROOT/'final_controller.lock').open('a') as final:
        fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(final,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            with r.locked():freeze()
            with r.locked():capture.capture()
            capture.analyze();deliver()
            r.write(D/'controller_status.json',dict(at=r.stamp(),state='complete',automatic_retry=False))
        except BaseException as error:
            r.write(D/'controller_status.json',dict(at=r.stamp(),state='stopped',error=str(error),automatic_retry=False));raise
if __name__=='__main__':main()
