"""Explicit terminal-stage commit, using a private index and preserving user edits."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
ROOT=Path(__file__).resolve().parents[2];REPO=Path('/workspace/composable_kernel')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,env=None,text=False):return subprocess.check_output(['git',*args],cwd=REPO,env=env,text=text)
def edits(patch):
    out={};current=None
    for line in patch.splitlines():
        if line.startswith('+++ b/'):current=line[6:];out.setdefault(current,[])
        elif current and line[:1] in ['+','-'] and not line.startswith(('+++','---')):
            if re.search(r'(GroupedGemmCandidateIdentity|CandidateExpected), \d+>',line):line=re.sub(r', \d+>',', COUNT>',line)
            out[current].append(line)
    return {k:v for k,v in out.items() if v}
def main():
    import sys;sys.path.insert(0,str(ROOT))
    from wave4_closure import require_closed
    require_closed()
    assert (ROOT/'profile_delivery_batch14.json').is_file()
    qualified=read(ROOT/'wave4_qualification.json');assert len(qualified)==35 and all(x['ok'] for x in qualified)
    manifest=read(ROOT/'manifests'/(qualified[0]['plan_sha256']+'.json'))
    assert manifest['phase']=='h3_wave4_discovery'
    epoch=read(ROOT/'environment_epoch.json')['id']
    assert all(x['plan_sha256']==manifest['plan_sha256'] and x['epoch']==epoch for x in qualified)
    rows=read(ROOT/'wave4_discovery_results.json');assert len(rows)==27
    assert all(x['plan_sha256']==manifest['plan_sha256'] and x['epoch']==epoch for x in rows)
    assert read(ROOT/'wave4_build_isa_audit.json')['ok']
    for n,h in manifest['worktree_source_sha256'].items():assert sha(REPO/n)==h
    stage=ROOT/'commit_preparation_wave4';pure=stage/'own_tree';proof=read(stage/'proof.json')
    tests=read(stage/'cpu/results.json');assert len(tests)==11 and all(x['rc']==0 and x['GPU'] is False for x in tests)
    for x in proof:
        assert sha(REPO/x['path'])==x['worktree_sha256']
        assert sha(pure/x['path'])==x['pure_sha256']
    assert not git('diff','--cached','--name-only').strip()
    worktree={x['path']:(REPO/x['path']).read_bytes() for x in proof}
    index=stage/'isolated.index';assert not index.exists()
    env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
    subprocess.run(['git','read-tree','HEAD'],cwd=REPO,env=env,check=True)
    owned=[]
    for x in proof:
        n=x['path'];data=(pure/n).read_bytes()
        blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=REPO,input=data).decode().strip()
        subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+n],cwd=REPO,env=env,check=True);owned.append((n,blob))
    changed=git('diff','--cached','--name-only',env=env,text=True).splitlines()
    assert len(changed)==8 and set(changed)<=set(worktree),changed
    subprocess.run(['git','diff','--cached','--check'],cwd=REPO,env=env,check=True)
    subprocess.run(['git','commit','-m','P6l decode四wave完整M所有权与B复用（实验用，不合入）'],cwd=REPO,env=env,check=True)
    head=git('rev-parse','HEAD',text=True).strip()
    for name,blob in owned:subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+name],cwd=REPO,check=True)
    assert not git('diff','--cached','--name-only').strip()
    assert all((REPO/n).read_bytes()==data for n,data in worktree.items())
    for name,blob in owned:assert git('rev-parse',head+':'+name,text=True).strip()==blob
    assert edits(git('diff',text=True))==edits((ROOT/'initial_tracked.patch').read_text())
    rf='include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp'
    assert hashlib.md5(git('diff','--',rf)).hexdigest()=='4c7f49a5c7592767d53195a713db6b8a'
    original={x[3:] for x in (ROOT/'initial_status.txt').read_text().splitlines() if x.startswith('?? ')}
    current=set(git('ls-files','--others','--exclude-standard',text=True).splitlines())
    pins=read(ROOT/'initial_files_sha256.json')
    assert all(sha(REPO/n)==pins[n] for n in original)
    assert original<=current
    receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=head,changed_files=changed,qualification_count=35,discovery_count=27,manifest_sha256=manifest['plan_sha256'],epoch=epoch,adopted=False,source_default_off=True,initial_user_edits_and_untracked_preserved=True,untracked10_bytes_verified=True,Git_blob_bytes_verified=len(owned),worktree_bytes_unchanged=True,readfirstlane_preserved=True,push=False)
    (ROOT/'wave4_source_commit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('WAVE4_EXPERIMENTAL_OWN_ONLY_SOURCE_COMMIT_PASS',head,flush=True)
if __name__=='__main__':main()
