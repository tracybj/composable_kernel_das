"""Apply inspected B consumer-reuse overlay and build official targets on CPU."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import plan,runtime as r,shader_audit
REPO=Path('/workspace/composable_kernel')
HERE=Path(__file__).resolve().parent
def main():
 r.no_core();session=r.read(ROOT/'session.json');assert time.time()+5400<session['gpu_deadline_epoch']
 assert r.read(ROOT/'post_low_lds_build_status.json')['state']=='complete'
 assert r.read(ROOT/'low_lds_controller_status.json')['state']=='complete'
 assert r.read(ROOT/'low_lds_source_commit.json')['untracked10_bytes_verified']
 assert r.read(ROOT/'low_lds_archive_commit.json')['user_worktree_preserved']
 assert len(r.read(ROOT/'low_lds_discovery_results.json'))==59
 assert r.read(ROOT/'profile_delivery_batch13.json')['captures']==14
 decision=r.read(HERE/'mechanism_decision.json');assert decision['proceed'] and decision['not_fourth_ownership_hypothesis']
 assert decision['evidence']['discovery_sha256']==plan.sha(ROOT/'low_lds_discovery_results.json')
 for name in ['cpu_model_result.json','probe_resources.json','actual_cfg_proof.json']:
  assert r.read(HERE/name)['ok']
 assert all(x['rc']==0 for x in r.read(HERE/'cpu_overlay/results.json'))
 assert r.read(HERE/'cpu_policy/results.json')['ok']
 assert r.read(HERE/'cpu_policy/public_disable_equivalence.json')['ok']
 assert r.read(HERE/'old_default_compatibility.json')['ok']
 check=subprocess.run([str(HERE/'cpu_overlay/grouped_gemm_decode_mainline_selector_test')],capture_output=True,text=True)
 r.write(HERE/'selector_cpu_result_before_apply.json',dict(rc=check.returncode,stdout=check.stdout,stderr=check.stderr,GPU=False));assert check.returncode==0
 overlay=r.read(HERE/'overlay.json');patch=HERE/'integration.patch';assert plan.sha(patch)==overlay['patch_sha256']
 for x in overlay['files']:
  p=REPO/x['path'];assert (plan.sha(p) if p.exists() else None)==x['old_sha256']
 subprocess.run(['git','apply','--check','--whitespace=error-all',str(patch)],cwd=REPO,check=True)
 folder=ROOT/'compile/build14';assert not folder.exists();assert shutil.disk_usage(ROOT).free>=20*1024**3
 folder.mkdir(parents=True);backup=folder/'previous';backup.mkdir()
 old=r.read(ROOT/'frozen_plan.json');assert old['phase']=='h3_low_lds_discovery'
 assert plan.sha(plan.BENCH)==old['benchmark_sha256']=='a8180db82315d1cb6b875ee8b9e1ef11933fa00e81fbf835636e848da3e947ab'
 for name,sha in old['worktree_source_sha256'].items():
  assert plan.sha(REPO/name)==sha
  q=backup/'source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/name,q)
 shutil.copy2(ROOT/'frozen_plan.json',backup/'frozen_plan.json')
 names=['tile_example_grouped_gemm_device_args_benchmark','tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke','tile_example_grouped_gemm_selector_test','tile_example_grouped_gemm_decode_depth8_selector_test','tile_example_grouped_gemm_decode_mainline_selector_test']
 for name in names:shutil.copy2(REPO/'build/bin'/name,backup/name)
 kernels=shader_audit.inventory(plan.BENCH);assert len(kernels)==1760
 r.write(folder/'reference_shaders.json',dict(binary_sha256=plan.sha(plan.BENCH),kernels=kernels))
 subprocess.run(['git','apply','--whitespace=error-all',str(patch)],cwd=REPO,check=True)
 for x in overlay['files']:assert plan.sha(REPO/x['path'])==x['new_sha256']
 sources=dict(old['worktree_source_sha256'])
 sources.update({x['path']:x['new_sha256'] for x in overlay['files']})
 for name in sources:sources[name]=plan.sha(REPO/name)
 assert len(sources)==25
 r.write(folder/'source_sha256.json',sources)
 for name,s in sources.items():
  q=folder/'compiled_sources'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/name,q);assert plan.sha(q)==s
 r.write(ROOT/'active_build.json',dict(folder='compile/build14',at=r.stamp(),script='drafts/conditional_n128_wave4/build_factor.py',phase='compile_N128_K32_D2_uniform_four_waves',GPU=False))
 os.sched_setaffinity(0,{124,125,126,127});os.nice(10)
 commands=[['cmake','-S',str(REPO),'-B',str(REPO/'build'),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],['cmake','--build',str(REPO/'build'),'--target',*names,'-j4']]
 results=[]
 r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='running',script_sha256=plan.sha(__file__),GPU=False))
 try:
  for i,cmd in enumerate(commands):
   assert time.time()+60<session['gpu_deadline_epoch']
   assert all(plan.sha(REPO/n)==s for n,s in sources.items())
   memory=int(re.search(r'MemAvailable:\s+(\d+)',Path('/proc/meminfo').read_text())[1]);assert memory>=96*1024*1024
   rec=dict(at=r.stamp(),command=cmd,GPU=False,stage=i);r.write(folder/f'{i}_command.json',rec);start=time.monotonic()
   env=os.environ.copy();env.update(HIP_VISIBLE_DEVICES='4',CUDA_VISIBLE_DEVICES='4')
   with (folder/f'{i}_build.log').open('x') as log:
    child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
    rec['pid']=child.pid;r.write(folder/'live.json',rec);rc=child.wait()
   rec.update(rc=rc,seconds=time.monotonic()-start,finished_at=r.stamp());results.append(rec);r.write(folder/'results.json',results)
   print('N128_WAVE4_BUILD_STAGE',i,'rc',rc,'seconds',rec['seconds'],flush=True)
   assert rc==0,'CPU build failed; no automatic retry'
  assert all(plan.sha(REPO/n)==s for n,s in sources.items())
  r.write(folder/'completed.json',dict(at=r.stamp(),CPU_only=True,GPU=False,benchmark_sha256=plan.sha(plan.BENCH),source_sha256=sources))
  r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='complete',GPU=False))
  print('N128_WAVE4_FACTOR_CPU_BUILD_PASS',plan.sha(plan.BENCH),flush=True)
 except BaseException as error:
  r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='stopped',GPU=False,error=str(error)));raise
if __name__=='__main__':main()
