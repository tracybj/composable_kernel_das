"""CPU-only actual ISA proof; no benchmark or GPU operation."""
from pathlib import Path
import hashlib,json,mmap,re,sys
D=Path(__file__).resolve().parent
ROOT=D.parents[1]
sys.path.insert(0,str(ROOT));import h3_isa_schedule as schedule
sys.path.insert(0,'/workspace/v7_coverage/p6d');import elf_isa as e

def audit(item,rows,depth):
    mf=1;nf=256//(8//rows)//16;cycle=3*depth;halves=2
    ins=schedule.instructions(item['assembly'])
    loops=[g for g in schedule.cyclic_regions(ins) if any(x['opcode'].startswith('v_mmac') for x in g)]
    assert len(loops)==1,(rows,len(loops))
    loop=loops[0];barriers=[i for i,x in enumerate(loop) if x['opcode']=='s_barrier']
    assert len(barriers)==cycle
    assert sum(x['opcode'].startswith('v_mmac') for x in loop)==cycle*mf*nf*halves
    rotated=loop[barriers[0]:]+loop[:barriers[0]]
    cuts=[i for i,x in enumerate(rotated) if x['opcode']=='s_barrier'];groups=[]
    for j,cut in enumerate(cuts):
        segment=rotated[cut+1:cuts[j+1] if j+1<len(cuts) else len(rotated)]
        reads=[x for x in segment if x['opcode'].startswith('ds_read')]
        calcs=[x for x in segment if x['opcode'].startswith('v_mmac')]
        loads=[x for x in segment if x['opcode'].startswith('buffer_load')]
        assert len(loads)==3 and all(x['opcode']=='buffer_load_dwordx4' and 'lds' in x['operands'] for x in loads),(rows,depth,j,'UnexpectedVMEMwidth/count')
        assert sum('idxen' in x['operands'] for x in loads)==1,(rows,depth,j,'Aindexedloadnotunique')
        assert len(reads)==(mf+nf//2)*halves and len(calcs)==mf*nf*halves,(rows,j,len(reads),len(calcs))
        first=next(i for i,x in enumerate(segment) if x['opcode'].startswith('ds_read'))
        compute=next(i for i,x in enumerate(segment) if x['opcode'].startswith('v_mmac'))
        assert not any(x['opcode']=='s_waitcnt' and 'lgkmcnt' in x['operands'] for x in segment[first:compute]),(rows,j,'Future operands waited before current MMAC')
        writes=set().union(*(schedule.vgprs(x['operands'].split(',')[0]) for x in reads));uses=set()
        for x in calcs:
            args=x['operands'].split(',');uses|=schedule.vgprs(args[1])|schedule.vgprs(args[2])
        assert not writes&uses,(rows,j,'Future/current alias')
        assert any(x['opcode']=='s_waitcnt' and 'lgkmcnt(0)' in x['operands'] for x in segment[compute:]),(rows,j,'Missing reader drain')
        groups.append(dict(segment=j,read_registers=sorted(writes),mmac_registers=sorted(uses),static_VMEM=3,A_indexed_VMEM=1,B_offset_VMEM=2))
    for j in range(1,len(groups)):
        assert groups[j]['mmac_registers']==groups[j-1]['read_registers'],(rows,j,'Ready operand mismatch')
    assert groups[-1]['read_registers']==groups[0]['mmac_registers'],(rows,depth,'Cyclicoperandwrap')
    vmwaits={int(m[1]) for x in loop if x['opcode']=='s_waitcnt' for m in [re.search(r'vmcnt\((\d+)\)',x['operands'])] if m}
    assert vmwaits==({0} if depth==2 else {2,3}),(rows,depth,vmwaits)
    return dict(rows=rows,depth=depth,cycle=cycle,halves=halves,groups=groups,main_loop=dict(start_pc=hex(loop[0]['address']),end_pc=hex(loop[-1]['address']),line_start=loop[0]['line'],line_end=loop[-1]['line']),unchanged_LG0_drain=True,main_loop_vmwait_counts=sorted(vmwaits),cyclic_register_wrap_verified=True)

def main():
    resource=json.loads((D/'probe_resources.json').read_text());assert resource['ok']
    binary=D/'probe.o';assert hashlib.sha256(binary.read_bytes()).hexdigest()==resource['binary_sha256']
    out=D/'cfg';out.mkdir(exist_ok=True);e.ROOT=out;results=[]
    with binary.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        fat=next(x for x in e.sections(data) if x['name']=='.hip_fatbin')
        for target,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
            if 'gfx936' not in target or code[:4]!=b'\x7fELF':continue
            sec=e.sections(code);symbols=e.symbols(code,sec);meta=e.metadata(code,sec)
            for name,fields in meta.items():
                match=re.search(r'DecodeNnN256DepthProbeKernelILi(\d+)ELi(\d+)EE',name)
                if not match:continue
                rows,depth=int(match[1]),int(match[2]);tag=f'n256_probe_m{rows*16}_d{depth}'
                co=out/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
                item=e.dump(co,code,sec,symbols,meta,name,tag);assert item['unknown_lines']==0
                proof=audit(item,rows,depth);proof.update(symbol=name,machine_sha256=item['sha256'],VGPR=fields['.vgpr_count']);results.append(proof)
    assert len(results)==6
    result=dict(ok=True,CPU_only=True,GPU=False,not_integrated=True,not_precision_or_timing_evidence=True,proofs=results,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),VMEM_width_count_proof=True)
    (D/'actual_cfg_proof.json').write_text(json.dumps(result,indent=2)+'\n')
    print('N256_D2_D3_ACTUAL_CPU_CFG_PASS',len(results),flush=True)
if __name__=='__main__':main()
