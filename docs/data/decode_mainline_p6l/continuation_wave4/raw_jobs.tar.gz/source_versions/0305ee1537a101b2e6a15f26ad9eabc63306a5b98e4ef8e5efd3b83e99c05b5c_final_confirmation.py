"""Freeze an actual selector domain, then independently confirm every member.

No candidate is chosen and no heldout is generated merely by importing this
module. `freeze --proposal FILE` is required after discovery has converged.
"""
from pathlib import Path
import argparse, copy, csv, hashlib, json, math, random, statistics, subprocess, time, uuid
import acceptance, campaign, plan, runtime as r
from shared_campaign import as_case
ROOT=Path(__file__).resolve().parent
STEMS=('MAINLINE','SHORT')

def geometry(x):return tuple(int(x[k]) for k in ('M','N','K','G'))

def predictor(folder):
    folder.mkdir(parents=True,exist_ok=True)
    executable=folder/'selector_probe'
    command=['g++','-O2','-std=c++17','-I'+str(plan.REPO/'include'),str(ROOT/'mainline_selector_probe.cpp'),'-o',str(executable)]
    subprocess.run(command,capture_output=True,text=True,check=True,timeout=120)
    def predict(cases):
        lines=[]
        for x in cases:
            env=x['env'];extra=[]
            for stem in STEMS:
                extra.extend([int(env.get(plan.PREFIX+'ENABLE_BF16_NN_DECODE_'+stem)=='1' and env.get(plan.PREFIX+'DISABLE_BF16_NN_DECODE_'+stem)!='1'),int(env.get(plan.PREFIX+'BF16_NN_DECODE_'+stem+'_VARIANT','0'))])
            values=[x[k] for k in ('ID','M','N','K','G')]+[0]+plan.base.policy_fields(x)+extra
            lines.append(' '.join(map(str,values)))
        out=subprocess.run([str(executable)],input='\n'.join(lines)+'\n',capture_output=True,text=True,check=True,timeout=120)
        rows=[list(map(int,line.split())) for line in out.stdout.splitlines()]
        assert len(rows)==len(cases) and all(z[0]==x['ID'] for x,z in zip(cases,rows))
        return [x[2] for x in rows]
    return predict,command

def previously_used():
    used=set()
    def visit(value):
        if isinstance(value,dict):
            if all(k in value and isinstance(value[k],int) for k in ('M','N','K','G')):used.add(geometry(value))
            for x in value.values():visit(x)
        elif isinstance(value,list):
            for x in value:visit(x)
    # A heldout must not reuse geometry even from CPU policy/selector design checks.
    files=[ROOT/'source_results.json',ROOT/'research_plan.json',
           ROOT/'cpu_host_policy_factors/cases.json',
           ROOT/'h3_factors_cpu_proposed_plan.json',
           ROOT/'isolated_resource_build/heldout_cpu_exclusion_inventory.json',
           ROOT/'cpu_phase_policy/heldout_geometry_inventory.json',
           ROOT/'cpu_k64_policy/heldout_geometry_inventory.json',
           ROOT/'cpu_n256_policy/heldout_geometry_inventory.json',
           ROOT/'cpu_b_reuse_policy/heldout_geometry_inventory.json',
           ROOT/'cpu_low_lds_policy/heldout_geometry_inventory.json',
           ROOT/'cpu_wave4_policy/heldout_geometry_inventory.json',
           ROOT/'historical_exclusion_inventory.json']
    files+=list(ROOT.glob('*discovery_plan.json'))
    files+=list((ROOT/'final_attempts').glob('*/plan.json'))
    for folder in ['docs/data/decode_areg_scope_p6j','docs/data/v7_decode_wave_p6h']:
        files+=list((plan.REPO/folder).glob('*.json'))
    records=[]
    for p in sorted(set(files)):
        if p.exists():
            value=r.read(p)
            if p.name=='historical_exclusion_inventory.json':
                assert all(plan.sha(x['path'])==x['sha256'] for x in value['source_records'])
            if p.name=='heldout_geometry_inventory.json':
                assert all(plan.sha(x['path'])==x['sha256'] for x in value['source_inputs'])
            visit(value);records.append(dict(path=str(p),sha256=plan.sha(p)))
    return used,records

def with_candidate(base,family):
    other=copy.deepcopy(base);other['env'].update(family['env'])
    # This also checks that all overrides are registered and no inherited flags leak.
    plan.environment(other['env'],{})
    return other

def freeze(proposal_path):
    assert time.time()+60<r.read(ROOT/'session.json')['gpu_deadline_epoch']
    proposal=r.read(proposal_path)
    assert proposal.get('mechanistic_reason') and proposal.get('evidence_results') and proposal.get('evidence_plan')
    evidence=Path(proposal['evidence_results']).resolve()
    assert evidence.is_relative_to(ROOT) and evidence.exists()
    assert plan.sha(evidence)==proposal['evidence_sha256']
    evidence_rows=r.read(evidence)
    evidence_plan=Path(proposal['evidence_plan']).resolve()
    assert evidence_plan.is_relative_to(ROOT) and evidence_plan.exists()
    assert plan.sha(evidence_plan)==proposal['evidence_plan_sha256']
    registered=r.read(evidence_plan)['discovery_pairs']
    assert len({x['pair'] for x in evidence_rows})==len(registered)
    assert {x['pair'] for x in evidence_rows}=={x['key'] for x in registered},'Incomplete registered discovery'
    old=r.read(ROOT/'frozen_plan.json')
    assert evidence_rows and all(x['binary_sha256']==old['benchmark_sha256'] and x['epoch']==r.Site(ROOT).epoch() for x in evidence_rows)
    assert plan.sha(plan.BENCH)==old['benchmark_sha256']
    for name,sha in old['worktree_source_sha256'].items():assert plan.sha(plan.REPO/name)==sha
    attempts=r.read(ROOT/'final_attempts.json',[]);protocol=r.read(ROOT/'heldout_protocol.json')
    number=len(attempts);assert number<len(protocol['seeds']),'No preregistered unused heldout seed remains'
    folder=ROOT/'final_attempts'/f'attempt_{number+1}'
    assert not folder.exists(),'Never overwrite a frozen finalization attempt'
    folder.mkdir(parents=True)
    predict,command=predictor(folder/'cpu')
    originals=r.read(ROOT/'source_results.json')
    original_path=plan.REPO/'docs/data/decode_depth8_replay_p6k/results.json'
    assert plan.sha(original_path)=='00c80c665735d59165947e5c9458e4e3cb0327df1a47dee2926fe725af4e9d3d'
    assert originals==r.read(original_path),'The original frozen source changed'
    bases=[as_case(x) for x in originals]
    assert len(bases)==1193
    assert predict(bases)==[x['expected'] for x in bases],'An old configured selector path changed'
    used,exclusions=previously_used();rng=random.Random(protocol['seeds'][number]);pairs=[];domains=[];owned_ids=set()
    families=proposal['families'];assert families and set(families)<=set(['main','short'])
    for name in sorted(families):
        family=families[name];allowed=set(family['candidate_ids']);assert allowed and all(x>=6004 for x in allowed)
        candidates=[with_candidate(x,family) for x in bases];selected=predict(candidates);domain=[];outside=[]
        for base,other,actual in zip(bases,candidates,selected):
            other['expected']=actual
            if actual not in allowed:
                assert actual==base['expected'],'Unexpected enabled path outside the proposed domain'
                outside.append(dict(ID=base['ID'],actual=actual));continue
            assert base['phase']=='decode' and 1<=base['M']<=64 and base['ID'] not in owned_ids
            assert (base['K']>=2048) if name=='main' else (base['K']<2048 and base['G']<=32)
            assert actual!=base['expected']
            owned_ids.add(base['ID']);domain.append(base['ID'])
            pairs.append(dict(key=f'original_{base["ID"]}_{name}',family=name,original=True,control=False,base=base,candidate=other))
        assert domain,'Selected candidate has no original-shape coverage'
        domains.append(dict(family=name,original_ids=domain,outside_cpu_fallback=outside))
        # Generate only now: binary, property selector and proposal are frozen.
        draw=protocol['draws'][name];heldouts=[];draw_count=0;rejected=[]
        while len(heldouts)<protocol['minimum_per_adopted_family']:
            assert draw_count<protocol['max_draws_per_seed']
            draw_count+=1
            m=rng.randint(*draw['M']);n=128*rng.randint(*draw['N_times128'])
            k=(128*rng.randint(*draw['K_times128']) if name=='main' else 32*rng.randint(*draw['K_times32']))
            g=rng.randint(*draw['G']);shape=(m,n,k,g)
            if shape in used:continue
            base=dict(ID=-200000-number*10000-len(pairs),M=m,N=n,K=k,G=g,phase='decode',env={plan.V7:'1',plan.DEPTH8:'1'},accuracy_repeats=3,baseline_source='Frozen default V7/Depth8 policy for unseen shapes; no historical per-shape oracle')
            other=with_candidate(base,family);a,b=predict([base,other])
            if b not in allowed:
                rejected.append(dict(shape=list(shape),actual=b));continue
            assert a>0 and a!=b
            base['expected']=a;other['expected']=b;used.add(shape)
            pair=dict(key=f'heldout_{name}_{len(heldouts)+1}',family=name,original=False,control=False,base=base,candidate=other)
            heldouts.append(pair);pairs.append(pair)
        domains[-1].update(heldout_keys=[x['key'] for x in heldouts],draw_count=draw_count,cpu_filtered_draws=rejected)
    assert len(owned_ids)<881,'This task does not authorize full decode GPU testing'
    assert len({x['key'] for x in pairs})==len(pairs)
    data=dict(schema=1,at=r.stamp(),number=number+1,seed=protocol['seeds'][number],heldout_protocol_sha256=plan.sha(ROOT/'heldout_protocol.json'),proposal=proposal,proposal_source=str(Path(proposal_path).resolve()),proposal_sha256=plan.sha(proposal_path),benchmark_sha256=old['benchmark_sha256'],epoch=r.Site(ROOT).epoch(),source_sha256=old['worktree_source_sha256'],discovery_evidence_sha256=plan.sha(evidence),selector_command=command,selector_sha256=plan.sha(plan.SELECTOR),exclusion_sources=exclusions,domains=domains,pairs=pairs,paired_blocks=7,order=['AB','BA','AB','BA','AB','BA','AB'],timing='warmup10/samples30/singlelaunch/include_args_build0; median of seven block medians; full3 and real guards both arms first',adoption_rule='Any member with candidate median >1.02*baseline median fails that whole family, including highCV cases; retain all uncertainty. Stable50/attributable30 use acceptance.py and original weak shapes only.',goal_rule='At least50 stable weak originals and30 attributable crossings from families passing whole-domain precision/fallback/regression gates')
    data['sha256']=plan.digest(data);r.write(folder/'plan.json',data)
    active=dict(path=str(folder),plan_sha256=data['sha256'],number=number+1);r.write(ROOT/'final_active.json',active)
    manifest=copy.deepcopy(old);manifest.pop('plan_sha256',None)
    manifest.update(phase='final_confirmation',final_plan_sha256=data['sha256'])
    for name in ['final_confirmation.py','final_active.json','mainline_selector_probe.cpp','acceptance.py']:
        manifest['runner_sha256'][name]=plan.sha(ROOT/name)
    manifest['runner_sha256'][str((folder/'plan.json').relative_to(ROOT))]=plan.sha(folder/'plan.json')
    manifest['plan_sha256']=plan.digest(manifest);r.write(ROOT/'manifests'/(manifest['plan_sha256']+'.json'),manifest);r.write(ROOT/'frozen_plan.json',manifest)
    attempts.append(dict(**active,at=r.stamp(),manifest_sha256=manifest['plan_sha256'],seed=data['seed']));r.write(ROOT/'final_attempts.json',attempts)
    print('FINAL_DOMAIN_FROZEN',data['sha256'],'originals',len(owned_ids),'heldouts',len(pairs)-len(owned_ids),'blocks7',flush=True)

def context():
    active=r.read(ROOT/'final_active.json');folder=Path(active['path']);data=r.read(folder/'plan.json');site=r.Site(ROOT)
    assert site.manifest['phase']=='final_confirmation' and site.manifest['final_plan_sha256']==data['sha256']==active['plan_sha256']
    assert site.epoch()==data['epoch'],'Epoch changed: freeze a new intact confirmation after recovery/qualification'
    return folder,data,site

def run():
    folder,data,site=context();completed=r.read(folder/'results.json',[]);r.no_core()
    with r.locked():
        regress=r.read(folder/'regressions.json',[])
        for name in ['tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke']:
            if any(x['logical_key']==name and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in regress):continue
            binary=plan.REPO/'build/bin'/name
            record=site.execute(dict(kind='regression',logical_key=name,command=[str(binary)],binary=str(binary),expected_binary_sha256=plan.sha(binary),env={},regression_kind='device_args_query_test' if name.endswith('query_test') else 'device_args_smoke',purpose='final_confirmation'))
            regress.append(record);r.write(folder/'regressions.json',regress)
        for pair in data['pairs']:
            if any(x['pair']==pair['key'] and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in completed):continue
            attempt=uuid.uuid4().hex[:12];group=[];epoch=site.epoch()
            for arm in ['base','candidate']:
                spec=campaign.ck(pair[arm],'accuracy',f'final_{pair["key"]}_{attempt}_{arm}_accuracy')
                group.append(site.execute(dict(spec,variant=arm,attempt=attempt,pair=pair['key'],purpose='final_confirmation')))
            for block in range(1,8):
                for arm in (['base','candidate'] if block%2 else ['candidate','base']):
                    spec=campaign.ck(pair[arm],'perf',f'final_{pair["key"]}_{attempt}_{arm}_b{block}')
                    group.append(site.execute(dict(spec,variant=arm,attempt=attempt,pair=pair['key'],block=block,purpose='final_confirmation')))
            assert len(group)==16 and all(x['ok'] and x['epoch']==epoch for x in group)
            aa=[x['result'] for x in group if x['kind']=='perf' and x['variant']=='base'];bb=[x['result'] for x in group if x['kind']=='perf' and x['variant']=='candidate']
            source=next((x for x in r.read(ROOT/'source_results.json') if x['ID']==pair['base']['ID']),None) if pair['original'] else None
            measured=acceptance.classify(source,aa,bb)
            assert pair['candidate']['expected']!=pair['base']['expected']
            row=dict(pair=pair['key'],family=pair['family'],ID=pair['base']['ID'],shape={k:pair['base'][k] for k in ('M','N','K','G')},original=pair['original'],base_instance=pair['base']['expected'],candidate_instance=pair['candidate']['expected'],base_env=pair['base']['env'],candidate_env=pair['candidate']['env'],base_blocks=aa,candidate_blocks=bb,epoch=epoch,binary_sha256=site.manifest['benchmark_sha256'],plan_sha256=site.manifest['plan_sha256'],keys=[x['key'] for x in group],**measured)
            completed.append(row);r.write(folder/'results.json',completed)
            r.write(folder/'progress.json',dict(at=r.stamp(),completed=len(completed),total=len(data['pairs']),last_pair=pair['key']))
            print('FINAL_PAIR_PASS',pair['key'],'delta_pct',round(100*(row['candidate_ms']/row['base_ms']-1),3),'stable',row['count_for_stable50'],'cross',row['count_for_attributable30'],'highCV',row['high_cv'],flush=True)
    print('FINAL_CONFIRMATION_MEASUREMENTS_PASS',len(completed),flush=True)

def project_measured_original(original,measured,bykey,folder,attempt_number):
    """Replace current values and their provenance together; preserve P6k verbatim."""
    assert original['ID']==measured['ID'] and measured['original']
    assert {k:original[k] for k in ('M','N','K','G')}==measured['shape']
    candidate=[bykey[k] for k in measured['keys'] if bykey[k]['variant']=='candidate']
    assert len(candidate)==8 and [x['kind'] for x in candidate]==['accuracy']+['perf']*7
    assert all(x['selected']==measured['candidate_instance'] and x['physical_gpu']==4 and
               (x['epoch'],x['binary_sha256'],x['plan_sha256'])==
               (measured['epoch'],measured['binary_sha256'],measured['plan_sha256']) for x in candidate)
    x=copy.deepcopy(original);x['projection_previous_P6k']=copy.deepcopy(original)
    x.update(projection_source='fresh_final_candidate',source_type='p6l_fresh_full_output_and_seven_block_confirmation',
             source=str(folder/'results.json'),configured_scheme=f'P6l_{measured["family"]}_instance_{measured["candidate_instance"]}',
             expected=measured['candidate_instance'],actual_instance=measured['candidate_instance'],
             env=copy.deepcopy(measured['candidate_env']),CK_ms=measured['candidate_ms'],
             physical_gpu=4,epoch=measured['epoch'],binary_sha256=measured['binary_sha256'],
             plan_sha256=measured['plan_sha256'],attempt=candidate[0]['attempt'],confirmation_attempt=attempt_number,
             confirmation_blocks=7,candidate_overlay_applied=True,candidate_overlay_source='P6l accepted whole property domain',
             source_keys=[z['key'] for z in candidate],source_logs=[str(Path(z['path'])/'run.log') for z in candidate],
             paired_source_keys=measured['keys'],paired_source_logs=[str(Path(bykey[k]['path'])/'run.log') for k in measured['keys']],
             full_output_key=candidate[0]['key'],comparisons=copy.deepcopy(candidate[0]['comparisons']),
             redzone_elements_each_backend=2*int(candidate[0]['config']['output_redzone_elements']),
             measured_at=max(z['finished_at'] for z in candidate),high_cv=measured['high_cv'])
    blocks=measured['candidate_blocks'];assert len(blocks)==7
    assert math.isclose(measured['candidate_ms'],statistics.median(z['median_ms'] for z in blocks),rel_tol=1e-12)
    for name,key in [('round_median_ms','median_ms'),('round_min_ms','min_ms'),('round_max_ms','max_ms'),('round_cv','cv')]:
        x[name]=[z[key] for z in blocks]
    x['R_frozen']=x['frozen_BLAS_ms']/x['CK_ms']
    x['P6k_CK_ms']=original['CK_ms'];x['P6k_R_frozen']=original['R_frozen']
    x['delta_pct_vs_P6k']=100*(x['CK_ms']/original['CK_ms']-1)
    if original.get('historical_CK_ms',0)>0:
        x['historical_delta_pct']=100*(x['CK_ms']/original['historical_CK_ms']-1)
    x['CK_TFLOPS']=2*math.prod(measured['shape'].values())/(x['CK_ms']*1e9)
    x['BLAS_TFLOPS']=2*math.prod(measured['shape'].values())/(x['frozen_BLAS_ms']*1e9)
    thresholds=[.99,.8,.5,.3,.2];ratios=[x['frozen_BLAS_ms']/z['median_ms'] for z in blocks]
    def bucket(value):return next((i for i,t in enumerate(thresholds) if value>=t),5)
    x['near_bucket_boundary']=(len({bucket(z) for z in ratios})>1 or
                               any(abs(x['R_frozen']/t-1)<=.01 for t in thresholds))
    x['quality_flags']=(['high_cv_over5pct'] if x['high_cv'] else [])+(['near_bucket_boundary'] if x['near_bucket_boundary'] else [])
    x['quality']='uncertain' if x['quality_flags'] else 'valid_seven_block_measurement'
    x['quality_definition']='Diagnostic flags only: any block CV>5%; or block R spans a reporting bucket / median R within1% relative of a bucket threshold. Acceptance remains acceptance.py.'
    x['observed_variation_band_pct']=100*(max(x['round_median_ms'])-min(x['round_median_ms']))/x['CK_ms']
    x['observed_variation_band_definition']='100*(max(block_median)-min(block_median))/median(block_median), seven candidate blocks'
    assert x['expected']==x['actual_instance'] and len(x['round_cv'])==7
    for key in original:
        if key.startswith('BLAS_') or key=='frozen_BLAS_ms':assert x[key]==original[key]
    return x

def report():
    folder,data,site=context();rows=r.read(folder/'results.json',[])
    jobs=[json.loads(x) for x in (ROOT/'jobs.jsonl').read_text().splitlines()];bykey={x['key']:x for x in jobs}
    originals={x['ID']:x for x in r.read(ROOT/'source_results.json')};pairs={x['key']:x for x in data['pairs']}
    assert len(bykey)==len(jobs) and len({x['pair'] for x in rows})==len(rows)
    for row in rows:
        pair=pairs[row['pair']];records=[bykey[k] for k in row['keys']]
        assert len(records)==16 and [x['kind'] for x in records]==['accuracy']*2+['perf']*14
        assert [x['variant'] for x in records]==['base','candidate']+sum([['base','candidate'] if b%2 else ['candidate','base'] for b in range(1,8)],[])
        assert [x.get('block') for x in records[2:]]==[i for b in range(1,8) for i in [b,b]]
        arms={'base':[],'candidate':[]}
        for rec in records:
            arm=rec['variant'];expected=pair[arm]['expected']
            assert rec['ok'] and rec['physical_gpu']==4 and rec['shape']==row['shape'] and rec['selected']==expected
            assert (rec['epoch'],rec['benchmark_sha256'],rec['plan_sha256'])==(data['epoch'],data['benchmark_sha256'],site.manifest['plan_sha256'])
            actual=r.parse_output((Path(rec['path'])/'run.log').read_text(),rec['kind'],expected,3 if rec['kind']=='accuracy' else 1)
            if rec['kind']=='accuracy':assert all(int(x[1])==row['shape']['M']*row['shape']['N']*row['shape']['G'] and int(x[2])==0 for x in actual['comparisons'])
            else:assert actual['result']==rec['result'];arms[arm].append(actual['result'])
        assert row['base_blocks']==arms['base'] and row['candidate_blocks']==arms['candidate']
        checked=acceptance.classify(originals[row['ID']] if row['original'] else None,arms['base'],arms['candidate'])
        for k,v in checked.items():assert row[k]==v,(row['pair'],k)
    complete=len(rows)==len(data['pairs']);families={}
    for name in data['proposal']['families']:
        cases=[x for x in rows if x['family']==name];expected=[x for x in data['pairs'] if x['family']==name]
        regressions=[x['pair'] for x in cases if x['point_median_regression_over_2pct']]
        families[name]=dict(measured=len(cases),expected=len(expected),pass_all_domain=len(cases)==len(expected) and not regressions,regressions_over2=regressions,highCV=[x['pair'] for x in cases if x['high_cv']])
    for x in rows:
        x['family_adopted']=families[x['family']]['pass_all_domain']
        x['count_for_goal_stable50']=x['family_adopted'] and x['count_for_stable50']
        x['count_for_goal_attributable30']=x['family_adopted'] and x['count_for_attributable30']
    stable=sum(x['count_for_goal_stable50'] for x in rows)
    crossings=sum(x['count_for_goal_attributable30'] for x in rows)
    result=dict(at=r.stamp(),complete=complete,families=families,stable_weak_originals=stable,attributable_crossings=crossings,goal_performance_pass=complete and stable>=50 and crossings>=30,rows=rows,scope='Fresh registered original domain and heldouts only; no1193 full GPU test',count_flags='Only count_for_goal_* from families passing the whole domain contribute to totals. acceptance.py individual count_for_* flags remain diagnostic until that gate passes.')
    r.write(folder/'report.json',result)
    columns=['ID','M','N','K','G','phase','family','original','base_instance','candidate_instance','base_scheme','candidate_scheme','base_ms','candidate_ms','delta_pct','high_cv','family_adopted','stable_gain_at_least_5pct','count_for_goal_stable50','count_for_goal_attributable30','base_TFLOPS','candidate_TFLOPS','frozen_BLAS_ms','BLAS_TFLOPS','BLAS_gpu','BLAS_protocol','BLAS_source','R_frozen_base','R_frozen_candidate','R_live_base','R_live_candidate','R_live_source','base_env','candidate_env','base_block_median_ms','candidate_block_median_ms','base_block_cv','candidate_block_cv','physical_gpu','binary_sha256','epoch','plan_sha256']
    with (folder/'per_shape_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,columns,lineterminator='\n');writer.writeheader()
        for x in rows:
            out={k:x.get(k) for k in columns};out.update(x['shape']);flops=2*math.prod(x['shape'].values())
            out.update(delta_pct=100*(x['candidate_ms']/x['base_ms']-1),base_TFLOPS=flops/(x['base_ms']*1e9),candidate_TFLOPS=flops/(x['candidate_ms']*1e9),phase='decode',physical_gpu=4,
                       base_scheme=originals[x['ID']]['configured_scheme'] if x['original'] else 'V7_Depth8_default_policy_for_unseen',candidate_scheme=f'P6l_{x["family"]}_instance_{x["candidate_instance"]}',
                       base_block_median_ms=[z['median_ms'] for z in x['base_blocks']],candidate_block_median_ms=[z['median_ms'] for z in x['candidate_blocks']],
                       base_block_cv=[z['cv'] for z in x['base_blocks']],candidate_block_cv=[z['cv'] for z in x['candidate_blocks']],
                       R_live_base=None,R_live_candidate=None,R_live_source='Not measured in final confirmation; sixteen-shape Native diagnostics are separate')
            if x['original']:
                origin=originals[x['ID']];blas=origin['frozen_BLAS_ms'];out.update(frozen_BLAS_ms=blas,BLAS_TFLOPS=flops/(blas*1e9),BLAS_gpu=origin['BLAS_gpu'],BLAS_protocol=origin['BLAS_protocol'],BLAS_source=origin['BLAS_source'],R_frozen_base=blas/x['base_ms'],R_frozen_candidate=blas/x['candidate_ms'])
            writer.writerow({k:json.dumps(v,sort_keys=True) if isinstance(v,(dict,list)) else v for k,v in out.items()})
    def bucket(ratio):return next((i for i,t in enumerate([.99,.8,.5,.3,.2]) if ratio>=t),5)
    projection=[];new_byid={x['ID']:x for x in rows if x['original'] and families[x['family']]['pass_all_domain']}
    buckets={p:[0]*6 for p in ['prefill','decode']};fresh=[0]*6
    for original in originals.values():
        new=new_byid.get(original['ID'])
        if new:
            x=project_measured_original(original,new,bykey,folder,data['number']);fresh[bucket(x['R_frozen'])]+=1
        else:
            x=copy.deepcopy(original);x['projection_source']='historical_P6k'
        projection.append(x)
        buckets[x['phase']][bucket(x['R_frozen'])]+=1
    r.write(folder/'historical_projection.json',dict(label='MIXED HISTORICAL PROJECTION; not a fresh1193 replay',updated=len(new_byid),frozen_BLAS_unchanged=True,buckets=buckets,rows=projection))
    r.write(folder/'fresh_adopted_domain_buckets.json',dict(total=len(new_byid),buckets=fresh,synthetics_excluded=True,complete=complete))
    measured={}
    for name in families:
        subset=[x for x in rows if x['original'] and x['family']==name]
        base_buckets=[0]*6;candidate_buckets=[0]*6
        for x in subset:
            blas=originals[x['ID']]['frozen_BLAS_ms']
            base_buckets[bucket(blas/x['base_ms'])]+=1
            candidate_buckets[bucket(blas/x['candidate_ms'])]+=1
        measured[name]=dict(measured_originals=len(subset),baseline=base_buckets,candidate=candidate_buckets,adopted=families[name]['pass_all_domain'],synthetics=sum(not x['original'] and x['family']==name for x in rows))
    r.write(folder/'fresh_measured_domain_buckets.json',dict(label='Fresh seven-block measured domain, including all losses and uncertain rows; not1193 full replay',families=measured,complete=complete))
    print('FINAL_REPORT',json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['freeze','run','report']);ap.add_argument('--proposal',default=str(ROOT/'final_proposal.json'));args=ap.parse_args()
    if args.stage=='freeze':
        assert args.proposal
        with r.locked():freeze(args.proposal)
    elif args.stage=='run':run()
    else:report()

if __name__=='__main__':main()
