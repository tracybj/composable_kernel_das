"""Bounded H3 phase factors; no GPU operation on import or plan creation."""
from pathlib import Path
import argparse,copy,json,statistics,subprocess,time,uuid
import campaign,final_confirmation as final,h3_factors_campaign as prior,resource_campaign as prior_resources,plan,runtime as r
import b_reuse_campaign as parent
ROOT=Path(__file__).resolve().parent
PLAN=ROOT/'low_lds_discovery_plan.json'
QUAL=ROOT/'low_lds_qualification.json'
RESULTS=ROOT/'low_lds_discovery_results.json'
VARIANTS={
 'pure':dict(variant=37,instance=6034),
 'scope_pure':dict(variant=38,instance=6034),
 'auto':dict(variant=39,instance=6034),
 'scope_auto':dict(variant=40,instance=6034),
}

def supported(c):
 m,n,k,g=(c[z] for z in ('M','N','K','G'))
 return 1<=m<=64 and 1024<=n<=4096 and n%128==0 and 2048<=k<=8192 and k%128==0 and 1<=g<=1024

def candidate(base,name,fast=1):
 other=copy.deepcopy(base);v=VARIANTS[name]
 other['env'].update({plan.PREFIX+'ENABLE_BF16_NN_DECODE_MAINLINE':'1',plan.PREFIX+'DISABLE_BF16_NN_DECODE_MAINLINE':'0',plan.PREFIX+'BF16_NN_DECODE_MAINLINE_VARIANT':str(v['variant']),plan.PREFIX+'ENABLE_BF16_NN_DECODE_FAST_POLICY':str(fast),plan.PREFIX+'DISABLE_BF16_NN_DECODE_FAST_POLICY':'0'})
 enabled=supported(base) and (not name.startswith('scope_') or (base['G']<=32 and (base['M']>=17 or base['K']>=6144)))
 if enabled:
  other['expected']=6032 if name in ['auto','scope_auto'] and base['N']%256==0 and (base['N']//256)*base['G']>=160 else 6034
 other['variant']=name
 return other

def create():
 hypothesis=r.read(ROOT/'h3_resource_factors_hypothesis.json')
 source={x['ID']:x for x in r.read(ROOT/'source_results.json')};pairs=[]
 def add(key,base,other,name,control=False,**fields):
  pairs.append(dict(key=key,ID=base['ID'],base=base,candidate=other,variant=name,control=control,**fields))
 extra=[]
 for target_m in [1,16,32,64]:
  available=[x for x in source.values() if x['M']==target_m and supported(x) and x['G']<=32 and (x['M']>=17 or x['K']>=6144) and x['ID'] not in hypothesis['discovery_representative_ids']]
  chosen=min(available,key=lambda x:((x['N']//256)*x['G'],x['N'],x['K'],x['G'],x['ID']))
  extra.append(chosen['ID'])
 ids=hypothesis['discovery_representative_ids']+extra
 assert len(ids)==len(set(ids))==23
 for name in ['pure','auto']:
  for ident in ids:
   base=prior.as_case(source[ident]);other=candidate(base,name)
   assert other['expected']!=base['expected']
   add(f'id{ident}_{name}',base,other,name)
 for ident,name in [(358,'pure'),(622,'auto'),(1184,'pure'),(1185,'auto'),(147,'pure'),(35,'auto'),(788,'scope_auto')]:
  base=prior.as_case(source[ident]);other=candidate(base,name);assert other['expected']==base['expected']
  add(f'fallback_id{ident}_{name}',base,other,name,True,fallback=True)
 for ident in [621,805,1009,312]:
  base=prior.as_case(source[ident]);add(f'geometry_id{ident}_pure',parent.candidate(base,'d2'),candidate(base,'pure'),'pure',True,geometry_compare=True)
 for ident,name,scoped in [(1009,'pure','scope_pure'),(621,'auto','scope_auto')]:
  base=prior.as_case(source[ident]);a=candidate(base,name);b=candidate(base,scoped);assert a['expected']==b['expected']
  add(f'route_id{ident}_{name}_{scoped}',a,b,scoped,True,route_compare=True)
 qualifications=[]
 def synthetic(m,k=2176,n=1280,g=3,expected=5000):
  return dict(ID=-70000-len(qualifications),M=m,N=n,K=k,G=g,phase='decode',expected=expected,env={plan.V7:'1'},accuracy_repeats=3)
 for name in ['pure','auto']:
  for m in [1,15,16,17,31,32,33,63,64]:qualifications.append(candidate(synthetic(m),name))
 for name in ['scope_pure','scope_auto']:
  for m,k in [(1,6144),(17,2176)]:qualifications.append(candidate(synthetic(m,k),name))
 for name in ['pure','auto']:
  case=candidate(synthetic(64),name);case['env'][plan.PREFIX+'DISABLE_BF16_NN_DECODE_FAST_POLICY']='1';case['variant']+='_fast_disabled';qualifications.append(case)
 for ident,name in [(620,'pure'),(805,'auto')]:
  base=prior.as_case(source[ident]);case=candidate(base,name);case['ID']=-70000-len(qualifications)
  case['env'][plan.PREFIX+'DISABLE_BF16_NN_DECODE_MAINLINE']='1';case['expected']=base['expected'];case['variant']+='_family_disabled';qualifications.append(case)
 for name in ['scope_pure','scope_auto']:
  case=candidate(synthetic(1),name);assert case['expected']==5000;case['variant']+='_scope_fallback';qualifications.append(case)
 for name in ['scope_pure','scope_auto']:
  case=candidate(synthetic(32,g=33),name);assert case['expected']==5000;case['variant']+='_G33_fallback';qualifications.append(case)
 for name in ['pure','auto']:
  case=candidate(synthetic(32,n=1152,expected=4002),name);assert case['expected']==6034;case['variant']+='_N128_contract';qualifications.append(case)
 for name in ['pure','auto']:
  case=candidate(synthetic(65),name);assert case['expected']==5000;case['variant']+='_M65_fallback';qualifications.append(case)
 for name in ['pure','auto']:
  case=candidate(synthetic(32,k=2112),name);assert case['expected']==5000;case['variant']+='_K64_tail_fallback';qualifications.append(case)
 for name,m in [('auto',32),('scope_auto',64)]:
  for g in [31,32]:
   case=candidate(synthetic(m,n=1280,g=g),name);assert case['expected']==(6034 if g==31 else 6032);case['variant']+='_CTA160_boundary';qualifications.append(case)
 assert len(pairs)==59 and len(qualifications)==40,(len(pairs),len(qualifications))
 result=dict(schema=1,hypothesis_sha256=plan.sha(ROOT/'low_lds_mechanism_decision.json'),variants=VARIANTS,qualification_cases=qualifications,discovery_pairs=pairs,protocol=r.read(ROOT/'research_plan.json')['diagnostic_protocol'],selection='23 identicalrepresentativesperpolicy(19originalplus4lowestCTAbyMwithoutusingR);7fallback,4coupledN/wave/consumergeometry,2sameGPUroute. NotID-basedadoption.',CPU_only_creation=True,no_new_heldout_draw=True,no_full_GPU_run=True)
 result['sha256']=plan.digest(result);return result

def prepare():
    proposed=create()
    if PLAN.exists():assert r.read(PLAN)==proposed
    else:r.write(PLAN,proposed)
    cases=proposed['qualification_cases']+[c for p in proposed['discovery_pairs'] for c in [p['base'],p['candidate']]]
    audit=prior.selector_check(cases,ROOT/'cpu_low_lds_campaign_preparation')
    r.write(ROOT/'low_lds_campaign_cpu_selector_audit.json',audit)
    predict,command=final.predictor(ROOT/'cpu_low_lds_campaign_baseline1193')
    originals=[prior.as_case(x) for x in r.read(ROOT/'source_results.json')]
    assert len(originals)==1193 and predict(originals)==[x['expected'] for x in originals]
    r.write(ROOT/'low_lds_baseline1193_cpu_audit.json',dict(ok=True,cpu_only=True,GPU=False,cases=1193,command=command,selector_sha256=plan.sha(plan.SELECTOR)))
    print('PHASE_PLAN_CPU_PASS',len(cases),'cases;59 pairs;42 qualification jobs; no GPU',flush=True)

def freeze():
    assert time.time()+60<r.read(ROOT/'session.json')['gpu_deadline_epoch']
    folder=ROOT/'compile/build13';stages=r.read(folder/'results.json')
    assert len(stages)==2 and all(x['rc']==0 for x in stages)
    actual=r.read(ROOT/'low_lds_build_isa_audit.json');assert actual['ok'] and actual['old_shader_count']==1754
    assert actual['benchmark_sha256']==plan.sha(plan.BENCH)
    policy=r.read(ROOT/'drafts/low_lds_n128/cpu_policy/results.json')
    assert policy['ok'] and policy['case_count']==165845
    assert policy['new_source_sha256']==plan.sha(plan.REPO/'example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args.cpp')
    assert r.read(ROOT/'drafts/low_lds_n128/cpu_policy/public_disable_equivalence.json')['ok']
    assert r.read(ROOT/'low_lds_baseline1193_cpu_audit.json')['ok']
    proposed=create();assert r.read(PLAN)==proposed
    cases=proposed['qualification_cases']+[c for p in proposed['discovery_pairs'] for c in [p['base'],p['candidate']]]
    for case in cases:plan.environment(case['env'],{})
    audit=prior.selector_check(cases,ROOT/'cpu_low_lds_campaign')
    r.write(ROOT/'low_lds_campaign_cpu_selector_audit.json',audit)
    source=r.read(folder/'source_sha256.json')
    assert all(plan.sha(plan.REPO/n)==sha for n,sha in source.items())
    old=r.read(ROOT/'frozen_plan.json');m=copy.deepcopy(old);m.pop('plan_sha256',None)
    m.update(phase='h3_low_lds_discovery',candidate_plan_sha256=proposed['sha256'],parent_manifest_sha256=old['plan_sha256'],benchmark_sha256=plan.sha(plan.BENCH),selector_sha256=plan.sha(plan.SELECTOR))
    for key in ['final_plan_sha256','regression_profile_plan_sha256','resource_profile_plan_sha256','phase_profile_plan_sha256','k64_profile_plan_sha256','n256_profile_plan_sha256','b_reuse_profile_plan_sha256','low_lds_profile_plan_sha256']:m.pop(key,None)
    deps=plan.base.dependencies();m['dependencies']['sha256'].update(deps['sha256']);m['dependencies']['ldd']=deps['ldd']
    for name in ['tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke']:
        p=plan.REPO/'build/bin'/name;m['dependencies']['sha256'][str(p)]=plan.sha(p)
    m['worktree_source_sha256'].update(source)
    for name in m['worktree_source_sha256']:m['worktree_source_sha256'][name]=plan.sha(plan.REPO/name)
    new=['low_lds_final_selection_rule.json','low_lds_campaign.py','low_lds_discovery_plan.json','low_lds_mechanism_decision.json','low_lds_build_isa_audit.json','audit_low_lds_build.py','low_lds_profiles_campaign.py','low_lds_profile_rule.json','audit_low_lds_qualification.py','analyze_low_lds_discovery.py','run_low_lds_discovery.py','low_lds_baseline1193_cpu_audit.json','drafts/low_lds_n128/build_factor.py','drafts/low_lds_n128/audit_schedule.py','drafts/low_lds_n128/cpu_policy/results.json','drafts/low_lds_n128/cpu_policy/public_disable_equivalence.json','drafts/low_lds_n128/heldout_geometry_inventory.json']
    new+= [str(p.relative_to(ROOT)) for p in ROOT.glob('*.py')]
    for name in list(m['runner_sha256'])+new:m['runner_sha256'][name]=plan.sha(ROOT/name)
    m['plan_sha256']=plan.digest(m);r.write(ROOT/'manifests'/(m['plan_sha256']+'.json'),m);r.write(ROOT/'frozen_plan.json',m)
    print('PHASE_GPU_PLAN_FROZEN',m['plan_sha256'],flush=True)

def qualify(site):
    proposed=r.read(PLAN);done=r.read(QUAL,[])
    for name in ['tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke']:
        key='low_lds_regression_'+name
        if any(x['logical_key']==key and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in done):continue
        binary=plan.REPO/'build/bin'/name
        spec=dict(kind='regression',logical_key=key,command=[str(binary)],binary=str(binary),expected_binary_sha256=plan.sha(binary),env={},regression_kind='device_args_query_test' if name.endswith('query_test') else 'device_args_smoke',purpose='low_lds_qualification')
        done.append(site.execute(spec));r.write(QUAL,done)
    for case in proposed['qualification_cases']:
        key=f'low_lds_qual_{case["ID"]}_{case["variant"]}'
        if any(x['logical_key']==key and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in done):continue
        spec=campaign.ck(case,'accuracy',key);spec.update(variant=case['variant'],purpose='low_lds_qualification')
        done.append(site.execute(spec));r.write(QUAL,done)
    assert len([x for x in done if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()])==42
    print('B_REUSE_QUALIFICATION_PASS42',flush=True)

def discover(site):
    qualified=r.read(QUAL,[])
    assert len([x for x in qualified if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() and x['ok']])==42
    completed=r.read(RESULTS,[])
    for pair in r.read(PLAN)['discovery_pairs']:
        if any(x['pair']==pair['key'] and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in completed):continue
        attempt=uuid.uuid4().hex[:12];epoch=site.epoch();jobs=[]
        for arm in ['base','candidate']:
            s=campaign.ck(pair[arm],'accuracy',f'low_lds_{pair["key"]}_{attempt}_{arm}_accuracy')
            jobs.append(site.execute(dict(s,variant=arm,attempt=attempt,pair=pair['key'],purpose='low_lds_discovery')))
        for rd in [1,2,3]:
            for arm in (['base','candidate'] if rd%2 else ['candidate','base']):
                s=campaign.ck(pair[arm],'perf',f'low_lds_{pair["key"]}_{attempt}_{arm}_r{rd}')
                jobs.append(site.execute(dict(s,variant=arm,attempt=attempt,pair=pair['key'],round=rd,purpose='low_lds_discovery')))
        assert len(jobs)==8 and all(x['ok'] and x['epoch']==epoch for x in jobs)
        aa=[x['result'] for x in jobs if x['kind']=='perf' and x['variant']=='base']
        bb=[x['result'] for x in jobs if x['kind']=='perf' and x['variant']=='candidate']
        a=statistics.median(x['median_ms'] for x in aa);b=statistics.median(x['median_ms'] for x in bb)
        row=dict(pair=pair['key'],ID=pair['ID'],shape={z:pair['base'][z] for z in ['M','N','K','G']},
            variant=pair['variant'],control=pair['control'],base_instance=pair['base']['expected'],candidate_instance=pair['candidate']['expected'],
            CK_base_ms=a,CK_candidate_ms=b,base_ms=a,candidate_ms=b,frozen_BLAS_ms=pair['base'].get('frozen_BLAS_ms'),
            route_compare=pair.get('route_compare',False),geometry_compare=pair.get('geometry_compare',False),depth_compare=pair.get('depth_compare',False),fallback=pair.get('fallback',False),
            ratio_candidate_over_base=b/a,delta_pct=100*(b/a-1),
            high_cv=any(x['cv']>.05 for x in aa+bb),base_rounds=aa,candidate_rounds=bb,
            epoch=epoch,plan_sha256=site.manifest['plan_sha256'],binary_sha256=site.manifest['benchmark_sha256'],keys=[x['key'] for x in jobs],
            accuracy_pass=True,not_final_confirmation=True)
        completed.append(row);r.write(RESULTS,completed)
        print('PHASE_DISCOVERY_PAIR_PASS',pair['key'],'delta_pct',round(row['delta_pct'],3),'highCV',row['high_cv'],flush=True)
    assert len([x for x in completed if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()])==59
    print('PHASE_DISCOVERY_COMPLETE59',flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['prepare','freeze','qualify','discover']);args=ap.parse_args();r.no_core()
    if args.stage=='prepare':prepare();return
    with r.locked():
        if args.stage=='freeze':freeze()
        else:
            site=r.Site(ROOT);assert site.manifest['phase']=='h3_low_lds_discovery'
            qualify(site) if args.stage=='qualify' else discover(site)

if __name__=='__main__':main()
