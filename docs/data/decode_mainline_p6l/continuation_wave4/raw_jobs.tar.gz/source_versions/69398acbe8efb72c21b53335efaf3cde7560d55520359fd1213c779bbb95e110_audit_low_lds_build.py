"""Verify all old shaders and actual N256 D2/D3 CFG/resources before GPU."""
from pathlib import Path
import importlib.util,mmap,re,sys
import plan,runtime as r,shader_audit,h3_isa_schedule as schedule
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('n256_panel_schedule',ROOT/'drafts/low_lds_n128/audit_schedule.py')
proof_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof_module)
schedule_proof=proof_module.audit
sys.path.insert(0,'/workspace/v7_coverage/p6d');import elf_isa as e

def main():
    folder=ROOT/'compile/build13';results=r.read(folder/'results.json')
    assert len(results)==2 and all(x['rc']==0 for x in results)
    old=r.read(folder/'reference_shaders.json');new=shader_audit.inventory(plan.BENCH)
    missing=[k for k in old['kernels'] if k not in new]
    changed=[k for k,v in old['kernels'].items() if k in new and new[k]['machine_sha256']!=v['machine_sha256']]
    assert len(old['kernels'])==1754 and not missing and not changed
    pins=r.read(folder/'source_sha256.json');assert len(pins)==25
    assert all(plan.sha(plan.REPO/n)==sha for n,sha in pins.items())
    kernels=[];proofs=[];e.ROOT=folder
    with plan.BENCH.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        fat=next(x for x in e.sections(data) if x['name']=='.hip_fatbin')
        for target,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
            if code[:4]!=b'\x7fELF':continue
            sec=e.sections(code);symbols=e.symbols(code,sec);meta=e.metadata(code,sec)
            for name,fields in meta.items():
                match=re.search(r'DecodeNnLowLdsN128KernelILi(\d+)EE',name)
                if not match:continue
                rows,depth=int(match[1]),2
                item=dict(target=target,symbol=name,depth=depth,padded_M=rows*16,VGPR=fields['.vgpr_count'],SGPR=fields['.sgpr_count'],scratch=fields.get('.private_segment_fixed_size',0),VGPR_spills=fields.get('.vgpr_spill_count',0),SGPR_spills=fields.get('.sgpr_spill_count',0),waves_per_CTA=4 if rows==1 else 8,expected_dynamic_LDS_bytes=2*(rows*1024+8192))
                assert item['scratch']==item['VGPR_spills']==item['SGPR_spills']==0
                kernels.append(item)
                if 'gfx936' not in target:continue
                tag=f'n256_actual_m{rows*16}_d{depth}';co=folder/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
                captured=e.dump(co,code,sec,symbols,meta,name,tag);assert captured['unknown_lines']==0
                proof=schedule_proof(captured,rows,depth);proof.update(symbol=name,machine_sha256=captured['sha256'],VGPR=item['VGPR']);proofs.append(proof)
    assert len(kernels)==6 and len(proofs)==3
    r.write(ROOT/'low_lds_build_isa_audit.json',dict(at=r.stamp(),ok=True,CPU_only=True,GPU=False,old_shader_count=1754,missing=missing,changed=changed,benchmark_sha256=plan.sha(plan.BENCH),kernels=kernels,proofs=proofs,not_GPU_precision_or_timing_evidence=True))
    print('LOW_LDS_ACTUAL_BUILD_AUDIT_PASS old1754_preserved/new6/CFG3',flush=True)
    for x in kernels:print('N256_RESOURCE',x['target'],x['padded_M'],x['depth'],x['VGPR'],x['expected_dynamic_LDS_bytes'],flush=True)
if __name__=='__main__':main()
