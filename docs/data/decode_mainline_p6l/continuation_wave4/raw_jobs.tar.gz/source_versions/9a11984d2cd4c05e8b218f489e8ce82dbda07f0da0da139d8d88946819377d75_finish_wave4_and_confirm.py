"""Finish one registered experiment and conditionally confirm its whole domain."""
from pathlib import Path
import datetime, fcntl, hashlib, json, os, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def main():
 with (ROOT/'wave4_finish.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  def event(**kw):
   row=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),controller_sha256=SELF,**kw)
   (ROOT/'wave4_finish_status.json').write_text(json.dumps(row,indent=2)+'\n')
   with (ROOT/'wave4_finish_events.jsonl').open('a') as out:out.write(json.dumps(row)+'\n');out.flush();os.fsync(out.fileno())
  def guard():
   assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
   assert time.time()<read(ROOT/'session.json')['deadline_epoch']
   assert not (ROOT/'user_pause.json').exists()
  def command(script,args=()):
   guard();cmd=[sys.executable,'-B','-u',str(ROOT/script),*args]
   event(state='running',command=cmd)
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL);rc=child.wait()
   event(state='passed' if rc==0 else 'stopped',script=script,rc=rc,child_pid=child.pid)
   assert rc==0,'Retain failure; no automatic restart or seed redraw'
  try:
   while True:
    guard();state=read(ROOT/'post_wave4_build_status.json')
    if state['state']=='complete':break
    assert state['state'] not in ['stopped','failed'],state
    stat=Path('/proc/929672/stat').read_text().rsplit(')',1)[1].split()
    assert stat[0]!='Z'
    event(state='waiting_registered_build_and_GPU_phase',post_pid=929672)
    time.sleep(20)
   assert read(ROOT/'wave4_controller_status.json')['state']=='complete'
   command('drafts/wave4_own_commit/commit_validated_source.py')
   command('archive_continuation_wave4.py')
   command('select_wave4_candidate.py')
   selected=read(ROOT/'wave4_candidate_selection.json')
   if not selected['eligible_for_confirmation']:
    event(state='complete_rejected_candidate',Goal_complete=False,note='Whole-policy discovery gate failed; no fresh heldout seed or adoption.');return
   if time.time()+60>=read(ROOT/'session.json')['gpu_deadline_epoch']:
    event(state='confirmation_not_started_deadline',Goal_complete=False);return
   assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json'])
   command('run_final_confirmation_wave4.py',['--proposal',str(ROOT/'wave4_candidate_proposal.json')])
   event(state='confirmation_and_report_complete',Goal_complete=False,note='Audit all deliverables and actual thresholds before any Goal completion.')
  except BaseException as error:
   event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False);raise
if __name__=='__main__':main()
