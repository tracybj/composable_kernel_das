"""Verify the one actual build, then run the finite registered GPU queue."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 with (ROOT/'post_wave4_build.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  identity=read(ROOT/'compile/build14/host_process_identity.json')['host_process']
  folder=ROOT/'compile/build14'
  def event(**fields):
   x=dict(at=stamp(),pid=os.getpid(),script_sha256=SELF,**fields)
   (ROOT/'post_wave4_build_status.json').write_text(json.dumps(x,indent=2)+'\n')
   with (ROOT/'post_wave4_build_events.jsonl').open('a') as out:out.write(json.dumps(x)+'\n');out.flush();os.fsync(out.fileno())
  def guard():
   assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
   s=read(ROOT/'session.json');assert time.time()+60<s['gpu_deadline_epoch']
   assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
  def command(name,args=()):
   guard();cmd=[sys.executable,'-B','-u',str(ROOT/name),*args]
   event(state='running',script=name,command=cmd)
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL);rc=child.wait()
   event(state='passed' if rc==0 else 'failed',script=name,child_pid=child.pid,rc=rc)
   print('POST_WAVE4_BUILD_STAGE',name,'rc',rc,flush=True)
   assert rc==0,'Finite continuation failed; no automatic restart'
  try:
   while True:
    guard();state=read(folder/'controller.json')
    if state['state']=='complete':break
    assert state['state']=='running',state
    stat=Path('/proc')/str(identity['pid'])/'stat'
    raw=stat.read_text().rsplit(')',1)[1].split()
    assert int(raw[19])==identity['start_ticks'] and raw[0]!='Z'
    event(state='verified_wait',actual_host_pid=identity['pid'],start_ticks=identity['start_ticks'],build_stage=read(folder/'live.json').get('stage'))
    time.sleep(20)
   results=read(folder/'results.json');assert len(results)==2 and all(x['rc']==0 for x in results)
   assert (folder/'completed.json').is_file()
   assert read(ROOT/'drafts/conditional_n128_wave4/cpu_policy/results.json')['ok']
   assert read(ROOT/'drafts/conditional_n128_wave4/cpu_policy/public_disable_equivalence.json')['ok']
   command('audit_wave4_build.py')
   command('wave4_campaign.py',['prepare'])
   command('run_wave4_discovery.py')
   event(state='complete',note='Four-wave actual build audited; finite qualification/discovery and profile14 complete. No adoption without whole property-domain confirmation.')
  except BaseException as error:
   event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False);raise
if __name__=='__main__':main()
