"""Apply the inspected bounded K64 overlay and build only on CPU."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
import plan,runtime as r,shader_audit
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
HERE=ROOT/'drafts/k64_integration'
def main():
 r.no_core();session=r.read(ROOT/'session.json');assert time.time()+3600<session['gpu_deadline_epoch']
 assert r.read(ROOT/'phase_controller_status.json')['state']=='complete'
 assert r.read(ROOT/'phase_archive_commit.json')['Git_blob_verified']
 assert len(r.read(ROOT/'phase_discovery_results.json'))==46
 assert r.read(ROOT/'profile_delivery_batch9.json')['captures']==10
 for name in ['k64_matched_capacity','k64_wide']:
  assert r.read(ROOT/'drafts'/name/'cpu_model_result.json')['ok']
  assert r.read(ROOT/'drafts'/name/'probe_resources.json')['ok']
 assert all(x['rc']==0 for x in r.read(HERE/'host_syntax.json'))
 check=subprocess.run([str(HERE/'selector_cpu')],capture_output=True,text=True)
 r.write(HERE/'selector_cpu_result.json',dict(rc=check.returncode,stdout=check.stdout,stderr=check.stderr,GPU=False));assert check.returncode==0
 overlay=r.read(HERE/'overlay.json');patch=HERE/'integration.patch';assert plan.sha(patch)==overlay['patch_sha256']
 for x in overlay['files']:
  p=REPO/x['path'];assert (plan.sha(p) if p.exists() else None)==x['old_sha256']
 subprocess.run(['git','apply','--check','--whitespace=error-all',str(patch)],cwd=REPO,check=True)
 folder=ROOT/'compile/build10';assert not folder.exists();assert shutil.disk_usage(ROOT).free>=20*1024**3
 folder.mkdir(parents=True);backup=folder/'previous';backup.mkdir()
 old=r.read(ROOT/'frozen_plan.json');assert old['phase']=='h3_phase_discovery'
 assert plan.sha(plan.BENCH)==old['benchmark_sha256']=='ee64d307fb6f506ff84326b3b2537351aee0c13ca1b1cce89604ebc302454d1d'
 for name,sha in old['worktree_source_sha256'].items():
  assert plan.sha(REPO/name)==sha
  q=backup/'source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/name,q)
 shutil.copy2(ROOT/'frozen_plan.json',backup/'frozen_plan.json')
 names=['tile_example_grouped_gemm_device_args_benchmark','tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke','tile_example_grouped_gemm_selector_test','tile_example_grouped_gemm_decode_depth8_selector_test','tile_example_grouped_gemm_decode_mainline_selector_test']
 for name in names:shutil.copy2(REPO/'build/bin'/name,backup/name)
 kernels=shader_audit.inventory(plan.BENCH);assert len(kernels)==1720
 r.write(folder/'reference_shaders.json',dict(binary_sha256=plan.sha(plan.BENCH),kernels=kernels))
 subprocess.run(['git','apply','--whitespace=error-all',str(patch)],cwd=REPO,check=True)
 for x in overlay['files']:assert plan.sha(REPO/x['path'])==x['new_sha256']
 sources=dict(old['worktree_source_sha256'])
 sources.update({x['path']:x['new_sha256'] for x in overlay['files']})
 for name in sources:sources[name]=plan.sha(REPO/name)
 assert len(sources)==24
 r.write(folder/'source_sha256.json',sources)
 for name,s in sources.items():
  q=folder/'compiled_sources'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/name,q);assert plan.sha(q)==s
 r.write(ROOT/'active_build.json',dict(folder='compile/build10',at=r.stamp(),script='build_k64_factor.py',phase='compile_K64D2_w4_w8',GPU=False))
 os.sched_setaffinity(0,{124,125,126,127});os.nice(10)
 commands=[['cmake','-S',str(REPO),'-B',str(REPO/'build'),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],['cmake','--build',str(REPO/'build'),'--target',*names,'-j4']]
 results=[]
 r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='running',script_sha256=plan.sha(__file__),GPU=False))
 try:
  for i,cmd in enumerate(commands):
   assert time.time()+60<session['gpu_deadline_epoch']
   assert all(plan.sha(REPO/n)==s for n,s in sources.items())
   memory=int(re.search(r'MemAvailable:\s+(\d+)',Path('/proc/meminfo').read_text())[1]);assert memory>=96*1024*1024
   rec=dict(at=r.stamp(),command=cmd,GPU=False,stage=i);r.write(folder/f'{i}_command.json',rec);start=time.monotonic()
   env=os.environ.copy();env.update(HIP_VISIBLE_DEVICES='4',CUDA_VISIBLE_DEVICES='4')
   with (folder/f'{i}_build.log').open('x') as log:
    child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
    rec['pid']=child.pid;r.write(folder/'live.json',rec);rc=child.wait()
   rec.update(rc=rc,seconds=time.monotonic()-start,finished_at=r.stamp());results.append(rec);r.write(folder/'results.json',results)
   print('K64_BUILD_STAGE',i,'rc',rc,'seconds',rec['seconds'],flush=True)
   assert rc==0,'CPU build failed; no automatic retry'
  assert all(plan.sha(REPO/n)==s for n,s in sources.items())
  r.write(folder/'completed.json',dict(at=r.stamp(),CPU_only=True,GPU=False,benchmark_sha256=plan.sha(plan.BENCH),source_sha256=sources))
  r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='complete',GPU=False))
  print('K64_FACTOR_CPU_BUILD_PASS',plan.sha(plan.BENCH),flush=True)
 except BaseException as error:
  r.write(folder/'controller.json',dict(at=r.stamp(),pid=os.getpid(),state='stopped',GPU=False,error=str(error)));raise
if __name__=='__main__':main()
