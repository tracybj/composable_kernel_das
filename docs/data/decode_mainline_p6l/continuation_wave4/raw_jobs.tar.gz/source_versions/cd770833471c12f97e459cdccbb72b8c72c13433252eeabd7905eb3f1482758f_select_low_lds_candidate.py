"""Apply the preregistered whole-policy selection rule; no GPU or seed draw."""
from pathlib import Path
import json,math,statistics,hashlib
import runtime as r,plan
ROOT=Path(__file__).resolve().parent

def main():
    assert r.read(ROOT/'post_low_lds_build_status.json')['state']=='complete'
    assert r.read(ROOT/'low_lds_controller_status.json')['state']=='complete'
    assert r.read(ROOT/'low_lds_source_commit.json')['untracked10_bytes_verified']
    assert (ROOT/'profile_delivery_batch13.json').is_file()
    rule=r.read(ROOT/'low_lds_final_selection_rule.json')
    rows=r.read(ROOT/'low_lds_discovery_results.json');assert len(rows)==59
    assert r.read(ROOT/'low_lds_discovery_analysis.json')['complete_phase']
    original=r.read(ROOT/'source_results.json')
    scope=[x for x in original if 1<=x['M']<=64 and 1024<=x['N']<=4096 and x['N']%128==0 and
           2048<=x['K']<=8192 and x['K']%128==0 and 1<=x['G']<=32 and (x['M']>=17 or x['K']>=6144)]
    assert len(scope)==rule['scope_original_count']==108
    ids={x['ID'] for x in scope};reports=[]
    for item in rule['policies']:
        selected=[x for x in rows if not x['control'] and x['variant']==item['name'] and x['ID'] in ids]
        assert selected
        loss=[]
        for x in selected:
            ratios=[b['median_ms']/a['median_ms'] for a,b in zip(x['base_rounds'],x['candidate_rounds'])]
            if not x['high_cv'] and all(v>1.02 for v in ratios):loss.append(x['ID'])
        gm=math.exp(statistics.mean(math.log(x['ratio_candidate_over_base']) for x in selected))
        reports.append(dict(**item,representatives=len(selected),known_three_round_losses=loss,
            geometric_candidate_over_base=gm,high_cv=sum(x['high_cv'] for x in selected),
            point_improve_ge5=sum(x['delta_pct']<=-5 for x in selected),eligible_for_confirmation=not loss and gm<1))
    viable=[x for x in reports if x['eligible_for_confirmation']]
    chosen=min(viable,key=lambda x:(x['geometric_candidate_over_base'],x['name']!='pure')) if viable else None
    report=dict(at=r.stamp(),rule_sha256=plan.sha(ROOT/'low_lds_final_selection_rule.json'),policies=reports,
        chosen_policy=chosen,not_performance_acceptance=True,accepted_stable50=0,accepted_attributable30=0,
        new_heldout_seed_drawn=False,scope_originals=108,scope_weak_originals=73)
    r.write(ROOT/'low_lds_candidate_selection.json',report)
    if chosen:
        P=plan.PREFIX
        proposal=dict(mechanistic_reason='Low-LDS K32/D2 full-M cooperative pipeline; fixed operator-property policy selected over identical in-scope representatives. Whole-domain independent acceptance remains required.',
            evidence_results=str(ROOT/'low_lds_discovery_results.json'),evidence_sha256=plan.sha(ROOT/'low_lds_discovery_results.json'),
            evidence_plan=str(ROOT/'low_lds_discovery_plan.json'),evidence_plan_sha256=plan.sha(ROOT/'low_lds_discovery_plan.json'),
            selection_rule=str(ROOT/'low_lds_final_selection_rule.json'),selection_rule_sha256=report['rule_sha256'],
            families=dict(main=dict(candidate_ids=chosen['candidate_ids'],env={
                P+'ENABLE_BF16_NN_DECODE_MAINLINE':'1',P+'DISABLE_BF16_NN_DECODE_MAINLINE':'0',
                P+'BF16_NN_DECODE_MAINLINE_VARIANT':str(chosen['final_variant']),
                P+'ENABLE_BF16_NN_DECODE_FAST_POLICY':'1',P+'DISABLE_BF16_NN_DECODE_FAST_POLICY':'0'})))
        target=ROOT/'low_lds_candidate_proposal.json'
        if target.exists():assert r.read(target)==proposal
        else:r.write(target,proposal)
    print('LOW_LDS_POLICY_SELECTION',json.dumps(report,ensure_ascii=False),flush=True)
    print('NO_GPU_OR_HELDOUT_DRAW',flush=True)

if __name__=='__main__':main()
