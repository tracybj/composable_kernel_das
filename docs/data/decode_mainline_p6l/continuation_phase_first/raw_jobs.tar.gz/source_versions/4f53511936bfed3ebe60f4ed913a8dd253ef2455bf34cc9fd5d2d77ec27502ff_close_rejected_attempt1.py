"""Audit and close the intentionally rejected trial; never clears environment faults."""
from pathlib import Path
import fcntl,json,os,shutil,subprocess,sys,time
import plan,runtime as r
ROOT=Path(__file__).resolve().parent
REASON='PERFORMANCE_CANDIDATE_REJECTED_AFTER_ORIGINAL_MAIN_DOMAIN'

def main():
    proof=r.read(ROOT/'old_controller_terminal_observation.json')
    assert proof['final_71690_terminal'] and proof['watcher_61274_terminal'] and proof['rejection_26069_terminal']
    status=r.read(ROOT/'final_controllers/20261112T131919_d428f251/status.json')
    assert status['state']=='stopped'
    try:os.kill(status['pid'],0)
    except ProcessLookupError:pass
    else:raise RuntimeError('Original controller still alive')
    with (ROOT/'final_controller.lock').open('a') as first,(ROOT/'regression_diagnosis_controller.lock').open('a') as second,r.locked():
        fcntl.flock(first,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(second,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert not any((ROOT/n).exists() for n in ['environment_recovery_required.json','user_pause.json'])
        marker=r.read(ROOT/'gpu_stop.json');assert marker['reason']==REASON and marker['environment_failure'] is False
        folder=ROOT/'final_attempts/attempt_1';data=r.read(folder/'plan.json');rows=r.read(folder/'results.json')
        report=r.read(folder/'report.json');assert not report['complete'] and not report['goal_performance_pass']
        originals={x['key'] for x in data['pairs'] if x['family']=='main' and x['original']}
        measured={x['pair']:x for x in rows};assert len(originals)==166 and originals<=set(measured)
        bad=[measured[k] for k in originals if measured[k]['point_median_regression_over_2pct'] and not measured[k]['high_cv'] and all(z>1.02 for z in measured[k]['paired_candidate_over_base'])]
        assert bad
        subprocess.run([sys.executable,'-B','-u',str(ROOT/'audit_final_snapshot.py')],check=True)
        audits=sorted((ROOT/'readonly_progress').glob('*/audit.json'));raw=r.read(audits[-1]);assert raw['ok'] and raw['audited_pairs']==len(rows)
        history=ROOT/'controller_history/rejected_attempt1';assert not history.exists();history.mkdir(parents=True)
        preserve=['regression_profile_campaign.py','after_confirmation_diagnosis.py','h3_regression_profile_rule.json',
            'attempt1_rejection_management_addendum.json','gpu_stop.json','post_final_regression_diagnosis.json','attempt1_rejection_status.json','frozen_plan.json']
        for name in preserve:shutil.copy2(ROOT/name,history/name)
        jobs=[json.loads(s) for s in (ROOT/'jobs.jsonl').read_text().splitlines()]
        recorded=[x for x in jobs if x['plan_sha256']==r.read(ROOT/'frozen_plan.json')['plan_sha256']]
        paired={key for row in rows for key in row['keys']}
        unpaired=[x['key'] for x in recorded if x['key'] not in paired and x['kind'] in ['accuracy','perf']]
        missing=[dict(key=x['key'],family=x['family'],original=x['original'],shape={z:x['base'][z] for z in ['M','N','K','G']}) for x in data['pairs'] if x['key'] not in measured]
        closure=dict(at=r.stamp(),whole_family_rejected=True,original_main_complete=166,
            original_planned_pairs=347,complete_pairs=len(rows),definite_regressions=len(bad),
            rejected_original_ids=sorted(x['ID'] for x in bad),unmeasured_pairs=missing,unpaired_raw_keys=unpaired,
            original_plan_sha256=data['sha256'],results_sha256=plan.sha(folder/'results.json'),report_sha256=plan.sha(folder/'report.json'),
            raw_audit=str(audits[-1]),raw_audit_sha256=plan.sha(audits[-1]),
            reason=REASON,environment_failure=False,epoch_unchanged=r.read(ROOT/'environment_epoch.json')['id'],
            original_marker_sha256=plan.sha(ROOT/'gpu_stop.json'),management_addendum_sha256=plan.sha(ROOT/'attempt1_rejection_management_addendum.json'),
            short_confirmation='Unmeasured; no adoption and no fabricated negative result',adopted=False,accepted_stable50=0,accepted_cross30=0)
        r.write(ROOT/'attempt1_closure.json',closure);r.write(history/'closure.json',closure)
        # Amend only the diagnostic prerequisite after all old controllers ended.
        script=ROOT/'regression_profile_campaign.py';text=script.read_text()
        old="    assert report and report['complete'] and len(rows)==len(data['pairs'])==347"
        assert text.count(old)==1
        text=text.replace(old,"    closure=r.read(ROOT/'attempt1_closure.json')\n    assert closure['whole_family_rejected'] and closure['original_main_complete']==166\n    assert closure['results_sha256']==plan.sha(folder/'results.json')\n    assert not report['complete'] and len(data['pairs'])==347\n    expected={x['key'] for x in data['pairs'] if x['original'] and x['family']=='main'}\n    assert len(expected)==166 and expected<={x['pair'] for x in rows}")
        text=text.replace('正式347对全部结束后采集。','原候选完成全部166条原表主线后整组否定，按已记录的研究收束修订采集；原347计划中未测项及所有在途记录完整保留。')
        text=text.replace("['regression_profile_campaign.py','after_confirmation_diagnosis.py',RULE.name,REGPLAN.name]", "['regression_profile_campaign.py','after_confirmation_diagnosis.py','run_batch7_closed.py',RULE.name,REGPLAN.name]")
        script.write_text(text)
        rule=r.read(ROOT/'h3_regression_profile_rule.json');rule.update(requires_complete_current_confirmation=None,
            requires_closed_rejected_original_main=166,diagnostic_prerequisite_amendment_sha256=closure['management_addendum_sha256'],
            original_rule_preserved=str(history/'h3_regression_profile_rule.json'),no_gpu_before_full_final_and_locks=False,
            no_gpu_before_closed_trial_and_released_locks=True)
        r.write(ROOT/'h3_regression_profile_rule.json',rule)
        # Move only the exact deliberate performance marker, after audit+archive.
        assert r.read(ROOT/'gpu_stop.json')==marker
        (ROOT/'gpu_stop.json').rename(history/'intentional_performance_stop_closed.json')
        print('REJECTED_ATTEMPT1_CLOSED_AUDITED',len(rows),'pairs; original main166; no adoption; epoch unchanged',flush=True)

if __name__=='__main__':main()
