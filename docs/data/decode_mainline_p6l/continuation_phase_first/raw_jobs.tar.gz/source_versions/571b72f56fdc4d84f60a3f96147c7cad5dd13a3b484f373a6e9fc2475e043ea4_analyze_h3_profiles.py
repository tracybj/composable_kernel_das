"""Reuse checked counter/ELF readers in a separate namespace for H1 captures."""
from pathlib import Path
import json
import analyze_profiles as counters,extract_profile_isa as isa,runtime as r
import h3_isa_schedule as schedule
ROOT=Path(__file__).resolve().parent

def main():
 captures=r.read(ROOT/'h3_profiles.json',[]);folder=ROOT/'h3_profile_analysis';folder.mkdir(exist_ok=True)
 assert captures and all(x['stage']=='sqtt' for x in captures)
 # Arm names include the variant so repeated IDs never overwrite another ISA.
 r.write(folder/'profiles.json',captures)
 counters.ROOT=folder;counters.main();isa.ROOT=folder;isa.main()
 records=r.read(folder/'profile_isa.json');proofs=[]
 for item in records:
  if 'DecodeNnCooperativeKernel' not in item['symbol']:continue
  proof=schedule.audit_one(item);proofs.append(dict(ID=item['ID'],arm=item['arm'],**proof))
  item['layout_backward_candidates']=item['main_loop_candidates']
  item['main_loop_candidates']=[proof['main_loop']]
  item['instruction_anchors']=proof['instruction_anchors']
  item['validated_static_lookahead']=dict(operand_banks=3,two_stage_matches=proof['two_stage_lookahead_register_matches'],no_immediate_lg_wait=True,not_timing_proof=True)
 r.write(folder/'profile_isa.json',records)
 r.write(folder/'h3_static_schedule.json',dict(kernels=proofs,note='True cyclic CFG regions exclude tail-layout backward jumps. Static dependencies are verified; performance still requires formal pairs and SQTT.'))
 print('H3_COUNTER_AND_ISA_AUDIT_PASS',len(captures),flush=True)

if __name__=='__main__':main()
