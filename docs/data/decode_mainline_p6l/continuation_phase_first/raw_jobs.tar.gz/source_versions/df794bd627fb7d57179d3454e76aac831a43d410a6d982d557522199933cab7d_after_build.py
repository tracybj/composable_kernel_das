"""One serial continuation of the already-running build, never a rebuild/retry."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SELF_SHA=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
BUILD_INFO=json.loads((ROOT/'active_build.json').read_text())
BUILD_ROOT=ROOT/BUILD_INFO['folder']

def read(path):return json.loads(Path(path).read_text())
def write(value):
 p=ROOT/'postbuild_controller.json';tmp=p.with_suffix('.tmp')
 tmp.write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),script_sha256=SELF_SHA,build_exec_session=BUILD_INFO['exec_session'],build_folder=BUILD_INFO['folder'],**value),indent=2));tmp.replace(p)

def guard():
 assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF_SHA
 assert read(ROOT/'active_build.json')==BUILD_INFO,'Active build control changed; no mixed-stage continuation'
 if (ROOT/'gpu_stop.json').exists() or (ROOT/'environment_recovery_required.json').exists() or (ROOT/'user_pause.json').exists():
  raise RuntimeError('Stop/recovery/pause marker; no automatic next stage')
 if time.time()+60>=read(ROOT/'session.json')['gpu_deadline_epoch']:
  raise RuntimeError('Original GPU/new-experiment deadline reached; no new stage')

def command(argv,label):
 guard();write(dict(state='stage_running',stage=label,command=argv));print('POSTBUILD_STAGE_START',label,flush=True)
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL)
 rc=child.wait();write(dict(state='stage_passed' if rc==0 else 'stage_failed',stage=label,child_pid=child.pid,rc=rc))
 if rc:raise RuntimeError(f'{label} failed rc={rc}; no retry or following GPU work')

def main():
 write(dict(state='waiting_for_original_build',next_stage='CPU shader/ISA audit, then freeze, qualify, representatives'))
 while True:
  guard();p=BUILD_ROOT/'results.json'
  try:stages=read(p)
  except (FileNotFoundError,json.JSONDecodeError):stages=[]
  if len(stages)==2:
   if not all(x['rc']==0 for x in stages):raise RuntimeError('Original build failed; no automatic rebuild')
   break
  time.sleep(15)
 binary='/workspace/composable_kernel/build/bin/tile_example_grouped_gemm_device_args_benchmark'
 command([sys.executable,'-B',str(ROOT/'shader_audit.py'),'compare','--output',str(BUILD_ROOT/'shader_preservation.json')],'preserve_all_old_shaders')
 command([sys.executable,'-B',str(ROOT/'audit_mainline_isa.py'),binary,'--tag',BUILD_ROOT.name],'actual_new_shader_isa')
 for name in ['tile_example_grouped_gemm_selector_test','tile_example_grouped_gemm_decode_depth8_selector_test','tile_example_grouped_gemm_decode_mainline_selector_test']:
  command(['/workspace/composable_kernel/build/bin/'+name],name)
 for stage in ['freeze','qualify','representatives']:
  command([sys.executable,'-B','-u',str(BASE/'run_stage.py'),stage,'--script','mainline_campaign.py'],stage)
 write(dict(state='complete',note='Discovery finished; performance Goal still requires independent domain confirmation and acceptance'))
 print('POSTBUILD_DISCOVERY_SEQUENCE_PASS',flush=True)

if __name__=='__main__':
 try:main()
 except Exception as ex:
  write(dict(state='stopped',error=repr(ex)));raise
