"""CPU-only cost of exact current policy reader and four legacy flag reads.
No HIP headers/runtime linked, no GPU initialization or GPU command is issued.
"""
from pathlib import Path
import hashlib,json,statistics,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
sys.path.insert(0,str(ROOT))
import plan

def main():
 folder=ROOT/'cpu_host_policy';folder.mkdir(exist_ok=False)
 capi=REPO/'example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args.cpp'
 header=REPO/'include/ck_tile/ops/gemm/grouped_gemm_bw_family_selected.hpp'
 provider=REPO/'example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_shared_device_args.cpp'
 source=capi.read_text();start=source.index('    const auto disabled = source->policy_disable_flags;');end=source.index('    return ck_tile::is_valid_grouped_gemm_problem(problem)',start);reader=source[start:end]
 helpers=header.read_text();helpers=helpers[helpers.index('inline bool ck_tile_hcu_grouped_gemm_bf16_nn_fixed_srd_lds8_enabled()'):helpers.index('// The v7 device-args entries.')]
 flags=provider.read_text();flags=flags[flags.index('CK_TILE_HOST bool decode_shared_flag('):flags.index('template<int Rows>\nCK_TILE_HOST int dispatch_decode_shared_flags')].replace('CK_TILE_HOST ','')
 preamble='''#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <iostream>
#include <vector>
#include "ck_tile/ops/gemm/grouped_gemm_selector.hpp"
#include "ck_tile/ops/gemm/grouped_gemm_device_args.h"
#define CK_TILE_GROUPED_GEMM_DEVICE_ARGS_HAS_DECODE_BF16 1
#define CK_TILE_GROUPED_GEMM_DEVICE_ARGS_HAS_GFX936_PROMOTED 1
#define CK_TILE_GROUPED_GEMM_DEVICE_ARGS_HAS_V7_V8_BF16 1
'''
 body='''
__attribute__((noinline)) ck_tile::GroupedGemmSelectorPolicy read_exact_policy()
{
    ck_tile_hcu_grouped_gemm_problem_v1 record{};
    const auto* source=&record;
    ck_tile::GroupedGemmSelectorPolicy policy{};
'''+reader+'''    return policy;
}
__attribute__((noinline)) unsigned four_flags()
{
    const bool early=decode_shared_flag("CK_TILE_GROUPED_GEMM_ENABLE_BF16_NN_DECODE_SHARED_EARLY_B","CK_TILE_GROUPED_GEMM_DISABLE_BF16_NN_DECODE_SHARED_EARLY_B");
    const bool x=decode_shared_flag("CK_TILE_GROUPED_GEMM_ENABLE_BF16_NN_DECODE_SHARED_XOR_A","CK_TILE_GROUPED_GEMM_DISABLE_BF16_NN_DECODE_SHARED_XOR_A");
    return unsigned(early)+2*unsigned(x);
}
volatile std::uint64_t keep=0;
int main()
{
    constexpr int iterations=20000;
    auto p=read_exact_policy();
    std::cout<<"POLICY "<<p.enable_bf16_nn_decode_mainline<<" "<<p.bf16_nn_decode_mainline_variant<<" "<<p.enable_bf16_nn_decode_short<<" "<<p.bf16_nn_decode_short_variant<<" "<<four_flags()<<"\\n";
    for(int warm=0;warm<1000;++warm){p=read_exact_policy();asm volatile("" :: "m"(p):"memory");}
    for(int round=0;round<11;++round)
    {
        auto t=std::chrono::steady_clock::now();
        for(int i=0;i<iterations;++i){p=read_exact_policy();asm volatile("" :: "m"(p):"memory");}
        auto u=std::chrono::steady_clock::now();
        for(int i=0;i<iterations;++i){const unsigned v=four_flags();asm volatile("" :: "r"(v):"memory");}
        auto v=std::chrono::steady_clock::now();
        for(int i=0;i<iterations;++i){asm volatile("" ::: "memory");}
        auto w=std::chrono::steady_clock::now();
        std::cout<<"ROUND "<<round<<" "<<std::chrono::duration<double,std::nano>(u-t).count()/iterations<<" "<<std::chrono::duration<double,std::nano>(v-u).count()/iterations<<" "<<std::chrono::duration<double,std::nano>(w-v).count()/iterations<<"\\n";
    }
    return 0;
}
'''
 p=folder/'host_policy.cpp';p.write_text(preamble+helpers+flags+body);binary=folder/'host_policy'
 cmd=['g++','-O3','-std=c++17','-I'+str(REPO/'include'),str(p),'-o',str(binary)];subprocess.run(cmd,check=True,capture_output=True,text=True)
 linked=subprocess.check_output(['ldd',str(binary)],text=True);assert not any(x in linked.lower() for x in ['libamdhip','libhsa','libhipblas','libgroupgemm'])
 source_rows={x['ID']:x for x in json.loads((ROOT/'source_results.json').read_text())};records=[]
 for ident in [621,1072,76,257]:
  for arm in ['baseline','legacy','direct']:
   env=dict(source_rows[ident]['env']);main=ident in [621,1072];stem='MAINLINE' if main else 'SHORT'
   if arm!='baseline':
    env.update({plan.PREFIX+'ENABLE_BF16_NN_DECODE_'+stem:'1',plan.PREFIX+'DISABLE_BF16_NN_DECODE_'+stem:'0',plan.PREFIX+'BF16_NN_DECODE_'+stem+'_VARIANT':str((4 if main else 2) if arm=='legacy' else (8 if main else 3))})
    for mode in ['EARLY_B','XOR_A']:
     value=arm=='legacy' and (main or mode=='XOR_A')
     env[plan.PREFIX+'ENABLE_BF16_NN_DECODE_SHARED_'+mode]=str(int(value));env[plan.PREFIX+'DISABLE_BF16_NN_DECODE_SHARED_'+mode]='0'
   out=subprocess.run([str(binary)],env=plan.environment(env),check=True,capture_output=True,text=True)
   (folder/f'id{ident}_{arm}.log').write_text(out.stdout)
   rows=[list(map(float,line.split()[2:])) for line in out.stdout.splitlines() if line.startswith('ROUND ')]
   assert len(rows)==11
   rec=dict(ID=ident,arm=arm,env=env,round_ns=rows,policy_reader_median_ns=statistics.median(x[0] for x in rows),four_provider_flags_median_ns=statistics.median(x[1] for x in rows),empty_loop_median_ns=statistics.median(x[2] for x in rows),policy_identity=out.stdout.splitlines()[0]);records.append(rec)
   print('CPU_HOST_POLICY',ident,arm,round(rec['policy_reader_median_ns'],2),round(rec['four_provider_flags_median_ns'],2),flush=True)
 result=dict(cpu_only=True,no_gpu_runtime_linked=True,source_sha256={str(x.relative_to(REPO)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [capi,header,provider]},cpp_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),command=cmd,ldd=linked,records=records,limitations='Exact policy reader body only, no GPU initialization/arch detection/API validation/launch/driver cost; environment scans and CPU contention vary. Four-flags timing is a standalone CPU estimate, not its critical-path cost in a HIP event interval. No performance/adoption claim and no replacement of registered GPU A/B.')
 (folder/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('CPU_HOST_POLICY_DIAGNOSTIC_PASS',len(records),flush=True)
if __name__=='__main__':main()
