"""Recorded CPU-only H3 build under the original session deadline."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')

def main():
    session=json.loads((ROOT/'session.json').read_text())
    assert time.time()+60 < session['gpu_deadline_epoch']
    folder=ROOT/'compile/build7'
    folder.mkdir(exist_ok=False)
    names=list(json.loads((ROOT/'compile/build3/source_sha256.json').read_text()))
    names += ['include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_shared_tuned.hpp',
      'include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_cooperative.hpp',
      'example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_cooperative_device_args.cpp']
    pins={n:hashlib.sha256((REPO/n).read_bytes()).hexdigest() for n in names}
    (folder/'source_sha256.json').write_text(json.dumps(pins,indent=2)+'\n')
    commands=[['cmake','-S',str(REPO),'-B',str(REPO/'build')],
      ['cmake','--build',str(REPO/'build'),'--target',
       'tile_example_grouped_gemm_device_args_benchmark',
       'tile_example_grouped_gemm_device_args_query_test',
       'tile_example_grouped_gemm_device_args_smoke',
       'tile_example_grouped_gemm_selector_test',
       'tile_example_grouped_gemm_decode_depth8_selector_test',
       'tile_example_grouped_gemm_decode_mainline_selector_test','-j4']]
    results=[]
    for i,cmd in enumerate(commands):
        assert time.time()+60 < session['gpu_deadline_epoch']
        assert all(hashlib.sha256((REPO/n).read_bytes()).hexdigest()==s for n,s in pins.items())
        item=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,gpu=False)
        (folder/f'{i}_command.json').write_text(json.dumps(item,indent=2)+'\n')
        start=time.monotonic()
        with (folder/f'{i}_build.log').open('x') as f:
            child=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
            item['pid']=child.pid
            (folder/'live.json').write_text(json.dumps(item,indent=2)+'\n')
            rc=child.wait()
        item.update(rc=rc,seconds=time.monotonic()-start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        results.append(item)
        (folder/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        print('H3_FACTORS_BUILD_STAGE',i,'rc',rc,'seconds',item['seconds'],flush=True)
        if rc:raise SystemExit(rc)
    assert all(hashlib.sha256((REPO/n).read_bytes()).hexdigest()==s for n,s in pins.items())
    print('H3_FACTORS_BUILD_PASS',flush=True)

if __name__=='__main__':main()
