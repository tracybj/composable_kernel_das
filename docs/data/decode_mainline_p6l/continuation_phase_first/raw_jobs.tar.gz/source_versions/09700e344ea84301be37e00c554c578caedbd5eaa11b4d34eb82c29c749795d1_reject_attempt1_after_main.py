"""Close an already rejected candidate after every original main shape finishes.

CPU control only: no signals, GPU query, source edit, or data rewriting. The
existing between-job stop gate lets the current GPU process finish naturally.
"""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,time
ROOT=Path(__file__).resolve().parent
WATCHED=ROOT/'final_controllers/20261112T131919_d428f251/status.json'
PID=333614
REASON='PERFORMANCE_CANDIDATE_REJECTED_AFTER_ORIGINAL_MAIN_DOMAIN'

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def alive():
    try:os.kill(PID,0);return True
    except ProcessLookupError:return False

def main():
    lock=(ROOT/'attempt1_rejection_controller.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    addendum=ROOT/'attempt1_rejection_management_addendum.json';fixed=sha(addendum)
    data=read(ROOT/'final_attempts/attempt_1/plan.json')
    expected={x['key'] for x in data['pairs'] if x['family']=='main' and x['original']}
    assert len(expected)==166 and data['sha256']==read(addendum)['original_plan_sha256']
    assert read(WATCHED)['pid']==PID and alive()
    def event(**extra):
        item=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),
            watched_pid=PID,addendum_sha256=fixed,gpu=False,**extra)
        path=ROOT/'attempt1_rejection_status.json';tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps(item,indent=2)+'\n');tmp.replace(path)
        with (ROOT/'attempt1_rejection_events.jsonl').open('a') as out:out.write(json.dumps(item)+'\n');out.flush();os.fsync(out.fileno())
    event(state='waiting_for_original_main_domain')
    print('REJECTION_CONTROLLER_WAITING_FOR_ORIGINAL_MAIN166',PID,flush=True)
    while True:
        assert sha(addendum)==fixed
        assert time.time()<read(ROOT/'session.json')['gpu_deadline_epoch']
        assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json']),'Preserve an existing stop/environment event'
        state=read(WATCHED);assert state['pid']==PID
        if state['state']!='running' or state.get('stage')!='run' or not alive():
            event(state='stopped_without_control_change',original_state=state)
            return
        rows=read(ROOT/'final_attempts/attempt_1/results.json');finished={x['pair'] for x in rows}
        if expected<=finished:
            main=[x for x in rows if x['pair'] in expected]
            failures=[x for x in main if x['point_median_regression_over_2pct'] and not x['high_cv'] and all(v>1.02 for v in x['paired_candidate_over_base'])]
            assert len(main)==166 and failures
            assert all(x['candidate_instance']==6023 and x['epoch']==data['epoch'] and x['binary_sha256']==data['benchmark_sha256'] for x in main)
            marker=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason=REASON,
                original_main_completed=166,complete_pairs=len(rows),original_planned_pairs=347,
                main_definite_regressions=len(failures),adoption=False,performance_goal_complete=False,
                epoch=data['epoch'],plan_sha256=data['sha256'],addendum_sha256=fixed,
                environment_failure=False,in_flight_policy='Let current command finish; existing gate blocks the next submission')
            target=ROOT/'gpu_stop.json';assert not target.exists();temp=target.with_suffix('.reject.tmp')
            temp.write_text(json.dumps(marker,indent=2)+'\n');temp.replace(target)
            event(state='intentional_rejection_gate_written',marker=marker)
            print('REJECTED_AFTER_ORIGINAL_MAIN166',len(rows),'complete pairs; current GPU command may finish naturally',flush=True)
            return
        event(state='waiting_for_original_main_domain',complete_original_main=len(expected&finished),complete_pairs=len(rows))
        time.sleep(5)

if __name__=='__main__':main()
