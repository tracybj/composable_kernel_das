"""Prepare a detached CPU-only source/build tree without touching live inputs."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
ISO=ROOT/'isolated_resource_build'
SRC=ISO/'source';BUILD=ISO/'build'

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def command(args,folder):
    result=subprocess.run(args,capture_output=True,text=True,check=False)
    (folder/'command.json').write_text(json.dumps(dict(command=args,rc=result.returncode),indent=2)+'\n')
    (folder/'run.log').write_text(result.stdout+result.stderr)
    assert result.returncode==0,(args,result.stdout[-3000:],result.stderr[-3000:])
    return result.stdout

def main():
    assert time.time()+60<read(ROOT/'session.json')['gpu_deadline_epoch']
    assert (ROOT/'h3_resource_isolated_cpu_build_addendum.json').exists()
    assert not ISO.exists();ISO.mkdir();manifest=read(ROOT/'frozen_plan.json')
    assert manifest['phase']=='final_confirmation'
    assert sha(REPO/'build/bin/tile_example_grouped_gemm_device_args_benchmark')==manifest['benchmark_sha256']
    for name,expected in manifest['worktree_source_sha256'].items():assert sha(REPO/name)==expected
    for name,expected in manifest['runner_sha256'].items():assert sha(ROOT/name)==expected
    head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    staged=subprocess.check_output(['git','-C',str(REPO),'diff','--cached','--raw'])
    status=subprocess.check_output(['git','-C',str(REPO),'status','--porcelain=v1','-z','--untracked-files=all'])
    modified=[]
    for entry in status.split(b'\0'):
        if not entry:continue
        assert b'R' not in entry[:2] and b'C' not in entry[:2]
        modified.append(entry[3:].decode())
    initial=read(ROOT/'initial_files_sha256.json');assert set(modified)<=set(initial)
    setup=ISO/'setup';setup.mkdir()
    command(['git','-C',str(REPO),'worktree','add','--detach',str(SRC),head],setup)
    copied={}
    for name in sorted(set(modified)|set(manifest['worktree_source_sha256'])):
        source=REPO/name;target=SRC/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target);assert sha(source)==sha(target);copied[name]=sha(source)
    patch=ROOT/'drafts/asymmetric_resource_factor/resource_integration.patch'
    patchlog=ISO/'patch';patchlog.mkdir()
    command(['git','-C',str(SRC),'apply','--whitespace=error-all',str(patch)],patchlog)
    labels=[]
    for name,old in [
        ('gemm_pipeline_decode_nn_cooperative_compact.hpp','// ISOLATED, UNCOMPILED DRAFT. This is not included by a benchmark/provider.'),
        ('gemm_pipeline_decode_nn_cooperative_wide.hpp','// ISOLATED UNCOMPILED DRAFT: no provider references this header.')]:
        p=SRC/'include/ck_tile/ops/gemm/pipeline'/name;before=sha(p);text=p.read_text();assert text.count(old)==1
        p.write_text(text.replace(old,'// Experimental resource factor; selected only through explicit decode policy.',1))
        labels.append(dict(path=str(p.relative_to(SRC)),before=before,after=sha(p),comments_only=True))
    BUILD.mkdir();cache=(REPO/'build/CMakeCache.txt').read_text()
    cache=cache.replace(str(REPO/'build'),str(BUILD)).replace(str(REPO),str(SRC))
    (BUILD/'CMakeCache.txt').write_text(cache)
    overlay=ROOT/'drafts/asymmetric_resource_factor/provider_overlay'
    names=set(manifest['worktree_source_sha256'])|{str(p.relative_to(overlay)) for p in overlay.rglob('*') if p.is_file()}
    pins={name:sha(SRC/name) for name in sorted(names)}
    for name,expected in manifest['worktree_source_sha256'].items():assert sha(REPO/name)==expected
    assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==head
    assert subprocess.check_output(['git','-C',str(REPO),'diff','--cached','--raw'])==staged
    assert sha(REPO/'build/bin/tile_example_grouped_gemm_device_args_benchmark')==manifest['benchmark_sha256']
    record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_only=True,gpu=False,
        original_source_unchanged=True,original_benchmark_unchanged=True,original_index_unchanged=True,
        head=head,source=str(SRC),build=str(BUILD),copied_current_overlay=copied,
        original_source_sha256=manifest['worktree_source_sha256'],isolated_source_sha256=pins,
        patch_sha256=sha(patch),comment_labels=labels,
        original_benchmark_sha256=manifest['benchmark_sha256'],original_manifest_sha256=manifest['plan_sha256'],
        addendum_sha256=sha(ROOT/'h3_resource_isolated_cpu_build_addendum.json'),
        not_promoted=True,not_adopted=True)
    (ISO/'preparation.json').write_text(json.dumps(record,indent=2)+'\n')
    print('ISOLATED_RESOURCE_SOURCE_PREPARED',SRC,'pins',len(pins),'NO_LIVE_INPUT_CHANGE',flush=True)

if __name__=='__main__':main()
