"""Audit actual H2 machine code, resources and all preserved H1 kernels."""
from pathlib import Path
import argparse, mmap, re, sys
import runtime as r
import shader_audit
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p6d')
import elf_isa as e

def main():
    ap=argparse.ArgumentParser();ap.add_argument('binary');ap.add_argument('--tag',default='shared');ap.add_argument('--probe',action='store_true')
    a=ap.parse_args();e.ROOT=ROOT;rows=[]
    old={} if a.probe else r.read(ROOT/'compile/build2/shader_preservation.json')['added']
    new=shader_audit.inventory(a.binary)
    assert all(k in new and new[k]['machine_sha256']==v['machine_sha256'] for k,v in old.items()), 'H1 machine code changed'
    with Path(a.binary).open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        fat=next(s for s in e.sections(data) if s['name']=='.hip_fatbin')
        for triple,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
            if 'gfx936' not in triple or code[:4]!=b'\x7fELF':continue
            sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
            for name in [n for n in md if 'DecodeNnSharedKernel' in n]:
                match=re.search(r'DecodeNnSharedKernelILi(\d+)ELi(\d+)ELi(\d+)EE',name);assert match,name
                fragments,k,depth=map(int,match.groups())
                tag=f'{a.tag}_shared_m{fragments*16}_k{k}_d{depth}'
                co=ROOT/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
                item=e.dump(co,code,sh,symbols,md,name,tag);meta=item['metadata'];op=item['opcodes']
                assert item['unknown_lines']==0 and meta.get('.private_segment_fixed_size',0)==0
                assert meta.get('.vgpr_spill_count',0)==meta.get('.sgpr_spill_count',0)==0
                assert op.get('s_barrier',0)>=depth
                assert op.get('buffer_load_dwordx2',0)==op.get('buffer_load_ushort',0)==0
                assert item['direct_lds_loads']>=2*depth*(1+k//16)
                assert op.get('v_mmac_f32_16x16x16_bf16',0)==4*fragments*depth*(k//16)
                a_waves=(fragments*16+(512//k)-1)//(512//k)
                item.update(row_fragments=fragments,block_k=k,depth=depth,
                            dynamic_lds_bytes=depth*(a_waves*1024+4*k*64))
                rows.append(item)
    assert len(rows)==9,len(rows)
    r.write(ROOT/(a.tag+'_shared_isa_audit.json'),dict(ok=True,binary=a.binary,kernels=rows,preserved_h1_shaders=len(old)))
    print('SHARED_ISA_AUDIT_PASS',len(rows),'preservedH1',len(old),flush=True)
    for x in rows:print('SHARED_ISA',x['row_fragments']*16,x['block_k'],x['depth'],'VGPR',x['metadata']['.vgpr_count'],'LDS',x['dynamic_lds_bytes'],'no_spill',flush=True)

if __name__=='__main__':main()
