"""Continue only after the repaired, registered tuning queue is terminal rc0."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
BUILD=json.loads((ROOT/'active_build.json').read_text())
def read(p):return json.loads(Path(p).read_text())
def state(**kw):
    p=ROOT/'post_h3_profile_controller.json';tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n');tmp.replace(p)
def guard(gpu=False):
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
    assert read(ROOT/'active_build.json')==BUILD
    session=read(ROOT/'session.json');assert time.time()<session['deadline_epoch']
    if gpu:assert time.time()+60<session['gpu_deadline_epoch']
    assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
def command(args,label,gpu=False):
    guard(gpu);state(state='running',stage=label,command=args)
    child=subprocess.Popen(args,stdin=subprocess.DEVNULL);rc=child.wait()
    state(state='passed' if rc==0 else 'stopped',stage=label,rc=rc,pid=child.pid)
    assert rc==0,(label,rc)
def main():
    state(state='waiting_for_original_h3_queue',build=BUILD)
    while True:
        guard(True);live=read(ROOT/'live_stage.json')
        if any(str(x).endswith('/h3_campaign.py') for x in live['command']):
            result=Path(live['path'])/'result.json'
            if result.exists():
                done=read(result);assert done['rc']==0,done
                if done['stage']=='representatives':break
        time.sleep(15)
    command([sys.executable,'-B',str(ROOT/'analyze_h3_discovery.py')],'audit85')
    command([sys.executable,'-B','-u',str(ROOT.parent/'run_stage.py'),'capture','--script','profile_h3.py'],'paired_h3_SQTT',True)
    command([sys.executable,'-B',str(ROOT/'analyze_h3_profiles.py')],'counter_ISA')
    command([sys.executable,'-B',str(ROOT/'deliver_h3.py')],'package')
    state(state='complete',next_action='Interpret all85 and route controls; deliver batch5, then freeze a defensible attribute domain and independently confirm if warranted. H3 is the last main architecture; do not start another ownership structure. No acceptance from discovery.')
    print('H3_AUTOMATIC_PROFILE_DELIVERY_PASS',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:state(state='stopped',error=repr(e));raise
