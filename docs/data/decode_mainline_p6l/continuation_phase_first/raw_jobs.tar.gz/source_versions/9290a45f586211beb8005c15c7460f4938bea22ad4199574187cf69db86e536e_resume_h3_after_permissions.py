"""One privileged-context continuation after successful standard recovery.
No rebuild, GPU retry, protocol relaxation or deadline extension is performed.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,datetime
import runtime as r,plan,h3_campaign as hc
ROOT=Path(__file__).resolve().parent
BUILD=r.read(ROOT/'active_build.json');SELF=plan.sha(__file__)
def state(value,**kw):
 data=dict(at=r.stamp(),pid=os.getpid(),state=value,script_sha256=SELF,build_folder=BUILD['folder'],build_exec_session=BUILD['exec_session'],**kw)
 r.write(ROOT/'h3_permission_resume_sequence.json',data);r.write(ROOT/'postbuild_h3_controller.json',data)
def guard():
 assert plan.sha(__file__)==SELF and r.read(ROOT/'active_build.json')==BUILD
 assert time.time()+60<r.read(ROOT/'session.json')['gpu_deadline_epoch']
 assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
def command(stage):
 guard();argv=[sys.executable,'-B','-u',str(ROOT.parent/'run_stage.py'),stage,'--script','h3_campaign.py']
 state('running',stage=stage,command=argv)
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL);rc=child.wait()
 state('stage_passed' if rc==0 else 'stopped',stage=stage,rc=rc,child_pid=child.pid)
 assert rc==0,(stage,rc)
def main():
 guard();assert BUILD['folder']=='compile/build6';assert r.Site(ROOT).epoch()==1
 stages=r.read(ROOT/BUILD['folder']/'results.json');assert len(stages)==2 and all(x['rc']==0 for x in stages)
 assert r.read(ROOT/'recovery_total.json')['attempts']==1
 with r.locked():
  hc.freeze()
  old=r.read(ROOT/'frozen_plan.json');m=dict(old);m.pop('plan_sha256',None)
  m['runner_sha256']=dict(old['runner_sha256'])
  for name in ['resume_h3_after_permissions.py','profile_after_h3_v2.py','profile_h3.py','h3_profile_selection_rule.json','analyze_h3_discovery.py','analyze_h3_profiles.py','h3_isa_schedule.py','deliver_h3.py']:
   m['runner_sha256'][name]=plan.sha(ROOT/name)
  m['execution_context']=dict(epoch=1,kernel_log_readable=True,permission_incident_archive='controller_history/h3_dmesg_permission_gate',standard_recovery_key=r.read(ROOT/'environment_epoch.json')['recovery_key'],new_GPU_data_before_recovery=False)
  m['plan_sha256']=plan.digest(m);r.write(ROOT/'manifests'/(m['plan_sha256']+'.json'),m);r.write(ROOT/'frozen_plan.json',m)
 state('execution_context_frozen',manifest=m['plan_sha256'],epoch=1)
 command('qualify')
 # The preceding stage is now terminal rc0, so the profile monitor never sees
 # the old failed permission-stage result. It waits for all85 paired results.
 guard();state('representatives_and_profile_monitor',epoch=1)
 prof=subprocess.Popen([sys.executable,'-B','-u',str(ROOT/'profile_after_h3_v2.py')],stdin=subprocess.DEVNULL)
 try:command('representatives')
 except Exception:
  # Failure state stops the CPU monitor before it can submit profiling work.
  prof.wait();raise
 profrc=prof.wait();assert profrc==0,('H3 profile/packaging failed',profrc)
 state('complete',epoch=1,note='All discovery and profiles finished; final-domain seven-block acceptance still required')
 print('H3_RECOVERED_DISCOVERY_PROFILE_SEQUENCE_PASS',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:state('stopped',error=repr(e));raise
