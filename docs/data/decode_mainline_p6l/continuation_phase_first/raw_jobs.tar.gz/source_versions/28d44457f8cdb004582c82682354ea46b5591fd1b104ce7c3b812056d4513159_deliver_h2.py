"""Package all preselected H2 SQTT pairs without filtering losses."""
from pathlib import Path
import csv, hashlib, json, shutil, tarfile
import runtime as r
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    captures=r.read(ROOT/'h2_profiles.json');selected=r.read(ROOT/'h2_profile_plan.json')
    assert len(captures)==2*len(selected['chosen']) and 8<=len(captures)<=12
    assert {(x['pair'],x['role']) for x in captures}=={(x['pair'],arm) for x in selected['chosen'] for arm in ['base','candidate']}
    analysis=ROOT/'h2_profile_analysis'
    isa={(x['ID'],x['arm']):x for x in r.read(analysis/'profile_isa.json')}
    metrics={(x['ID'],x['arm']):x for x in r.read(analysis/'profile_analysis.json')['rows']}
    target=ROOT/'delivery/batch3_h2_current_candidate';assert not target.exists()
    target.mkdir(parents=True);manifest=[]
    readme=['# H2协作共享A流水：当前CK与候选成对SQTT','',
      '固定代表ID621/805/1072及短线ID76，主线配置按全部8条代表几何平均candidate/base最低选择；另补实际观测到但固定组缺失的收益/持平/回退类别中位样本。规则在捕获前冻结，所有负结果和高CV保留。',
      '', '## 打开与核对','',
      '完整解压，保持captures中的原始名字和相对依赖。XCompute File → Open打开.perf；Result选dispatch18、以下kernel、XCD0。捕获SE0/active-CU-index0。',
      'Summary先核对grid/block/VGPR/LDS；Source恢复全范围并按以下PC定位重复K主循环；Wavefronts先缩到全kernel，再放大中间重复段，最后查看预热和排空。准确GUI时间区间需要打开后确定。',
      '关注A的ds_read_b64、B的ds_read_m32x16、vmcnt/lgkmcnt和barrier到MMAC的次序。比较不同wave是否同步停顿、下一操作数读取是否与当前MMAC重叠、未来B预取在何时发出。',
      '正式三轮数据来自shared_discovery_analysis.csv，profiler时长不是正式成绩。PMC重放可能改变缓存状态，HBM总流量不能独自归因于A或B；不同wave累计Latency不能相加当墙钟。',
      '本机已核对文件SHA、SQTT字节数/results.txt、dispatch18、GPU4和实际代码。未在本机运行Windows XCompute，不宣称GUI解码已验证。',
      '', '## 同shape计数对照','']
    for pair in selected['chosen']:
        caps=[x for x in captures if x['pair']==pair['pair']]
        assert len(caps)==2
        base=next(x for x in caps if x['role']=='base');candidate=next(x for x in caps if x['role']=='candidate')
        a=metrics[base['ID'],base['arm']];b=metrics[candidate['ID'],candidate['arm']]
        readme += [f'- `{pair["pair"]}`：正式耗时变化{pair["delta_pct"]:+.3f}%，highCV={pair["high_cv"]}；',
          f'  baseline/candidate VMEM每wave={a.get("sq_insts_vmem_per_wave")}/{b.get("sq_insts_vmem_per_wave")}；wait/wavecycle={a.get("wait_any_over_wave_cycles")}/{b.get("wait_any_over_wave_cycles")}；LDS冲突/active={a.get("lds_bank_conflict_over_lds_active")}/{b.get("lds_bank_conflict_over_lds_active")}；HBM读取字节={a.get("hbm_read_bytes")}/{b.get("hbm_read_bytes")}。']
    readme+=['','## 每份perf定位','']
    for cap in captures:
        code=isa[cap['ID'],cap['arm']];metric=metrics[cap['ID'],cap['arm']]
        source=Path(next(f['path'] for f in cap['files'] if f['path'].endswith('.perf'))).parent
        relative=Path('captures')/source.name;shutil.copytree(source,target/relative)
        entry={k:v for k,v in cap.items() if k not in ['files','raw_log']}
        entry.update(kernel_name=code['captured_kernel'],machine_sha256=code['sha256'],resources=metric['geometry'],files=[])
        for item in cap['files']:
            p=target/relative/Path(item['path']).relative_to(source)
            assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
            entry['files'].append(dict(path=str(p.relative_to(target)),bytes=p.stat().st_size,sha256=sha(p)))
        assert cap['raw_token_bytes']>=4096 and code['unknown_lines']==0
        manifest.append(entry);perf=next(x for x in entry['files'] if x['path'].endswith('.perf'))
        readme += [f'### ID{cap["ID"]} {cap["arm"]}','',
          f'- MNKG：{cap["shape"]}；实例{cap["actual_instance"]}；GPU4/epoch{cap["epoch"]}。',
          f'- 文件：`{perf["path"]}`；dispatch18/XCD0；SQTT token {cap["raw_token_bytes"]}字节。',
          f'- kernel：`{code["captured_kernel"]}`。',
          f'- 资源：{metric["geometry"]}。',
          f'- Source主循环PC：`{code["main_loop_candidates"]}`。','']
        readme.extend('  指令PC定位：`'+z['text']+'`' for z in code['instruction_anchors'][:12]);readme.append('')
    r.write(target/'profile_manifest.json',manifest)
    fields=['ID','M','N','K','G','role','variant','actual_instance','selected_dispatch','XCD','physical_gpu','epoch','raw_token_bytes','perf_path','perf_bytes','perf_sha256','kernel_name']
    with (target/'profile_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fields);writer.writeheader()
        for x in manifest:
            perf=next(z for z in x['files'] if z['path'].endswith('.perf'));row={k:x.get(k) for k in fields}
            row.update(x['shape']);row.update(perf_path=perf['path'],perf_bytes=perf['bytes'],perf_sha256=perf['sha256']);writer.writerow(row)
    for name in ['h2_profile_plan.json','h2_profile_selection_rule.json','shared_discovery_analysis.csv','shared_discovery_analysis.json','h2_hypothesis.json']:
        shutil.copy2(ROOT/name,target/name)
    shutil.copy2(analysis/'profile_analysis.json',target/'profile_analysis.json')
    (target/'XCOMPUTE_README.md').write_text('\n'.join(readme),encoding='utf-8')
    package=target.parent/'P6l_batch3_H2_current_candidate_SQTT.tar.gz';assert not package.exists()
    with tarfile.open(package,'w:gz') as archive:archive.add(target,arcname=target.name)
    r.write(ROOT/'profile_delivery_batch3.json',dict(at=r.stamp(),path=str(package),bytes=package.stat().st_size,sha256=sha(package),captures=len(captures),gui_verified=False,local_integrity_checked=True))
    print('H2_PROFILE_DELIVERY_PASS',package,package.stat().st_size,sha(package),flush=True)

if __name__=='__main__':main()
