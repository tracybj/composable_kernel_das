"""Wait for the one live final controller, then diagnose four fixed pairs.

No queue restarts, source edits, compile, automatic recovery, or new seed.
Only the predeclared SQTT diagnosis may follow a fully completed failed attempt.
"""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
WATCHED=ROOT/'final_controllers/20261112T131919_d428f251/status.json'
EXPECTED_PID=333614
PINNED=['after_confirmation_diagnosis.py','regression_profile_campaign.py','h3_regression_profile_rule.json']

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def alive(pid):
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False

def main():
    exclusive=(ROOT/'regression_diagnosis_controller.lock').open('a')
    fcntl.flock(exclusive,fcntl.LOCK_EX|fcntl.LOCK_NB)
    first=read(WATCHED)
    assert first['pid']==EXPECTED_PID and first['state']=='running' and first['stage']=='run'
    assert alive(EXPECTED_PID),'Do not infer liveness from the checkpoint alone'
    pins={n:sha(ROOT/n) for n in PINNED}
    def event(**extra):
        value=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),
            watched_pid=EXPECTED_PID,watched_status=str(WATCHED),script_sha256=pins,**extra)
        p=ROOT/'post_final_regression_diagnosis.json';tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
        with (ROOT/'post_final_regression_diagnosis_events.jsonl').open('a') as out:
            out.write(json.dumps(value)+'\n');out.flush();os.fsync(out.fileno())
    def guard(gpu):
        assert all(sha(ROOT/n)==s for n,s in pins.items()),'Prepared controller changed'
        session=read(ROOT/'session.json');assert time.time()<session['deadline_epoch']
        if gpu:
            assert time.time()+60<session['gpu_deadline_epoch'],'Original new-GPU deadline reached'
            assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
    event(state='waiting_for_live_final_controller')
    print('POST_FINAL_DIAGNOSIS_WAITING',EXPECTED_PID,flush=True)
    try:
        while True:
            guard(True);current=read(WATCHED)
            assert current['pid']==EXPECTED_PID
            if current['state'] in ['failed','stopped']:
                raise RuntimeError('Original confirmation stopped; no follow-up GPU submitted')
            if current['state']=='measurement_and_report_complete':
                if not alive(EXPECTED_PID):
                    with (ROOT/'final_controller.lock').open('a') as lock:
                        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                        folder=Path(read(ROOT/'final_active.json')['path'])
                        report=read(folder/'report.json')
                        assert report['complete'] and len(read(folder/'results.json'))==347
                        assert not report['goal_performance_pass']
                    break
            elif not alive(EXPECTED_PID):
                raise RuntimeError('Original process ended without a complete terminal report')
            event(state='waiting_for_live_final_controller',observed_state=current['state'],observed_stage=current.get('stage'))
            time.sleep(30)
        for stage in ['freeze','capture','analyze','deliver']:
            guard(stage in ['freeze','capture'])
            command=[sys.executable,'-B','-u',str(ROOT/'regression_profile_campaign.py'),stage]
            event(state='running',stage=stage,command=command)
            child=subprocess.Popen(command,stdin=subprocess.DEVNULL)
            code=child.wait();event(state='passed' if code==0 else 'failed',stage=stage,rc=code,child_pid=child.pid)
            print('POST_FINAL_DIAGNOSIS_STAGE',stage,'rc',code,flush=True)
            if code:raise SystemExit(code)
        event(state='complete',delivery=read(ROOT/'profile_delivery_batch7.json'),note='Diagnosis only; original performance target remains unchanged')
        print('POST_FINAL_REGRESSION_DIAGNOSIS_COMPLETE',flush=True)
    except BaseException as error:
        event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False)
        raise

if __name__=='__main__':main()
