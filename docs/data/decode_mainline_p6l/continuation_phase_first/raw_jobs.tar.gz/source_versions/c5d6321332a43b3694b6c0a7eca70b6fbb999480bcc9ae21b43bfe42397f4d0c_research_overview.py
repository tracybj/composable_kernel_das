"""Evidence-backed research ledger; never merges per-shape winners across builds."""
from pathlib import Path
import csv,hashlib,json,datetime
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
 phases=[('H1','mainline_discovery',48),('H2','shared_discovery',39),('H2 layout factors','tuning_discovery',74),('H3','h3_discovery',85)]
 if (ROOT/'h3_factors_discovery_analysis.json').exists():phases.append(('H3 depth/host factors','h3_factors_discovery',116))
 rows=[];records=[]
 for name,stem,expected in phases:
  path=ROOT/(stem+'_analysis.json');analysis=json.loads(path.read_text());source=ROOT/(stem+'_results.json')
  assert sha(source)==analysis['input_sha256']
  records.append(dict(phase=name,source=str(path),sha256=sha(path),completed=analysis['completed_pairs'],expected=expected,complete=analysis['completed_pairs']==expected,failed_jobs=analysis['failed_jobs']))
  for group in analysis['groups']:
   for variant,x in group['variants'].items():
    rows.append(dict(phase=name,variant=variant,family='short' if variant.startswith('short') or '_short_' in variant else 'main',pairs=x['pairs'],candidate_over_baseline_GM=x['geometric_candidate_over_base'],GM_delta_pct=100*(x['geometric_candidate_over_base']-1),improve_over2=x['improve_gt2'],point_improve_ge5=x['point_improve_ge5'],regress_over2=x['regress_gt2'],within2=x['within2'],highCV=x['high_cv'],epoch=group['epoch'],binary_sha256=group['binary_sha256'],plan_sha256=group['plan_sha256'],formal_seven_block_acceptance=False))
 packages=[]
 for i in range(1,7):
  path=ROOT/f'profile_delivery_batch{i}.json'
  if path.exists():
   x=json.loads(path.read_text());actual=Path(x['path']);assert actual.stat().st_size==x['bytes'] and sha(actual)==x['sha256'];packages.append(x)
 confirmation=ROOT/'final_active.json'
 result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Terminal three-round phases, separate binaries/epochs; no cross-build best-per-shape score',phases=records,rows=rows,delivered_packages=packages,final_confirmation_frozen=confirmation.exists(),adopted_families=[],accepted_stable_weak_originals=0,accepted_attributable_crossings=0,performance_goal_complete=False,note='This ledger does not evaluate seven-block confirmation. Final acceptance must come from final_attempts/*/report.json, not these exploratory point estimates.')
 (ROOT/'research_overview_current.json').write_text(json.dumps(result,indent=2)+'\n')
 fields=list(rows[0])
 with (ROOT/'research_overview_current.csv').open('w',newline='') as out:
  w=csv.DictWriter(out,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
 text=['# 研究证据阶段汇总（进行中）','','每行是一个完整变体在同轮对照上的几何平均耗时比；不同构建和epoch分开，不能拼接逐shape赢家。三轮数据没有通过七block采用验收。','','| 阶段 | 配置 | 对数 | GM耗时变化 | 改善>2% | 回退>2% | 高CV |','|---|---|---:|---:|---:|---:|---:|']
 for x in rows:text.append(f'|{x["phase"]}|{x["variant"]}|{x["pairs"]}|{x["GM_delta_pct"]:+.2f}%|{x["improve_over2"]}|{x["regress_over2"]}|{x["highCV"]}|')
 text+=['','当前候选仍在研究，尚未获得采用域完整独立确认和50/30目标证据。五级预取与快速host解析的CPU/静态结果不能替代GPU精度和耗时。','',f'已交付{len(packages)}批perf包，路径、大小、SHA及GUI检查范围见JSON。用户XCompute反馈异步处理；本机没有宣称打开Windows GUI。','', '原P6k、冻结BLAS、原Excel不改；本轮没有1193或881全量GPU复测。最终须另列实际测量域统计和明确标注的历史混合投影。']
 (ROOT/'research_overview_current.md').write_text('\n'.join(text)+'\n')
 print('RESEARCH_LEDGER_WRITTEN',len(records),'phases',sum(x['completed'] for x in records),'pairs',len(rows),'variants',len(packages),'perf packages',flush=True)

if __name__=='__main__':main()
