"""Read-only audit of the registered same-card diagnostic pairs; no GPU work."""
from pathlib import Path
import csv,json,math,statistics
import plan,runtime as r
ROOT=Path(__file__).resolve().parent

def main():
 research=r.read(ROOT/'research_plan.json');manifest=r.read(ROOT/'frozen_plan.json')
 jobs=[json.loads(s) for s in (ROOT/'jobs.jsonl').read_text().splitlines()]
 bykey={x['key']:x for x in jobs};assert len(bykey)==len(jobs)
 completed=r.read(ROOT/'diagnostic_completions.json',[]);cases={x['ID']:x for x in research['cases']};rows=[]
 for done in completed:
  case=cases[done['ID']];records=[bykey[k] for k in done['keys']]
  assert len(records)==8 and all(x['ok'] and x['physical_gpu']==4 and x['epoch']==done['epoch'] and x['plan_sha256']==done['plan_sha256'] and x['attempt']==done['attempt'] for x in records)
  assert all(x['benchmark_sha256']==done['binary_sha256'] for x in records)
  ck=[x for x in records if x['kind']=='perf'];native=[x for x in records if x['kind']=='native_perf' and x['mode']=='perf']
  assert [x['round'] for x in ck]==[1,2,3]==[x['round'] for x in native]
  assert [x['variant'] for x in records[2:]]==['current_best','frozen_native','frozen_native','current_best','current_best','frozen_native']
  accuracy=records[0];assert accuracy['kind']=='accuracy' and accuracy['selected']==case['expected'] and len(accuracy['comparisons'])==3
  elements=case['G']*case['M']*case['N']
  assert all(int(x[1])==elements and int(x[2])==0 and math.isfinite(float(x[3])) for x in accuracy['comparisons'])
  na=records[1]['native'];assert len(na['comparisons'])==3
  assert all(x['checked']==elements and x['failed']==0 and x['finite'] and x['guards_ok'] for x in na['comparisons'])
  for rec in native:
   n=rec['native'];assert n['algorithm_id']==case['algorithm_id'] and n['kernel_name']==case['kernel_name'] and n['repeat']==1 and n['samples']==30 and len(n['samples_ms'])==30
   assert math.isclose(statistics.median(n['samples_ms']),n['median_ms'],rel_tol=1e-12)
  cm=statistics.median(x['result']['median_ms'] for x in ck);nm=statistics.median(x['native']['median_ms'] for x in native)
  assert math.isclose(cm,done['CK_ms'],rel_tol=1e-12) and math.isclose(nm,done['Native_ms'],rel_tol=1e-12)
  rows.append(dict(ID=case['ID'],**{z:case[z] for z in ['M','N','K','G']},actual_instance=case['expected'],scheme=case['scheme'],CK_ms=cm,Native_ms=nm,R_live=nm/cm,frozen_BLAS_ms=case['frozen_BLAS_ms'],R_frozen=case['frozen_BLAS_ms']/cm,ck_round_ms=[x['result']['median_ms'] for x in ck],native_round_ms=[x['native']['median_ms'] for x in native],ck_round_cv=[x['result']['cv'] for x in ck],native_round_cv=[x['native']['cv'] for x in native],epoch=done['epoch'],benchmark_sha256=done['binary_sha256'],keys=done['keys']))
 status=dict(at=r.stamp(),completed=len(rows),expected=16,complete=len(rows)==16,source='Same-session GPU4 default-selector CK and frozen-algorithm Native; no new candidate',protocol=research['diagnostic_protocol'],note='R_live is diagnostic single-call HIP-event timing. Native GroupGemm::run and CK direct launch have different CPU enqueue paths; neither is identical to historical GPU0/repeat20 Native. R_frozen retains original reference. No gain is attributable to a new kernel.',rows=rows)
 r.write(ROOT/'diagnostic_analysis.json',status)
 fields=['ID','M','N','K','G','actual_instance','scheme','CK_ms','Native_ms','R_live','frozen_BLAS_ms','R_frozen','ck_round_ms','native_round_ms','ck_round_cv','native_round_cv','epoch','benchmark_sha256']
 with (ROOT/'diagnostic_analysis.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader()
  for row in rows:w.writerow({k:json.dumps(row[k]) if isinstance(row[k],list) else row[k] for k in fields})
 print('DIAGNOSTIC_AUDIT_PASS',len(rows),'/16 complete='+str(status['complete']),flush=True)
 for x in rows:print('DIAG',x['ID'],'CK',round(x['CK_ms'],6),'Native',round(x['Native_ms'],6),'R_live',round(x['R_live'],3),'R_frozen',round(x['R_frozen'],3))

if __name__=='__main__':main()
