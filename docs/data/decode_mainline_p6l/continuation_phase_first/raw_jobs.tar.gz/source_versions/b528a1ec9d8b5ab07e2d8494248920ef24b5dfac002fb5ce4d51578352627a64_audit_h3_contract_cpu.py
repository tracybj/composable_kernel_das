"""Read-only ABI/source contract proof; does not stand in for GPU validation."""
from pathlib import Path
import csv,datetime,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/composable_kernel')
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 session=json.loads((ROOT/'session.json').read_text());head=session['head'];name='include/ck_tile/ops/gemm/grouped_gemm_device_args.h'
 old=subprocess.check_output(['git','show',head+':'+name],cwd=REPO).decode();current=(REPO/name).read_text()
 def structures(source):
  pattern=r'typedef struct\s+(\w+)\s*\{.*?\}\s*\w+\s*;'
  return {m.group(1):m.group(0) for m in re.finditer(pattern,source,re.S)}
 a=structures(old);b=structures(current);assert a and a==b
 arg='include/ck_tile/ops/gemm/kernel/grouped_gemm_kernel.hpp'
 initial_arg=subprocess.check_output(['git','show',head+':'+arg],cwd=REPO);assert initial_arg==(REPO/arg).read_bytes()
 providers=['example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_mainline_device_args.cpp','example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_shared_device_args.cpp','example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_cooperative_device_args.cpp']
 forbidden=r'\b(hipMalloc\w*|hipFree\w*|hipMemcpy\w*|hipDeviceSynchronize|hipStreamSynchronize)\s*\('
 for n in providers:assert not re.search(forbidden,(REPO/n).read_text()),n
 shapes=[]
 for path in ['/workspace/shapes_1178.csv','/workspace/Grouped_Geem/blaslt_tuning_tools/shapes_1178.csv']:
  p=Path(path);assert sha(p.read_bytes())=='5c3ae4d1d682b919ed90adb5cfed1cec755e3b519f9003afde8c46d282e77863'
  with p.open(newline='') as f:count=len(list(csv.DictReader(f)))
  assert count==1193;shapes.append(dict(path=path,rows=count,sha256=sha(p.read_bytes())))
 protected=subprocess.check_output(['git','diff','--','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp'],cwd=REPO);assert hashlib.md5(protected).hexdigest()==session['protected_diff_md5']
 result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_source_only=True,initial_head=head,public_structures_unchanged={n:sha(s.encode()) for n,s in a.items()},public_abi_version=1,GemmTransKernelArg_defining_file_unchanged=dict(path=arg,sha256=sha(initial_arg)),no_hot_allocation_copy_or_host_sync_in_new_providers=True,provider_source_sha256={n:sha((REPO/n).read_bytes()) for n in providers},original_shapes_unchanged=shapes,readfirstlane_diff_md5=hashlib.md5(protected).hexdigest(),selector_source_sha256=sha((REPO/'include/ck_tile/ops/gemm/grouped_gemm_selector.hpp').read_bytes()),qualified_geometry='Only gfx936 BF16 NN/common nonempty nonragged; mainM1..64,N1024..4096,N%128=0,K2048..8192,K%128=0,G1..1024. ShortM1..64,N128..4096,N%128=0,K64..<2048,K%64=0,G<=32.',storage_scope='Packed/aligned dense test allocations; no claim for every possible arbitrary pointer/stride. N tiles exact128; no column tail predicate. Neighbor/disable/outside CPU regressions and scheduled GPU controls remain required.',gpu_h3_precision_verified=False,gpu_h3_performance_verified=False,note='Exact public-struct source and descriptor definition equality proves unchanged layout definition. Static provider scan is limited to these source files; launch helper is unmodified. Scope/API checks supplement, never replace, the pending full-output/guard and default-selector GPU validation.')
 (ROOT/'h3_contract_cpu_audit.json').write_text(json.dumps(result,indent=2)+'\n')
 print('H3_ABI_SOURCE_CONTRACT_AUDIT_PASS',len(a),'public structures, shapes1193x2; GPU status pending',flush=True)
if __name__=='__main__':main()
