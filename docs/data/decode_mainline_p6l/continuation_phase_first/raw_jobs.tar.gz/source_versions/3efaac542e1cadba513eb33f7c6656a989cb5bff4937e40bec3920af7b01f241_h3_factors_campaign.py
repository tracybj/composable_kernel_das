"""Registered standalone-decode qualification and paired discovery, GPU4 only."""
from pathlib import Path
import argparse,copy,json,statistics,subprocess,sys,time,uuid,re
import profile_capture as profile_tools
import campaign as diagnostic,plan,runtime as r
ROOT=Path(__file__).resolve().parent
VARIANTS={'coop_d4_full': {'family': 'main', 'variant': 11, 'instance': 6022, 'early': 0, 'xor': 0, 'fast': 0}, 'coop_d4_fast': {'family': 'main', 'variant': 11, 'instance': 6022, 'early': 0, 'xor': 0, 'fast': 1}, 'coop_d5_full': {'family': 'main', 'variant': 12, 'instance': 6023, 'early': 0, 'xor': 0, 'fast': 0}, 'coop_d5_fast': {'family': 'main', 'variant': 12, 'instance': 6023, 'early': 0, 'xor': 0, 'fast': 1}, 'private_xor_full': {'family': 'main', 'variant': 6, 'instance': 6013, 'early': 0, 'xor': 0, 'fast': 0}, 'private_xor_fast': {'family': 'main', 'variant': 6, 'instance': 6013, 'early': 0, 'xor': 0, 'fast': 1}, 'private_both_full': {'family': 'main', 'variant': 8, 'instance': 6015, 'early': 0, 'xor': 0, 'fast': 0}, 'private_both_fast': {'family': 'main', 'variant': 8, 'instance': 6015, 'early': 0, 'xor': 0, 'fast': 1}, 'short_xor_full': {'family': 'short', 'variant': 3, 'instance': 6016, 'early': 0, 'xor': 0, 'fast': 0}, 'short_xor_fast': {'family': 'short', 'variant': 3, 'instance': 6016, 'early': 0, 'xor': 0, 'fast': 1}, 'short_both_full': {'family': 'short', 'variant': 5, 'instance': 6018, 'early': 0, 'xor': 0, 'fast': 0}, 'short_both_fast': {'family': 'short', 'variant': 5, 'instance': 6018, 'early': 0, 'xor': 0, 'fast': 1}}

def supported(case,family):
 m,n,k,g=(case[z] for z in ['M','N','K','G'])
 common=1<=m<=64 and n%128==0 and n<=4096 and 1<=g<=1024
 return common and (n>=1024 and 2048<=k<=8192 and k%128==0 if family=='main' else n>=128 and 64<=k<2048 and k%64==0 and g<=32)

def as_case(row):
 return dict(ID=row['ID'],**{k:row[k] for k in ['M','N','K','G','phase']},expected=row['actual_instance'],env=copy.deepcopy(row['env']),accuracy_repeats=3,frozen_BLAS_ms=row['frozen_BLAS_ms'],p6k_CK_ms=row['CK_ms'],p6k_R=row['R_frozen'],scheme=row['configured_scheme'])

def candidate(base,name):
 case=copy.deepcopy(base);v=VARIANTS[name];stem='MAINLINE' if v['family']=='main' else 'SHORT'
 case['env'].update({plan.PREFIX+'ENABLE_BF16_NN_DECODE_'+stem:'1',plan.PREFIX+'DISABLE_BF16_NN_DECODE_'+stem:'0',plan.PREFIX+'BF16_NN_DECODE_'+stem+'_VARIANT':str(v['variant'])})
 for mode in ['EARLY_B','XOR_A']:
  case['env'][plan.PREFIX+'ENABLE_BF16_NN_DECODE_SHARED_'+mode]=str(v['early' if mode=='EARLY_B' else 'xor'])
  case['env'][plan.PREFIX+'DISABLE_BF16_NN_DECODE_SHARED_'+mode]='0'
 if supported(case,v['family']):case['expected']=v['instance']
 case['env'][plan.PREFIX+'ENABLE_BF16_NN_DECODE_FAST_POLICY']=str(v['fast'])
 case['env'][plan.PREFIX+'DISABLE_BF16_NN_DECODE_FAST_POLICY']='0'
 case['variant']=name;return case

def selector_check(cases,folder):
 folder.mkdir(parents=True,exist_ok=True);exe=folder/'selector_probe'
 command=['g++','-O2','-std=c++17','-I'+str(plan.REPO/'include'),str(ROOT/'mainline_selector_probe.cpp'),'-o',str(exe)]
 subprocess.run(command,capture_output=True,text=True,check=True,timeout=120)
 lines=[]
 for x in cases:
  e=x['env']
  def enabled(stem):return int(e.get(plan.PREFIX+'ENABLE_BF16_NN_DECODE_'+stem)=='1' and e.get(plan.PREFIX+'DISABLE_BF16_NN_DECODE_'+stem)!='1')
  extra=[enabled('MAINLINE'),int(e.get(plan.PREFIX+'BF16_NN_DECODE_MAINLINE_VARIANT','0')),enabled('SHORT'),int(e.get(plan.PREFIX+'BF16_NN_DECODE_SHORT_VARIANT','0'))]
  lines.append(' '.join(map(str,[x[k] for k in ['ID','M','N','K','G','expected']]+plan.base.policy_fields(x)+extra)))
 out=subprocess.run([str(exe)],input='\n'.join(lines)+'\n',capture_output=True,text=True,check=True,timeout=30)
 actual=out.stdout.splitlines();assert len(actual)==len(cases)
 for x,line in zip(cases,actual):assert tuple(map(int,line.split()))==(x['ID'],x['expected'],x['expected']),(x,line)
 return dict(passed=True,cpu_only=True,cases=len(cases),command=command,output=out.stdout,selector_sha256=plan.sha(plan.SELECTOR))

def create_discovery_plan():
 research=r.read(ROOT/'research_plan.json');source={x['ID']:x for x in r.read(ROOT/'source_results.json')}
 pairs=[]
 short_ids=[26,31,32,76,82,122,128,257,263]
 for name,v in VARIANTS.items():
  ids=research['representative_ids'] if v['family']=='main' else short_ids
  for i in ids:
   base=as_case(source[i])
   if supported(base,v['family']):pairs.append(dict(key=f'id{i}_{name}',ID=i,variant=name,base=base,candidate=candidate(base,name),control=False))
 for i,name in [(358,'coop_d5_fast'),(622,'coop_d5_fast'),(1184,'coop_d5_fast'),(1185,'short_both_fast'),(147,'coop_d5_fast'),(35,'short_both_fast')]:
  base=as_case(source[i]);other=candidate(base,name);assert other['expected']==base['expected']
  pairs.append(dict(key=f'fallback_id{i}_{name}',ID=i,variant=name,base=base,candidate=other,control=True))
 for i,name in [(621,'coop_d4'),(1072,'coop_d4'),(76,'short_xor'),(257,'short_xor')]:
  original=as_case(source[i]);base=candidate(original,name+'_full');other=candidate(original,name+'_fast')
  assert base['expected']==other['expected']
  pairs.append(dict(key=f'host_id{i}_{name}',ID=i,variant=name+'_host',base=base,candidate=other,control=True,route_compare=True))
 for i in [621,805,1009,1072]:
  original=as_case(source[i]);base=candidate(original,'coop_d4_fast');other=candidate(original,'coop_d5_fast')
  pairs.append(dict(key=f'depth_id{i}_d4_d5',ID=i,variant='coop_d5_depth',base=base,candidate=other,control=True,depth_compare=True))
 for i in [633,788]:
  base=as_case(source[i]);other=candidate(base,'coop_d5_fast')
  other['env'][plan.PREFIX+'BF16_NN_DECODE_MAINLINE_VARIANT']='14';other['expected']=base['expected'];other['variant']='scoped_d5_fast_fallback'
  pairs.append(dict(key=f'scope_fallback_id{i}',ID=i,variant='scoped_d5_fast_fallback',base=base,candidate=other,control=True,scope_compare=True))
 qualifications=[]
 for name,v in VARIANTS.items():
  for m in [1,15,16,17,31,32,33,63,64]:
   ident=-10000-len(qualifications)
   base=dict(ID=ident,M=m,N=1152 if v['family']=='main' else 128,K=2176 if v['family']=='main' else 64,G=3,phase='decode',expected=v['instance'],env={plan.V7:'1'},accuracy_repeats=3)
   qualifications.append(candidate(base,name))
 for name in ['coop_d5_fast','short_xor_fast']:
  original=qualifications[-1];v=VARIANTS[name]
  base=dict(ID=-12000-len(qualifications),M=64,N=1152 if v['family']=='main' else 128,K=2176 if v['family']=='main' else 64,G=3,phase='decode',expected=v['instance'],env={plan.V7:'1'},accuracy_repeats=3)
  case=candidate(base,name);case['env'][plan.PREFIX+'DISABLE_BF16_NN_DECODE_FAST_POLICY']='1';case['variant']+='_disabled';qualifications.append(case)
 assert len(pairs)==116 and len(qualifications)==110
 result=dict(schema=1,research_plan_sha256=research['sha256'],structural_design_sha256=plan.sha(ROOT/'h3_factors_hypothesis.json'),preregistration_addendum_sha256=plan.sha(ROOT/'h3_factors_preregistration_addendum.json'),source_build=r.read(ROOT/'active_build.json')['folder']+'/source_sha256.json',heldout_protocol_sha256=plan.sha(ROOT/'heldout_protocol.json'),variants=VARIANTS,short_early_ids=short_ids,short_selection='M1/M32/M64 fragment boundaries; K512/768/1024/1536 and lowG4/8 plus existing-leading G16 controls; fixed before first candidate GPU',qualification_cases=qualifications,discovery_pairs=pairs,protocol=research['diagnostic_protocol'],no_full_run=True)
 result['sha256']=plan.digest(result);return result

def freeze():
 assert time.time()+60<r.read(ROOT/'session.json')['gpu_deadline_epoch']
 build_root=ROOT/r.read(ROOT/'active_build.json')['folder']
 build=r.read(build_root/'results.json');assert len(build)==2 and all(x['rc']==0 for x in build)
 for name,sha in r.read(build_root/'source_sha256.json').items():assert plan.sha(plan.REPO/name)==sha
 path=ROOT/'h3_factors_discovery_plan.json';proposed=create_discovery_plan()
 if path.exists():assert r.read(path)==proposed
 else:r.write(path,proposed)
 old=r.read(ROOT/'frozen_plan.json');m=copy.deepcopy(old);m.pop('plan_sha256',None)
 m.update(phase='h3_factors_cooperative_discovery',candidate_plan_sha256=proposed['sha256'],benchmark_sha256=plan.sha(plan.BENCH),selector_sha256=plan.sha(plan.SELECTOR))
 deps=plan.base.dependencies();m['dependencies']['sha256'].update(deps['sha256']);m['dependencies']['ldd']=deps['ldd']
 for name in ['tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke']:
  p=plan.REPO/'build/bin'/name;m['dependencies']['sha256'][str(p)]=plan.sha(p)
 m['worktree_source_sha256'].update({name:plan.sha(plan.REPO/name) for name in m['worktree_source_sha256']})
 m['worktree_source_sha256'].update(r.read(build_root/'source_sha256.json'))
 for name in ['plan.py','runtime.py','health.py','campaign.py','native_replay.py','mainline_campaign.py','shared_campaign.py','tuning_campaign.py','h3_factors_campaign.py','h3_factors_hypothesis.json','h3_cpu_model.py','mainline_selector_probe.cpp','acceptance.py','after_build.py','after_shared_build.py','after_tuning_build.py','after_h3_factors_build.py','h3_factors_preregistration_addendum.json','h3_factors_discovery_plan.json','build_h3_factors.py','audit_h3_factors_isa.py','cpu_h3_policy_factors.py','profile_h3_factors.py','h3_factors_profile_selection_rule.json','analyze_h3_factors_discovery.py','analyze_h3_factors_profiles.py','deliver_h3_factors.py','active_build.json','heldout_protocol.json']:
  m['runner_sha256'][name]=plan.sha(ROOT/name)
 all_cases=[]
 for pair in proposed['discovery_pairs']:all_cases.extend([pair['base'],pair['candidate']])
 all_cases.extend(proposed['qualification_cases']);audit=selector_check(all_cases,ROOT/'cpu_h3_factors/discovery')
 r.write(ROOT/'cpu_h3_factors/discovery_audit.json',audit)
 m['plan_sha256']=plan.digest(m);r.write(ROOT/'manifests'/(m['plan_sha256']+'.json'),m);r.write(ROOT/'frozen_plan.json',m)
 print('H3_FACTORS_GPU_PLAN_FROZEN',m['plan_sha256'],'pairs',len(proposed['discovery_pairs']),'qualification',len(proposed['qualification_cases']),flush=True)

def spec(case,kind,key,variant,purpose):
 s=diagnostic.ck(case,kind,key);s.update(variant=variant,purpose=purpose);return s

def qualify(site):
 frozen=r.read(ROOT/'h3_factors_discovery_plan.json');done=r.read(ROOT/'h3_factors_qualification.json',[])
 for name in ['tile_example_grouped_gemm_device_args_query_test','tile_example_grouped_gemm_device_args_smoke']:
  key='h3_factors_regression_'+name
  if any(x['logical_key']==key and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in done):continue
  binary=plan.REPO/'build/bin'/name
  s=dict(kind='regression',logical_key=key,command=[str(binary)],binary=str(binary),expected_binary_sha256=plan.sha(binary),env={},regression_kind='device_args_query_test' if name.endswith('query_test') else 'device_args_smoke',purpose='h3_factors_qualification')
  rec=site.execute(s);done.append(rec);r.write(ROOT/'h3_factors_qualification.json',done)
 for case in frozen['qualification_cases']:
  key=f'h3_factors_qual_{case["ID"]}_{case["variant"]}'
  if not any(x['logical_key']==key and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in done):
   rec=site.execute(spec(case,'accuracy',key,case['variant'],'h3_factors_qualification'));done.append(rec);r.write(ROOT/'h3_factors_qualification.json',done)
 print('H3_FACTORS_QUALIFICATION_PASS',len(done),flush=True)

def representatives(site):
 frozen=r.read(ROOT/'h3_factors_discovery_plan.json');qualified=r.read(ROOT/'h3_factors_qualification.json',[])
 assert len([x for x in qualified if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()])==112
 completed=r.read(ROOT/'h3_factors_discovery_results.json',[])
 for pair in frozen['discovery_pairs']:
  if any(x['pair']==pair['key'] and x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch() for x in completed):continue
  attempt=uuid.uuid4().hex[:12];epoch=site.epoch();group=[]
  for arm in ['base','candidate']:
   s=spec(pair[arm],'accuracy',f'h3_factors_{pair["key"]}_{attempt}_{arm}_accuracy',arm,'h3_factors_representatives');group.append(site.execute(dict(s,attempt=attempt,pair=pair['key'])))
  for rd in [1,2,3]:
   for arm in (['base','candidate'] if rd%2 else ['candidate','base']):
    s=spec(pair[arm],'perf',f'h3_factors_{pair["key"]}_{attempt}_{arm}_r{rd}',arm,'h3_factors_representatives');group.append(site.execute(dict(s,attempt=attempt,pair=pair['key'],round=rd)))
  assert all(x['ok'] and x['epoch']==epoch for x in group)
  aa=[x['result'] for x in group if x['kind']=='perf' and x['variant']=='base'];bb=[x['result'] for x in group if x['kind']=='perf' and x['variant']=='candidate']
  a=statistics.median(x['median_ms'] for x in aa);b=statistics.median(x['median_ms'] for x in bb)
  row=dict(pair=pair['key'],ID=pair['ID'],shape={z:pair['base'][z] for z in ['M','N','K','G']},variant=pair['variant'],control=pair['control'],route_compare=pair.get('route_compare',False),depth_compare=pair.get('depth_compare',False),scope_compare=pair.get('scope_compare',False),base_instance=pair['base']['expected'],candidate_instance=pair['candidate']['expected'],base_env=pair['base']['env'],candidate_env=pair['candidate']['env'],base_ms=a,candidate_ms=b,delta_pct=100*(b/a-1),base_rounds=aa,candidate_rounds=bb,high_cv=any(x['cv']>.05 for x in aa+bb),frozen_BLAS_ms=pair['base']['frozen_BLAS_ms'],R_frozen_base=pair['base']['frozen_BLAS_ms']/a,R_frozen_candidate=pair['base']['frozen_BLAS_ms']/b,epoch=epoch,binary_sha256=site.manifest['benchmark_sha256'],plan_sha256=site.manifest['plan_sha256'],keys=[x['key'] for x in group])
  completed.append(row);r.write(ROOT/'h3_factors_discovery_results.json',completed);print('H3_FACTORS_PAIR_PASS',pair['key'],'delta_pct',round(row['delta_pct'],3),'high_cv',row['high_cv'],flush=True)
 print('H3_FACTORS_REPRESENTATIVES_PASS',len(completed),flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['freeze','qualify','representatives']);args=ap.parse_args();r.no_core()
 if args.stage=='freeze':
  with r.locked():freeze()
  return
 site=r.Site(ROOT);assert site.manifest.get('phase')=='h3_factors_cooperative_discovery'
 with r.locked():
  if args.stage=='qualify':qualify(site)
  else:representatives(site)

if __name__=='__main__':main()
