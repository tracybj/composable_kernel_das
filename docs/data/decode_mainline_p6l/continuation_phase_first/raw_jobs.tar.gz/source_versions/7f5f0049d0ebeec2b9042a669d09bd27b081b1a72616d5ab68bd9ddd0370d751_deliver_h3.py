"""Package all preselected H2 SQTT pairs without filtering losses."""
from pathlib import Path
import csv, hashlib, json, shutil, tarfile
import runtime as r
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    captures=r.read(ROOT/'h3_profiles.json');selected=r.read(ROOT/'h3_profile_plan.json')
    assert len(captures)==2*len(selected['chosen']) and 8<=len(captures)<=22
    assert {(x['pair'],x['role']) for x in captures}=={(x['pair'],arm) for x in selected['chosen'] for arm in ['base','candidate']}
    analysis=ROOT/'h3_profile_analysis'
    isa={(x['ID'],x['arm']):x for x in r.read(analysis/'profile_isa.json')}
    metrics={(x['ID'],x['arm']):x for x in r.read(analysis/'profile_analysis.json')['rows']}
    target=ROOT/'delivery/batch5_h3_current_candidate';assert not target.exists()
    target.mkdir(parents=True);manifest=[]
    readme=['# H3协作A/B、三组操作数及相同GPU代码的派发入口对照','',
      '全部85对完成后才依冻结规则选取：固定621/805/1072取H3三配置中八代表几何均值最低者，短76取九代表均值最低者；整体主线赢家若不同补805；补缺失gain/flat/loss中位样本；另含预声明四组direct/legacy同GPU代码控制。仅用于诊断，不是采用或七block确认。',
      '', '## 打开与核对','',
      '完整解压，保持captures中的原始名字和相对依赖。XCompute File → Open打开.perf；Result选dispatch18、以下kernel、XCD0。捕获SE0/active-CU-index0。',
      'Summary先核对grid/block/VGPR/LDS；Source恢复全范围并按以下PC定位重复K主循环。Wavefronts先缩到全kernel，依次查看0～15%的预热、25～75%的重复稳态、最后15%的排空和写回；这些是相对查看窗口，不是假定的阶段耗时。准确绝对Clk范围需要打开后确定。target-cu0是active-CU索引；GUI实际CU编号以展开后的标签为准，可能显示CU1，不应仅因编号不同认定选错文件。',
      '关注B的连续整行Direct-to-LDS、A/B的ds_read、vmcnt/lgkmcnt、barrier与MMAC次序；比较三组操作数的提前读取是否与当前MMAC重叠，M64两个M-wave是否复用B，以及预热和尾部成本。',
      '正式三轮数据来自h3_discovery_analysis.csv，profiler时长不是正式成绩。PMC重放可能改变缓存状态，HBM总流量不能独自归因于A或B；不同wave累计Latency不能相加当墙钟。',
      '本机已核对文件SHA、SQTT字节数/results.txt、dispatch18、GPU4和实际代码。未在本机运行Windows XCompute，不宣称GUI解码已验证。',
      '', '## 同shape计数对照','']
    for pair in selected['chosen']:
        caps=[x for x in captures if x['pair']==pair['pair']]
        assert len(caps)==2
        base=next(x for x in caps if x['role']=='base');candidate=next(x for x in caps if x['role']=='candidate')
        a=metrics[base['ID'],base['arm']];b=metrics[candidate['ID'],candidate['arm']]
        readme += [f'- `{pair["pair"]}`：正式耗时变化{pair["delta_pct"]:+.3f}%，highCV={pair["high_cv"]}；',
          f'  baseline/candidate VMEM每wave={a.get("sq_insts_vmem_per_wave")}/{b.get("sq_insts_vmem_per_wave")}；wait/wavecycle={a.get("wait_any_over_wave_cycles")}/{b.get("wait_any_over_wave_cycles")}；LDS冲突/active={a.get("lds_bank_conflict_over_lds_active")}/{b.get("lds_bank_conflict_over_lds_active")}；HBM读取字节={a.get("hbm_read_bytes")}/{b.get("hbm_read_bytes")}。']
    readme+=['','## 每份perf定位','']
    for cap in captures:
        code=isa[cap['ID'],cap['arm']];metric=metrics[cap['ID'],cap['arm']]
        source=Path(next(f['path'] for f in cap['files'] if f['path'].endswith('.perf'))).parent
        relative=Path('captures')/source.name;shutil.copytree(source,target/relative)
        entry={k:v for k,v in cap.items() if k not in ['files','raw_log']}
        entry.update(kernel_name=code['captured_kernel'],machine_sha256=code['sha256'],resources=metric['geometry'],files=[])
        for item in cap['files']:
            p=target/relative/Path(item['path']).relative_to(source)
            assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
            entry['files'].append(dict(path=str(p.relative_to(target)),bytes=p.stat().st_size,sha256=sha(p)))
        assert cap['raw_token_bytes']>=4096 and code['unknown_lines']==0
        manifest.append(entry);perf=next(x for x in entry['files'] if x['path'].endswith('.perf'))
        readme += [f'### ID{cap["ID"]} {cap["arm"]}','',
          f'- MNKG：{cap["shape"]}；实例{cap["actual_instance"]}；GPU4/epoch{cap["epoch"]}。',
          f'- 文件：`{perf["path"]}`；dispatch18/XCD0；SQTT token {cap["raw_token_bytes"]}字节。',
          f'- kernel：`{code["captured_kernel"]}`。',
          f'- 资源：{metric["geometry"]}。',
          f'- Source主循环PC：`{code["main_loop_candidates"]}`。','']
        readme.extend('  指令PC定位：`'+z['text']+'`' for z in code['instruction_anchors'][:20]);readme.append('')
    route_proof=[]
    for pair in [x for x in selected['chosen'] if x.get('route_compare')]:
        caps=[x for x in captures if x['pair']==pair['pair']]
        base=next(x for x in caps if x['role']=='base');other=next(x for x in caps if x['role']=='candidate')
        a=isa[base['ID'],base['arm']];b=isa[other['ID'],other['arm']]
        assert a['symbol']==b['symbol'] and a['sha256']==b['sha256']
        route_proof.append(dict(pair=pair['pair'],ID=pair['ID'],legacy_instance=base['actual_instance'],direct_instance=other['actual_instance'],actual_kernel=a['captured_kernel'],same_machine_sha256=a['sha256'],formal_delta_pct=pair['delta_pct'],high_cv=pair['high_cv'],not_goal_acceptance=True))
    assert len(route_proof)==4
    r.write(target/'same_gpu_kernel_route_proof.json',route_proof)
    readme+=['','## 同GPU代码的入口对照','',
      '四组route控制均核对实际kernel符号与机器码SHA一致；base走legacy provider因素开关，candidate用固定bit实例。正式三轮仍单独计时。',
      '这些配对能检验整条host派发路径的差别，不能将差别全部归因于getenv；新实例的selector/registry/switch路径也有区别。profiler缓存状态和采集扰动不能替代正式A/B。','']
    for x in route_proof:readme.append('- '+x['pair']+'：同机器码SHA '+x['same_machine_sha256']+'；正式变化'+str(x['formal_delta_pct'])+'%。')
    r.write(target/'profile_manifest.json',manifest)
    fields=['ID','M','N','K','G','role','variant','actual_instance','selected_dispatch','XCD','physical_gpu','epoch','raw_token_bytes','perf_path','perf_bytes','perf_sha256','kernel_name']
    with (target/'profile_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fields);writer.writeheader()
        for x in manifest:
            perf=next(z for z in x['files'] if z['path'].endswith('.perf'));row={k:x.get(k) for k in fields}
            row.update(x['shape']);row.update(perf_path=perf['path'],perf_bytes=perf['bytes'],perf_sha256=perf['sha256']);writer.writerow(row)
    for name in ['h3_profile_plan.json','h3_profile_selection_rule.json','h3_discovery_analysis.csv','h3_discovery_analysis.json','h3_hypothesis.json']:
        shutil.copy2(ROOT/name,target/name)
    shutil.copy2(analysis/'profile_analysis.json',target/'profile_analysis.json')
    shutil.copy2(analysis/'h3_static_schedule.json',target/'h3_static_schedule.json')
    (target/'XCOMPUTE_README.md').write_text('\n'.join(readme),encoding='utf-8')
    package=target.parent/'P6l_batch5_h3_current_candidate_SQTT.tar.gz';assert not package.exists()
    with tarfile.open(package,'w:gz') as archive:archive.add(target,arcname=target.name)
    r.write(ROOT/'profile_delivery_batch5.json',dict(at=r.stamp(),path=str(package),bytes=package.stat().st_size,sha256=sha(package),captures=len(captures),same_gpu_route_pairs=4,gui_verified=False,local_integrity_checked=True))
    print('H3_PROFILE_DELIVERY_PASS',package,package.stat().st_size,sha(package),flush=True)

if __name__=='__main__':main()
