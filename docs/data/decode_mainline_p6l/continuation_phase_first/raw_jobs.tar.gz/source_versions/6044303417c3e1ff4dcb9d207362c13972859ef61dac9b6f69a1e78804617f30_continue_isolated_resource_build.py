"""Explicit follow-up after the observed, fixed registry compile error.

Original failure logs remain immutable. CPU only; no promotion or GPU execution.
"""
from pathlib import Path
import datetime,hashlib,json,os,re,resource,shlex,signal,subprocess,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
ISO=ROOT/'isolated_resource_build'

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.nice(10)
    cpus=sorted(os.sched_getaffinity(0))[-4:];os.sched_setaffinity(0,cpus)
    preparation=read(ISO/'preparation.json');revision=read(ISO/'revisions/registry_completion/revision.json')
    assert read(ISO/'status.json')['state']=='stopped'
    assert revision['initial_controller_tool_handle']==98120 and revision['initial_controller_terminal_rc']==1
    folder=ISO/'followup_registry_completion';folder.mkdir(exist_ok=False)
    src=Path(preparation['source']);build=Path(preparation['build']);pins=revision['isolated_source_sha256'];results=[]
    env={k:v for k,v in os.environ.items() if not k.startswith('CK_TILE_GROUPED_GEMM_') and k not in ['LD_PRELOAD','ROCR_VISIBLE_DEVICES','HSA_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL']}
    env.update(HIP_VISIBLE_DEVICES='4',CUDA_VISIBLE_DEVICES='4',OMP_NUM_THREADS='4')
    def event(**extra):
        row=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),gpu=False,
            cpu_affinity=cpus,nice=os.nice(0),revision_sha256=sha(ISO/'revisions/registry_completion/revision.json'),**extra)
        temporary=folder/'status.tmp';temporary.write_text(json.dumps(row,indent=2)+'\n');temporary.replace(folder/'status.json')
        with (folder/'events.jsonl').open('a') as out:out.write(json.dumps(row)+'\n');out.flush();os.fsync(out.fileno())
    def guard():
        deadline=read(ROOT/'session.json')['gpu_deadline_epoch'];assert time.time()+60<deadline
        available=int(re.search(r'MemAvailable:\s+(\d+)',Path('/proc/meminfo').read_text())[1]);assert available>=96*1024*1024
        assert all(sha(src/n)==s for n,s in pins.items())
        assert all(sha(REPO/n)==s for n,s in preparation['original_source_sha256'].items())
        assert sha(REPO/'build/bin/tile_example_grouped_gemm_device_args_benchmark')==preparation['original_benchmark_sha256']
        return deadline
    def run(label,command):
        deadline=guard();part=folder/label;part.mkdir(exist_ok=False)
        event(state='running',stage=label,command=command);start=time.monotonic()
        with (part/'run.log').open('x') as log:
            child=subprocess.Popen(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,start_new_session=True)
            event(state='running',stage=label,command=command,child_pid=child.pid)
            try:code=child.wait(timeout=max(1,deadline-time.time()-60))
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=30)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                raise RuntimeError('Original compile deadline; stopped own CPU child group')
        row=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stage=label,
            command=command,rc=code,seconds=time.monotonic()-start,gpu=False)
        results.append(row);(part/'command.json').write_text(json.dumps(row,indent=2)+'\n')
        (folder/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        event(state='passed' if code==0 else 'failed',stage=label,rc=code,seconds=row['seconds'])
        print('ISOLATED_REGISTRY_FOLLOWUP_STAGE',label,'rc',code,'seconds',row['seconds'],flush=True)
        assert code==0,(label,str(part/'run.log'))
    try:
        commands=read(build/'compile_commands.json')
        file=str(src/'example_hcu/ck_tile/19_grouped_gemm/providers/grouped_gemm_registry_fp16.cu')
        entry=[x for x in commands if x['file']==file];assert len(entry)==1
        args=shlex.split(entry[0]['command']);i=args.index('-o');del args[i:i+2];args.remove('-c')
        run('registry_host_syntax',args+['--offload-host-only','-fsyntax-only'])
        run('official_targets',['cmake','--build',str(build),'--target',
            'tile_example_grouped_gemm_device_args_benchmark','tile_example_grouped_gemm_device_args_query_test',
            'tile_example_grouped_gemm_device_args_smoke','tile_example_grouped_gemm_selector_test',
            'tile_example_grouped_gemm_decode_depth8_selector_test',
            'tile_example_grouped_gemm_decode_mainline_selector_test','-j4'])
        guard();event(state='compiled_cpu_only',benchmark=str(build/'bin/tile_example_grouped_gemm_device_args_benchmark'),
            benchmark_sha256=sha(build/'bin/tile_example_grouped_gemm_device_args_benchmark'),
            not_promoted=True,not_gpu_validated=True,not_adopted=True)
        print('ISOLATED_REGISTRY_FOLLOWUP_CPU_COMPLETE_NO_GPU',flush=True)
    except BaseException as error:
        event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False)
        raise

if __name__=='__main__':main()
