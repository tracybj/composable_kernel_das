"""Archive terminal H3 discovery, including permission and sparse-trace events."""
from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,shutil,tarfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
DEST=REPO/'docs/data/decode_mainline_p6l/h3_discovery'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')

def main():
 assert not DEST.exists();DEST.mkdir(parents=True)
 analysis=json.loads((ROOT/'h3_discovery_analysis.json').read_text());assert analysis['completed_pairs']==85
 jobs=[json.loads(s) for s in (ROOT/'jobs.jsonl').read_text().splitlines() if s]
 jobs=[x for x in jobs if x.get('purpose') in ['h3_qualification','h3_representatives','h3_profile','h3_profile_repair']]
 assert len(jobs)==786 and all(x['ok'] and x['epoch']==1 for x in jobs)
 comps=[c for x in jobs if x['kind']=='accuracy' for c in x['comparisons']]
 captures=json.loads((ROOT/'h3_profiles.json').read_text());assert len(captures)==18
 summary=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=len(jobs),purposes=dict(collections.Counter(x['purpose'] for x in jobs)),physical_gpu=4,epoch=1,formal_pairs=85,qualification=83,full_output_comparisons=len(comps),full_output_elements=sum(int(x[1]) for x in comps),failed_elements=sum(int(x[2]) for x in comps),profile_jobs=23,accepted_paired_sqtt=18,excluded_sparse_sqtt=3,excluded_nonpaired_complete_sqtt=2,formal_seven_block_acceptance=False,performance_goal_complete=False)
 assert summary['failed_elements']==0
 write(DEST/'jobs.json',jobs);write(DEST/'audit_summary.json',summary)
 names=['h3_hypothesis.json','h3_discovery_plan.json','h3_discovery_results.json','h3_discovery_analysis.json','h3_discovery_analysis.csv','h3_qualification.json','h3_qualification_audit.json','h3_profile_plan.json','h3_profile_selection_rule.json','profile_delivery_batch5.json','h3_sparse_capture_repair_plan.json','h3_sparse_capture_repair_attempts.json','h3_profile_excluded_records.json','h3_sparse_capture_repair_status.json','h3_permission_recovery_audit.json','h3_source_commit.json','h3_contract_cpu_audit.json','heldout_protocol.json','initial_files_sha256.json','compile/build5/results.json','compile/build6/results.json','compile/build6/source_sha256.json','compile/build6/shader_preservation.json','build6_h3_isa_audit.json','build6_h3_isa_audit_schedule.json','controller_history/h3_terminal/frozen_plan.json','controller_history/h3_terminal/active_build.json','controller_history/h3_terminal/h3_cpu_model.py','controller_history/h3_terminal/h3_cpu_model_result.json']
 for name in names:
  src=ROOT/name;dst=DEST/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  if dst.suffix=='.csv':dst.write_bytes(dst.read_bytes().replace(b'\r\n',b'\n'))
 (DEST/'initial_tracked.patch.gz').write_bytes(gzip.compress((ROOT/'initial_tracked.patch').read_bytes(),mtime=0))
 for name in ['profile_analysis.json','h3_static_schedule.json']:
  shutil.copy2(ROOT/'h3_profile_analysis'/name,DEST/name)
 pins=json.loads((ROOT/'compile/build6/source_sha256.json').read_text())
 for name,s in pins.items():
  data=(ROOT/'controller_history/h3_terminal/compiled_sources'/name).read_bytes();assert sha(data)==s
  dst=DEST/'compiled_sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 blobs={}
 for name in ['gates.jsonl','started.jsonl','kernel_checks.jsonl','stage_commands.jsonl','recovery_observations.jsonl']:
  src=ROOT/name
  if src.exists():blobs['journals/'+name]=src.read_bytes()
 for rec in jobs:
  for src in Path(rec['path']).iterdir():
   if src.is_file():
    assert src.suffix not in ['.perf','.co','.o','.isa']
    blobs['jobs/'+Path(rec['path']).name+'/'+src.name]=src.read_bytes()
 for name,s in {(n,s) for x in jobs for n,s in x['script_sha256'].items()}:
  src=ROOT/'source_versions'/(s+'_'+name);data=src.read_bytes();assert sha(data)==s;blobs['source_versions/'+src.name]=data
 for s in {x['plan_sha256'] for x in jobs}:blobs['manifests/'+s+'.json']=(ROOT/'manifests'/(s+'.json')).read_bytes()
 # Permission event was before GPU launch; preserve the stop and recovery evidence.
 for subdir in ['controller_history/h3_dmesg_permission_gate','controller_history/h3_sparse_sqtt_attempt1']:
  for src in (ROOT/subdir).rglob('*'):
   if src.is_file() and src.suffix in ['.json','.log','.jsonl']:blobs[str(src.relative_to(ROOT))]=src.read_bytes()
 for src in (ROOT/'recovery').rglob('*') if (ROOT/'recovery').exists() else []:
  if src.is_file() and src.suffix in ['.json','.log','.jsonl']:blobs[str(src.relative_to(ROOT))]=src.read_bytes()
 manifest=[]
 with tarfile.open(DEST/'raw_jobs.tar.gz','w:gz') as archive:
  for name,data in sorted(blobs.items()):
   item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;archive.addfile(item,io.BytesIO(data));manifest.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 with tarfile.open(DEST/'raw_jobs.tar.gz') as archive:
  assert len(archive.getmembers())==len(manifest)
  for expected,member in zip(manifest,archive.getmembers()):
   data=archive.extractfile(member).read();assert member.name==expected['path'] and len(data)==expected['bytes'] and sha(data)==expected['sha256']
 write(DEST/'raw_manifest.json',manifest)
 (DEST/'README.md').write_text('''# 协作A/B与三组操作数：代表集局部收益，未整域采用

85对发现全部完成，控制与候选均为同一build6正式benchmark/default selector、GPU4/epoch1。每臂全输出三次及真实guard，然后三轮AB/BA，warmup10/samples30/单launch/include_args_build0。全部回退和高CV保留，不混用不同构建的逐shape赢家，未做七block确认。

三个协作A/B配置K16D4、K16D8、K32D4的八代表GM candidate/base为1.115065、0.991590、0.942367。K32D4有6条改善>2%、2条回退>2%、1条高CV，5条点估计改善≥5%；没有证明完整属性域可采用，不计入50稳定/30可归因跨桶。短线三配置GM均>1。四组同GPU代码direct/legacy入口控制也未证明广泛host收益。详细正负结果见h3_discovery_analysis.csv/json。

H3独立实现使用完整CTA M所有权、协作A/B共享LDS、三组操作数读t+2/计算t，以及Global预取t+D+1。M≤32为1M×4N wave，M64为2M×2N；并非A寄存器/B私有LDS。共享LDS不是V7独有架构，独立代码是否有效须以当前最佳CK对照验证。旧5003实际64×128×16、5008实际64×128×32，不能把small_m128误解为M128，也不能把M64收益全归因去除M256填充。

18份有效SQTT组成9对，第5批包路径/大小/SHA见profile_delivery_batch5.json；包含固定收益、短线及回退、四组相同GPU代码的host路线控制。所有原名和sidecar保持。未在本机运行Windows XCompute，不能宣称GUI已解码。LDS冲突约.25～.28接近对照、HBM约一份输入，不支持B大规模重复的根因解释；两stage提前LDS读通过真实循环CFG及寄存器依赖静态核对，静态顺序不证明实际重叠。profiler时长和不同wave累计Latency不是正式成绩。

首次资格在任何H3 GPU启动前因sandbox无权读dmesg停止。原stop和manifest保留，具权限独立新进程依原门禁恢复：两次健康间隔60.196秒、固定SHA5000全输出探针PASS、epoch0→1、恢复445.379秒全部计入期限，无驱动重启/切卡/门禁绕过。build5另有query变量shadowing普通编译失败，保留结果；仅host变量改名后build6通过，不称MKFD。

短76原SQTT稀疏及后续两个采集位置稀疏均保留；只依登记的CU索引0/1/2顺序成对重采，不改shape/kernel/正式85对或4096token门槛。23个profile作业中18份成对有效、3份稀疏、2份原本完整但被成对重采替代；原数据仍在现场。全部作业ok表示进程/门禁有效，不表示每个SQTT都通过完整性门槛。

raw_jobs.tar.gz归档786物理作业、相关门禁/命令/脚本/manifest以及权限和稀疏事件，逐成员SHA核对；perf、二进制、厂商ISA不入Git。compiled_sources保留build6实际输入，与source_sha256逐字核对，包含已记录的初始用户overlay；源代码自有增量提交5e86b6e，初始用户修改未代为提交。原1193/冻结BLAS/旧Excel未改，无全量GPU复测。后续有限深度/host因素实验及其成绩不属于本归档。
''',encoding='utf-8')
 files=[dict(path=str(p.relative_to(DEST)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(DEST.rglob('*')) if p.is_file()]
 write(DEST/'manifest.json',files);print('H3_ARCHIVE_PASS',len(jobs),len(manifest),len(files),summary,flush=True)

if __name__=='__main__':main()
