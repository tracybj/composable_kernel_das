"""Commit only P6l source increments after complete GPU qualification.
Uses an isolated index; leaves every worktree byte and initial user edit intact.
"""
from pathlib import Path
import difflib,hashlib,json,os,re,subprocess,sys,datetime
ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/composable_kernel')
def git(*args,env=None,text=False):return subprocess.check_output(['git',*args],cwd=REPO,env=env,text=text)
def main():
 frozen=json.loads((ROOT/'frozen_plan.json').read_text());assert frozen['phase']=='h3_cooperative_discovery'
 epoch=json.loads((ROOT/'environment_epoch.json').read_text())['id'] if (ROOT/'environment_epoch.json').exists() else 0
 qualified=[x for x in json.loads((ROOT/'h3_qualification.json').read_text()) if x['plan_sha256']==frozen['plan_sha256'] and x['epoch']==epoch]
 assert len(qualified)==83 and all(x['ok'] for x in qualified),'All83 current qualifications must pass first'
 for n,s in frozen['worktree_source_sha256'].items():assert hashlib.sha256((REPO/n).read_bytes()).hexdigest()==s
 assert not git('diff','--cached','--name-only').strip(),'Do not disturb an existing staged change'
 helper=(ROOT/'prepare_h3_own_commit.py').read_text().replace("stage=ROOT/'commit_preparation_h3'","stage=ROOT/'commit_preparation_h3_final'")
 path=ROOT/'prepare_h3_final_own_commit.py';assert not path.exists();path.write_text(helper)
 subprocess.run([sys.executable,'-B',str(path)],check=True)
 stage=ROOT/'commit_preparation_h3_final';pure=stage/'own_tree';proof=json.loads((stage/'proof.json').read_text())
 # Tests already passed on the pre-fix pure selector/headers. Only the query
 # local variable rename changed after that CPU proof; verify exact equality.
 oldpure=ROOT/'commit_preparation_h3/own_tree'
 for name in ['include/ck_tile/ops/gemm/grouped_gemm_selector.hpp','include/ck_tile/ops/gemm/grouped_gemm_device_args.h','example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args.cpp','example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_decode_mainline_selector_test.cpp']:
  assert (pure/name).read_bytes()==(oldpure/name).read_bytes(),name
 cpu=json.loads((ROOT/'commit_preparation_h3/cpu_tests.json').read_text());assert len(cpu)==3 and all(x['rc']==0 for x in cpu)
 assert json.loads((ROOT/'commit_preparation_h3/capi_syntax.json').read_text())['rc']==0
 base=json.loads((ROOT/'compile/h2_probe/command.json').read_text())['command'];cmd=base[:base.index('-o')]
 cmd[1:1]=['-I'+str(pure/'include')]
 cmd+=['-I'+str(REPO/'example_hcu/ck_tile/19_grouped_gemm'),'--offload-host-only','-fsyntax-only',str(pure/'example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args_query_test.cpp')]
 test=subprocess.run(cmd,capture_output=True,text=True);(stage/'query_syntax.json').write_text(json.dumps(dict(command=cmd,rc=test.returncode,stdout=test.stdout,stderr=test.stderr,gpu=False),indent=2)+'\n');assert test.returncode==0,test.stderr
 worktree={x['path']:(REPO/x['path']).read_bytes() for x in proof}
 index=stage/'isolated.index';env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
 subprocess.run(['git','read-tree','HEAD'],cwd=REPO,env=env,check=True)
 owned=[]
 for x in proof:
  name=x['path'];data=(pure/name).read_bytes();blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=REPO,input=data).decode().strip()
  subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+name],cwd=REPO,env=env,check=True);owned.append((name,blob))
 staged=git('diff','--cached','--name-only',env=env,text=True).splitlines();assert staged and set(staged)<=set(worktree)
 subprocess.run(['git','diff','--cached','--check'],cwd=REPO,env=env,check=True)
 subprocess.run(['git','commit','-m','feat: add cooperative decode operand pipeline and direct routes (实验用，不合入)'],cwd=REPO,env=env,check=True)
 head=git('rev-parse','HEAD',text=True).strip()
 # Advance only our paths in the normal index to the committed pure versions.
 for name,blob in owned:subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+name],cwd=REPO,check=True)
 assert not git('diff','--cached','--name-only').strip()
 assert all((REPO/n).read_bytes()==b for n,b in worktree.items())
 initial=(ROOT/'initial_tracked.patch').read_text();actual=git('diff',text=True)
 def edits(patch):
  out={};current=None
  for line in patch.splitlines():
   if line.startswith('+++ b/'):current=line[6:];out.setdefault(current,[])
   elif current and line[:1] in ['+','-'] and not line.startswith(('+++','---')):
    if re.search(r'(GroupedGemmCandidateIdentity|CandidateExpected), \d+>',line):line=re.sub(r', \d+>',', COUNT>',line)
    out[current].append(line)
  return {k:v for k,v in out.items() if v}
 assert edits(actual)==edits(initial),'Residual initial user changes differ'
 assert hashlib.md5(git('diff','--','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp')).hexdigest()=='4c7f49a5c7592767d53195a713db6b8a'
 result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=head,changed_files=staged,worktree_bytes_unchanged=True,initial_tracked_user_edits_preserved=True,readfirstlane_preserved=True,push=False,qualification_manifest=frozen['plan_sha256'])
 (ROOT/'h3_source_commit.json').write_text(json.dumps(result,indent=2)+'\n');print('H3_OWN_ONLY_SOURCE_COMMIT_VERIFIED',head,len(staged),flush=True)
if __name__=='__main__':main()
