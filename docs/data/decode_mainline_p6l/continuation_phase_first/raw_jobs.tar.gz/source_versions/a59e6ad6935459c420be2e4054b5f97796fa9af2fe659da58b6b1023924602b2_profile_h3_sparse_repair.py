"""Bounded diagnostic CU fallback; keeps shapes, kernels and all formal data.
Only sparse SQTT is retried. Dispatch/identity/environment errors stop at once.
"""
from pathlib import Path
import json,re,uuid,subprocess,sys
import plan,runtime as r,campaign as c,profile_capture as trace,profile_h3 as original
ROOT=Path(__file__).resolve().parent

def main():
 r.no_core();site=r.Site(ROOT);rule,selection,results=original.select(site)
 assert site.epoch()==1
 self_sha=plan.sha(__file__);source_sha=plan.sha(ROOT/'h3_discovery_results.json')
 configs={x['key']:x for x in r.read(ROOT/'h3_discovery_plan.json')['discovery_pairs']}
 captures=r.read(ROOT/'h3_profiles.json');partial=[p['pair'] for p in selection['chosen'] if len([x for x in captures if x['pair']==p['pair']])==1]
 assert partial==['id76_direct_short_both']
 history=ROOT/'controller_history/h3_sparse_sqtt_attempt1';history.mkdir(parents=True,exist_ok=False)
 for name in ['h3_profiles.json','h3_profile_plan.json','h3_profile_selection_rule.json','h3_sparse_original_attempt.json','frozen_plan.json','h3_permission_resume_sequence.json','post_h3_profile_controller.json']:
  (history/name).write_bytes((ROOT/name).read_bytes())
 removed=[x for x in captures if x['pair'] in partial];captures=[x for x in captures if x['pair'] not in partial]
 r.write(ROOT/'h3_profile_excluded_records.json',dict(partial_pair_records=removed,sparse_attempt=r.read(ROOT/'h3_sparse_original_attempt.json'),reason='Retain all original files. Recapture both arms on one CU index so a pair never mixes capture locations.'))
 repair=dict(at=r.stamp(),original_rule_sha256=selection['rule_sha256'],original_selection_sha256=plan.sha(ROOT/'h3_profile_plan.json'),formal_results_sha256=source_sha,plan_sha256=site.manifest['plan_sha256'],binary_sha256=site.manifest['benchmark_sha256'],epoch=site.epoch(),minimum_raw_token_bytes=4096,SE=0,target_cu_order=[0,1,2],partial_pairs_start_at_cu1=partial,max_CU_choices_per_pair=3,shapes_and_kernels_unchanged=True,no_performance_rerun=True,script_sha256=self_sha)
 r.write(ROOT/'h3_sparse_capture_repair_plan.json',repair);repair_sha=plan.sha(ROOT/'h3_sparse_capture_repair_plan.json');r.write(ROOT/'h3_profiles.json',captures)
 attempts=[]
 with r.locked():
  for chosen in selection['chosen']:
   row=results[chosen['pair']];assert row['epoch']==site.epoch()==1
   old=[x for x in captures if x['pair']==row['pair']]
   if len(old)==2:
    assert {x['role'] for x in old}=={'base','candidate'} and len({x['active_CU_index'] for x in old})==1;continue
   assert not old
   choices=[1,2] if row['pair'] in partial else [0,1,2]
   for cu in choices:
    pair_entries=[];sparse=False
    for role in ['base','candidate']:
     assert plan.sha(__file__)==self_sha and plan.sha(ROOT/'h3_sparse_capture_repair_plan.json')==repair_sha and plan.sha(ROOT/'h3_discovery_results.json')==source_sha
     case=configs[row['pair']][role];label=role+'_'+row['variant'];key=f'h3fix_id{row["ID"]}_{label}_cu{cu}_{uuid.uuid4().hex[:8]}'
     folder=ROOT/'profiles_h3'/key;folder.mkdir(parents=True,exist_ok=False)
     spec=c.ck(case,'perf',key);app=[a.replace('--samples=30','--samples=1').replace('--validate=1','--validate=0') for a in spec['command']]
     kernel,expected=original.kernel_identity(case)
     cmd=[str(c.XPROF),'--enable-sqtt','--enable-raw','--target-se','0','--target-cu',str(cu),'--dispatches',str(rule['dispatch']),'--kernels',kernel,'--sections',rule['sections'],'--output-dir',str(folder),*app]
     spec.update(kind='profile',command=cmd,variant=label,purpose='h3_profile_repair',sqtt=True,capture_timing_is_formal=False,prior_accuracy_keys=chosen['precision_keys'],capture_script_sha256=self_sha,profile_rule_sha256=selection['rule_sha256'],repair_rule_sha256=repair_sha)
     rec=site.execute(spec);inventory=trace.trace_inventory(folder)
     log=Path(rec['path'],'run.log').read_text();dispatches=[int(x) for x in re.findall(r'== dispatch kernel \[(\d+)\]',log)];assert dispatches==[18],('Dispatch mismatch, no sparse retry',dispatches)
     txt=(folder/'results.txt').read_text();name=re.search(r'kernel-name\((.*?)\), start_ts',txt)[1];normal=re.sub(r'\s+','',name)
     assert expected is None or expected in normal,('Identity mismatch, no retry',expected,name)
     assert 'dispatch[18], gpu-id(4)' in txt
     valid=inventory['raw_token_bytes']>=4096
     attempts.append(dict(pair=row['pair'],role=role,CU_index=cu,job_key=rec['key'],raw_token_bytes=inventory['raw_token_bytes'],accepted_token_gate=valid,inventory=inventory,actual_kernel=name));r.write(ROOT/'h3_sparse_capture_repair_attempts.json',attempts)
     entry=dict(ID=row['ID'],pair=row['pair'],role=role,arm=label,variant=row['variant'],route_compare=row.get('route_compare',False),shape=row['shape'],dtype='BF16',layout='NN',stage='sqtt',epoch=rec['epoch'],physical_gpu=4,key=rec['key'],actual_instance=case['expected'],algorithm_id=None,kernel_filter=kernel,actual_kernel=name,expected_kernel=expected,dispatches=dispatches,selected_dispatch=18,XCD=0,SE=0,active_CU_index=cu,sqtt=True,raw_log=str(Path(rec['path'])/'run.log'),benchmark_sha256=site.manifest['benchmark_sha256'],binary_sha256=rec['binary_sha256'],collection_command=cmd,environment=rec['environment'],prior_accuracy_keys=chosen['precision_keys'],plan_sha256=rec['plan_sha256'],source_sha256=site.manifest['worktree_source_sha256'],script_sha256=rec['script_sha256'],formal_timing=False,point_base_ms=row['base_ms'],point_candidate_ms=row['candidate_ms'],point_delta_pct=row['delta_pct'],sparse_repair_rule_sha256=repair_sha,**inventory)
     pair_entries.append(entry)
     if not valid:
      sparse=True;print('H3_SPARSE_CU_ATTEMPT_RETAINED',row['pair'],role,cu,inventory['raw_token_bytes'],flush=True);break
    if not sparse:
     assert len(pair_entries)==2;captures+=pair_entries;r.write(ROOT/'h3_profiles.json',captures);print('H3_REPAIRED_PROFILE_PAIR_PASS',row['pair'],'CUindex',cu,flush=True);break
   else:raise RuntimeError('Three predeclared CU choices exhausted; retain all traces and stop')
 assert len(captures)==2*len(selection['chosen'])==18
 r.write(ROOT/'h3_sparse_capture_repair_status.json',dict(at=r.stamp(),state='captures_complete',captures=len(captures),epoch=site.epoch(),formal_results_sha256_unchanged=plan.sha(ROOT/'h3_discovery_results.json')==source_sha))
 for name in ['analyze_h3_profiles.py','deliver_h3_repaired.py']:
  child=subprocess.run([sys.executable,'-B',str(ROOT/name)],stdin=subprocess.DEVNULL);assert child.returncode==0,(name,child.returncode)
 r.write(ROOT/'h3_sparse_capture_repair_status.json',dict(at=r.stamp(),state='complete',captures=len(captures),epoch=site.epoch()))
 print('H3_SPARSE_REPAIR_AND_DELIVERY_PASS',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:r.write(ROOT/'h3_sparse_capture_repair_status.json',dict(at=r.stamp(),state='stopped',error=repr(e)));raise
