"""Deliver every preregistered H1 pair, including all measured regressions."""
from pathlib import Path
import csv, hashlib, json, shutil, tarfile
import runtime as r
ROOT = Path(__file__).resolve().parent

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    captures = r.read(ROOT/'h1_profiles.json')
    selected = r.read(ROOT/'h1_profile_plan.json')['chosen']
    assert len(captures) == 2*len(selected) == 8
    assert {(x['pair'], x['role']) for x in captures} == {
        (x['pair'], role) for x in selected for role in ['base', 'candidate']}
    analysis = ROOT/'h1_profile_analysis'
    isa = {(x['ID'], x['arm']): x for x in r.read(analysis/'profile_isa.json')}
    metrics = {(x['ID'], x['arm']): x for x in r.read(analysis/'profile_analysis.json')['rows']}
    target = ROOT/'delivery/batch2_h1_current_candidate'
    assert not target.exists(), 'Preserve old delivery packages'
    target.mkdir(parents=True)
    manifest = []
    readme = ['# 当前最佳CK与H1独立候选：四组成对SQTT', '',
      '四组均为回退结果；这是诊断包，不是采用范围或正式计时。正式三轮结果见mainline_discovery_analysis.csv。', '',
      '完整解压后保留captures中的原始名字与相对依赖。XCompute中File → Open打开.perf，Result选择dispatch18和以下kernel，XCD0；捕获SE0、active-CU-index0。',
      '先核对Summary资源；Source恢复全范围，按下列PC定位重复K主循环；Wavefronts先缩到全kernel，再放大中间重复段，对比vmcnt/lgkmcnt与MMAC的顺序和空隙。准确GUI时间区间需打开后确定，本机未运行Windows GUI。',
      '本机已核对全部文件SHA、SQTT token字节数/results.txt、实际dispatch和代码。PMC多次重放会改变缓存状态；不同wave累计Latency不能相加当墙钟；wait占比不是单独的因果证明。',
      '', '## 需要共同确认', '',
      '- ID621/805：候选每wave VMEM指令明显增加，等待计数占wave周期约77%/82%；对照约14%/17%。请确认主要停顿对应A加载、B入LDS还是操作数等待，并查看计算是否能覆盖等待。',
      '- ID1072：HBM总流量均接近一份输入，但候选等待占比约87%。不能把该差距归因为B大量重复读取。',
      '- ID76：候选资源和MMAC浪费下降，正式计时仍回退；其SQTT单次时长反而较快，不能取代三轮正式结果。请关注预热、主循环和写回占用。',
      '- 当前证据支持研究减少A的多指令加载及共享复用、调整全局与操作数流水；尚不能证明单独改A或单独改等待即可获益。', '']
    for cap in captures:
        key = cap['ID'], cap['arm']
        code, metric = isa[key], metrics[key]
        source = Path(next(x['path'] for x in cap['files'] if x['path'].endswith('.perf'))).parent
        rel = Path('captures')/source.name
        shutil.copytree(source, target/rel)
        entry = {k: v for k, v in cap.items() if k not in ['files', 'raw_log']}
        entry.update(kernel_name=code['captured_kernel'], machine_sha256=code['sha256'],
                     resources=metric['geometry'], files=[])
        for item in cap['files']:
            p = target/rel/Path(item['path']).relative_to(source)
            assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256']
            entry['files'].append(dict(path=str(p.relative_to(target)), bytes=p.stat().st_size, sha256=sha(p)))
        assert cap['raw_token_bytes'] >= 4096 and code['unknown_lines'] == 0
        manifest.append(entry)
        perf = next(x for x in entry['files'] if x['path'].endswith('.perf'))
        readme += [f'## ID{cap["ID"]} {cap["arm"]}', '',
          f'- MNKG：{cap["shape"]}；实际实例{cap["actual_instance"]}；物理GPU4/epoch{cap["epoch"]}。',
          f'- 文件：`{perf["path"]}`；dispatch18/XCD0。',
          f'- kernel：`{code["captured_kernel"]}`。',
          f'- 资源：{metric["geometry"]}；SQTT token {cap["raw_token_bytes"]}字节。',
          f'- 主循环PC：`{code["main_loop_candidates"]}`。',
          f'- 正式三轮baseline/candidate：{cap["point_base_ms"]}/{cap["point_candidate_ms"]}ms，候选耗时变化{cap["point_delta_pct"]:+.3f}%。',
          '- Source搜索buffer_load_dwordx2、buffer_load_dwordx4、ds_read、s_waitcnt、v_mmac。候选A为dwordx2到寄存器；B为dwordx4到LDS。', '']
        readme.extend('  指令PC定位：`'+z['text']+'`' for z in code['instruction_anchors'][:12])
        readme.append('')
    r.write(target/'profile_manifest.json', manifest)
    fields = ['ID','M','N','K','G','role','variant','actual_instance','selected_dispatch','XCD','physical_gpu','epoch','raw_token_bytes','perf_path','perf_bytes','perf_sha256','kernel_name']
    with (target/'profile_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fields);w.writeheader()
        for x in manifest:
            perf=next(z for z in x['files'] if z['path'].endswith('.perf'))
            row={k:x.get(k) for k in fields};row.update(x['shape']);row.update(perf_path=perf['path'],perf_bytes=perf['bytes'],perf_sha256=perf['sha256']);w.writerow(row)
    for name in ['h1_profile_plan.json','h1_profile_selection_rule.json','mainline_discovery_analysis.csv','mainline_discovery_analysis.json']:
        shutil.copy2(ROOT/name,target/name)
    shutil.copy2(analysis/'profile_analysis.json',target/'profile_analysis.json')
    (target/'XCOMPUTE_README.md').write_text('\n'.join(readme),encoding='utf-8')
    package=target.parent/'P6l_batch2_H1_current_candidate_SQTT.tar.gz'
    assert not package.exists()
    with tarfile.open(package,'w:gz') as archive:archive.add(target,arcname=target.name)
    r.write(ROOT/'profile_delivery_batch2.json',dict(at=r.stamp(),path=str(package),bytes=package.stat().st_size,sha256=sha(package),captures=8,gui_verified=False,local_integrity_checked=True))
    print('H1_PROFILE_DELIVERY_PASS',package,package.stat().st_size,sha(package),flush=True)

if __name__ == '__main__':main()
