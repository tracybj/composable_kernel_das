"""Archive terminal depth/host discovery before independently confirming a domain."""
from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,shutil,tarfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
DEST=REPO/'docs/data/decode_mainline_p6l/h3_factors'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')

def main():
 assert not DEST.exists();DEST.mkdir(parents=True)
 assert json.loads((ROOT/'postbuild_h3_factors_controller.json').read_text())['state']=='complete'
 analysis=json.loads((ROOT/'h3_factors_discovery_analysis.json').read_text());assert analysis['completed_pairs']==116
 jobs=[json.loads(s) for s in (ROOT/'jobs.jsonl').read_text().splitlines() if s]
 jobs=[x for x in jobs if x.get('purpose') in ['h3_factors_qualification','h3_factors_representatives','h3_factors_profile']]
 assert len(jobs)==1069 and all(x['ok'] and x['epoch']==1 for x in jobs)
 attempts=json.loads((ROOT/'h3_factors_profile_attempts.json').read_text());captures=json.loads((ROOT/'h3_factors_profiles.json').read_text())
 assert len(attempts)==29 and len(captures)==28 and sum(not x['accepted_token_gate'] for x in attempts)==1
 comps=[c for x in jobs if x['kind']=='accuracy' for c in x['comparisons']]
 summary=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),physical_gpu=4,epoch=1,jobs=len(jobs),purposes=dict(collections.Counter(x['purpose'] for x in jobs)),qualification_jobs=112,formal_pairs=116,full_output_comparisons=len(comps),full_output_elements=sum(int(x[1]) for x in comps),failed_elements=sum(int(x[2]) for x in comps),accepted_paired_sqtt=28,profile_jobs=29,excluded_sparse_sqtt=1,excluded_complete_sqtt=0,formal_seven_block_acceptance=False,performance_goal_complete=False)
 assert len(comps)==1026 and summary['failed_elements']==0
 write(DEST/'audit_summary.json',summary)
 ledger=json.dumps(jobs,indent=2).encode();(DEST/'jobs.json.gz').write_bytes(gzip.compress(ledger,mtime=0));assert json.loads(gzip.decompress((DEST/'jobs.json.gz').read_bytes()))==jobs
 names=['h3_factors_hypothesis.json','h3_factors_preregistration_addendum.json','h3_factors_discovery_plan.json','h3_factors_discovery_results.json','h3_factors_discovery_analysis.json','h3_factors_discovery_analysis.csv','h3_factors_qualification.json','h3_factors_qualification_audit.json','h3_factors_profile_plan.json','h3_factors_profile_selection_rule.json','h3_factors_profiles.json','h3_factors_profile_attempts.json','profile_delivery_batch6.json','h3_factors_source_commit.json','h3_factors_contract_cpu_audit.json','h3_factors_plan_artifact_pin.json','h3_factors_plan_artifact_pin_audit.json','h3_factors_pre_gpu_review.json','heldout_protocol.json','heldout_exclusion_extension_cpu.json','heldout_cpu_exclusion_audit.json','cpu_h3_factors/tests.json','cpu_h3_factors/discovery_audit.json','h3_factors_host_syntax.json','cpu_host_policy_factors/results.json','cpu_host_policy_factors/public_disable_flags_equivalence.json','cpu_host_policy_factors/policy_equivalence.cpp','cpu_host_policy_factors/ldd.txt','commit_preparation_h3_factors/proof.json','commit_preparation_h3_factors/cpu_tests.json','commit_preparation_h3_factors/host_syntax.json','compile/build7/source_sha256.json','compile/build7/results.json','compile/build7/shader_preservation.json','build7_h3_isa_audit.json','build7_h3_isa_audit_schedule.json','controller_history/h3_factors_terminal/frozen_plan.json','controller_history/h3_factors_terminal/active_build.json','controller_history/h3_factors_terminal/postbuild_h3_factors_controller.json','controller_history/h3_factors_terminal/h3_cpu_model.py','controller_history/h3_factors_terminal/h3_cpu_model_result.json','initial_files_sha256.json']
 for name in names:
  src=ROOT/name;dst=DEST/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  if dst.suffix=='.csv':dst.write_bytes(dst.read_bytes().replace(b'\r\n',b'\n'))
 (DEST/'initial_tracked.patch.gz').write_bytes(gzip.compress((ROOT/'initial_tracked.patch').read_bytes(),mtime=0))
 for name in ['profile_analysis.json','h3_static_schedule.json']:
  shutil.copy2(ROOT/'h3_factors_profile_analysis'/name,DEST/name)
 pins=json.loads((ROOT/'compile/build7/source_sha256.json').read_text())
 for name,s in pins.items():
  data=(ROOT/'controller_history/h3_factors_initial/compiled_sources'/name).read_bytes();assert sha(data)==s
  dst=DEST/'compiled_sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 blobs={}
 for name in ['gates.jsonl','started.jsonl','kernel_checks.jsonl','stage_commands.jsonl']:
  blobs['journals/'+name]=(ROOT/name).read_bytes()
 for record in jobs:
  for src in Path(record['path']).iterdir():
   if src.is_file():
    assert src.suffix not in ['.perf','.co','.o','.isa']
    blobs['jobs/'+Path(record['path']).name+'/'+src.name]=src.read_bytes()
 for name,s in {(n,s) for x in jobs for n,s in x['script_sha256'].items()}:
  src=ROOT/'source_versions'/(s+'_'+name);data=src.read_bytes();assert sha(data)==s;blobs['source_versions/'+src.name]=data
 for s in {x['plan_sha256'] for x in jobs}:blobs['manifests/'+s+'.json']=(ROOT/'manifests'/(s+'.json')).read_bytes()
 for name in ['build7_verified_process_wait.json','build7_compiler_observations.jsonl','verified_waits.jsonl']:
  blobs['build_wait/'+name]=(ROOT/name).read_bytes()
 for name in ['run.log','public_disable_flags_run.log']:
  blobs['cpu_host_policy_factors/'+name]=(ROOT/'cpu_host_policy_factors'/name).read_bytes()
 raw=[]
 with tarfile.open(DEST/'raw_jobs.tar.gz','w:gz') as archive:
  for name,data in sorted(blobs.items()):
   item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;archive.addfile(item,io.BytesIO(data));raw.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 with tarfile.open(DEST/'raw_jobs.tar.gz') as archive:
  assert len(archive.getmembers())==len(raw)
  for expected,member in zip(raw,archive.getmembers()):
   data=archive.extractfile(member).read();assert member.name==expected['path'] and len(data)==expected['bytes'] and sha(data)==expected['sha256']
 write(DEST/'raw_manifest.json',raw)
 (DEST/'README.md').write_text('''# K32预取深度与host策略解析：完整发现，尚未采用

全部116对完成，均由同一build7正式benchmark/default selector、GPU4/epoch1测得。每臂先全输出三次与真实guard，再三轮AB/BA，warmup10/samples30/单launch/include_args_build0；全部回退和高CV保留。112资格验证通过；本归档不包含七block独立确认，不计为50/30性能目标达成。

协作A/B K32的D4full/D4fast/D5full/D5fast八代表几何平均候选/对照为.945576/.927456/.940887/.933936，均6改善>2%、2回退>2%、1高CV。提前登记的M>=17或K>=6144子域中六代表D4fast/D5fast为.893778/.891733，平均差别很小，不足证明五级普遍更好。四个深度直接控制分别+2.949%、-2.699%、-1.277%、-1.176%，无高CV；必须按完整属性域决定采用，不能逐ID挑赢家。

短线XORfast/BOTHfast九代表GM为.969254/.963239，均无>2%中位回退，但5/6条高CV；未完成稳定性证明。四组同GPU kernel的host控制实际符号/机器码一致，正式变化为-1.555%/-0.786%/-10.813%/-5.846%，两条短线高CV。它们支持进一步核对host成本，不能把所有变化归因于流水本体。

28份有效SQTT组成14对，含固定主线/短线、gain/flat/loss样本、四组host和四组深度控制。29次采集有一份稀疏trace，保留并按预声明CU索引顺序重采；不改变shape、kernel或4096token门槛。下载包见profile_delivery_batch6.json，10188506字节/SHA429cf850856d86aab0263a3041b102b1d2c9357be6d57b428bf8903f01a2e247，GUI未在本机打开。ID788回退样本HBM接近一份输入，baseline8wave/64KiB与候选4wave/45KiB的驻留/请求并行度值得后续检查，不能仅从低wait比例推断更快。

build7用时3303.075秒；原1574+前序120 shader机器码不变，新增总数126。12个gfx936协作核无scratch/spill，三bank静态数据流核对通过。1750新选核、1063 Depth8及旧selector通过；51317 CPU策略场景及额外3456个有效几何/公开禁用位场景通过。源码自有增量本地实验提交5c9d3f7，初始用户overlay与readfirstlane保留，公开v1 struct/GemmTransKernelArg不改。

jobs.json.gz为完整1069作业ledger的无损gzip；raw_jobs.tar.gz保留原始作业/门禁/脚本版本/manifest和CPU日志，raw_manifest.json逐成员SHA核对。compiled_sources与build7实际15份输入逐字匹配，包含已记录的初始用户overlay。perf、二进制和厂商ISA不入Git；51k CPU测试输入由保留的确定性生成脚本和冻结P6k重建，不将大体积展开输入提交Git。

原P6k、1193形状表、冻结BLAS和旧Excel未改，无全量GPU复测。后续最终候选必须冻结可解释属性范围，包含全部原表成员及已有赢家、至少24个未见合成shape，并按预先固定七block规则确认。混合历史投影不能冒充新鲜1193结果。
''',encoding='utf-8')
 files=[dict(path=str(p.relative_to(DEST)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(DEST.rglob('*')) if p.is_file()]
 write(DEST/'manifest.json',files);print('H3_FACTORS_ARCHIVE_PASS',len(jobs),len(raw),len(files),summary,flush=True)

if __name__=='__main__':main()
