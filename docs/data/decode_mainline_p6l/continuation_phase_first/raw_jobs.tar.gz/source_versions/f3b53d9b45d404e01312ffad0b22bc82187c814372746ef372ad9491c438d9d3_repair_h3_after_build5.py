"""One explicit host-only query repair after the pinned build is terminal.
Never cancels compilation, retries GPU failures, resets a device, or extends time.
"""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/composable_kernel')
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
OLD=json.loads((ROOT/'active_build.json').read_text())
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2)+'\n');tmp.replace(p)
def state(**v):write(ROOT/'h3_host_repair_sequence.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),**v))
def guard():
 assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
 assert time.time()+60<read(ROOT/'session.json')['gpu_deadline_epoch']
 assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
def main():
 assert OLD['folder']=='compile/build5'
 state(state='waiting_for_original_build5_and_postbuild',build=OLD)
 while True:
  guard();assert read(ROOT/'active_build.json')==OLD
  stages=read(ROOT/'compile/build5/results.json')
  post=read(ROOT/'postbuild_h3_controller.json')
  if len(stages)==2:
   assert stages[0]['rc']==0 and stages[1]['rc']!=0,'Expected only known query-target failure; no automatic alternative repair'
   if post.get('build_folder')==OLD['folder'] and post.get('state')=='stopped':break
  time.sleep(15)
 guard();log=(ROOT/'compile/build5/1_build.log').read_text()
 assert 'declaration shadows a local variable' in log and 'grouped_gemm_device_args_query_test.cpp' in log
 preview=read(ROOT/'h3_query_fix_preview_syntax.json');assert preview['rc']==0
 assert not (ROOT/'h3_qualification.json').exists() and not (ROOT/'h3_discovery_results.json').exists(),'No pre-repair GPU work expected'
 issue=read(ROOT/'h3_pending_host_query_fix.json');source=REPO/'example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args_query_test.cpp'
 assert hashlib.sha256(source.read_bytes()).hexdigest()==issue['source_sha256_before']
 history=ROOT/'controller_history/build5_query_host_failure';history.mkdir(parents=True,exist_ok=False)
 for n in ['active_build.json','postbuild_h3_controller.json','post_h3_profile_controller.json','h3_query_host_syntax.json','h3_pending_host_query_fix.json','pending_h3_query_host_fix.patch']:
  p=ROOT/n
  if p.exists():(history/n).write_bytes(p.read_bytes())
 subprocess.run(['git','apply','--check',str(ROOT/'pending_h3_query_host_fix.patch')],cwd=REPO,check=True)
 subprocess.run(['git','apply',str(ROOT/'pending_h3_query_host_fix.patch')],cwd=REPO,check=True)
 assert source.read_bytes()==Path(preview['command'][-1]).read_bytes()
 # Retain the old source preparation and add an explicit repaired pure file.
 pure=ROOT/'commit_preparation_h3/own_tree'/source.relative_to(REPO)
 old=pure.read_text();fixed=old.replace('auto invalid = make_selection();','auto malformed_variant_selection = make_selection();').replace('&probe, &invalid) == 0;','&probe, &malformed_variant_selection) == 0;').replace('decode_pass &= invalid.instance_id == off.instance_id;','decode_pass &= malformed_variant_selection.instance_id == off.instance_id;')
 (ROOT/'commit_preparation_h3/query_pure_repaired.cpp').write_text(fixed)
 handle=read(ROOT/'h3_repair_outer_handle.json')['exec_session']
 active=dict(folder='compile/build6',exec_session=handle,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),script='repair_h3_after_build5.py',build_script='build_h3_6.py',note='One host query variable rename; no pipeline/GPU protocol change')
 write(ROOT/'active_build.json',active)
 state(state='building6',build=active,original_build5_terminal=stages)
 child=subprocess.Popen([sys.executable,'-B','-u',str(ROOT/'build_h3_6.py')],stdin=subprocess.DEVNULL);rc=child.wait();assert rc==0,('Incremental build6 failed; stop',rc)
 guard();state(state='postbuild6_and_profiles',build=active)
 postchild=subprocess.Popen([sys.executable,'-B','-u',str(ROOT/'after_h3_build.py')],stdin=subprocess.DEVNULL)
 while True:
  guard();post=read(ROOT/'postbuild_h3_controller.json')
  if post.get('build_folder')==active['folder']:break
  time.sleep(1)
 profchild=subprocess.Popen([sys.executable,'-B','-u',str(ROOT/'profile_after_h3_v2.py')],stdin=subprocess.DEVNULL)
 postrc=postchild.wait();profrc=profchild.wait()
 state(state='complete' if postrc==profrc==0 else 'stopped',build=active,postbuild_rc=postrc,profile_rc=profrc,note='No seven-block acceptance from discovery')
 assert postrc==profrc==0,(postrc,profrc)
 print('H3_ONE_HOST_FIX_BUILD_DISCOVERY_PROFILE_SEQUENCE_PASS',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:state(state='stopped',error=repr(e));raise
