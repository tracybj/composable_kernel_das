"""Audit tuning code and require every original/H1/H2 shader to stay exact."""
from pathlib import Path
import argparse,mmap,re,sys
import runtime as r,shader_audit
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p6d')
import elf_isa as e

def main():
    ap=argparse.ArgumentParser();ap.add_argument('binary');ap.add_argument('--tag',default='tuning');ap.add_argument('--probe',action='store_true');a=ap.parse_args()
    old={} if a.probe else r.read(ROOT/'compile/build3/shader_preservation.json')['added']
    new=shader_audit.inventory(a.binary)
    assert all(k in new and new[k]['machine_sha256']==v['machine_sha256'] for k,v in old.items()),'An H1/H2 control shader changed'
    e.ROOT=ROOT;rows=[]
    with Path(a.binary).open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        fat=next(s for s in e.sections(data) if s['name']=='.hip_fatbin')
        for triple,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
            if 'gfx936' not in triple or code[:4]!=b'\x7fELF':continue
            sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
            for name in [n for n in md if 'DecodeNnSharedTunedKernel' in n]:
                match=re.search(r'DecodeNnSharedTunedKernelILi(\d+)ELi(\d+)ELi(\d+)ELb([01])ELb([01])EE',name);assert match,name
                rows_m,k,depth,early,xor=map(int,match.groups());tag=f'{a.tag}_m{rows_m*16}_k{k}_d{depth}_early{early}_xor{xor}'
                co=ROOT/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
                item=e.dump(co,code,sh,symbols,md,name,tag);meta=item['metadata'];op=item['opcodes']
                assert item['unknown_lines']==0 and meta.get('.private_segment_fixed_size',0)==0
                assert meta.get('.vgpr_spill_count',0)==meta.get('.sgpr_spill_count',0)==0
                assert op.get('buffer_load_ushort',0)==op.get('buffer_load_dwordx2',0)==0
                assert item['direct_lds_loads']>=2*depth*(1+k//16)
                assert op.get('v_mmac_f32_16x16x16_bf16',0)==4*rows_m*depth*(k//16)
                assert op.get('s_barrier',0)>=2*depth+1
                if early:
                    b=k//16;target=f'vmcnt({(b+1)*(depth-2)+b})'
                    assert target in item['wait_operands'],(target,item['wait_operands'])
                a_waves=(rows_m*16+(512//k)-1)//(512//k)
                item.update(row_fragments=rows_m,block_k=k,depth=depth,early_b=bool(early),xor_a=bool(xor),dynamic_lds_bytes=depth*(a_waves*1024+4*k*64))
                rows.append(item)
    assert len(rows)==27,len(rows)
    r.write(ROOT/(a.tag+'_tuning_isa_audit.json'),dict(ok=True,binary=a.binary,kernels=rows,preserved_H1_H2=len(old)))
    print('TUNING_ISA_AUDIT_PASS',len(rows),'preservedH1H2',len(old),flush=True)
    for x in rows:
        if x['block_k']==16:print('TUNED_ISA',x['row_fragments']*16,x['depth'],x['early_b'],x['xor_a'],'VGPR',x['metadata']['.vgpr_count'],'LDS',x['dynamic_lds_bytes'],flush=True)

if __name__=='__main__':main()
