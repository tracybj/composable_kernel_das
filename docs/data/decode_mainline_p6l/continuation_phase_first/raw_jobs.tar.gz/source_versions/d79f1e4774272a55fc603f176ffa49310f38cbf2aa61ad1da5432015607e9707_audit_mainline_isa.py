"""Verify actual standalone decode issue order and resource invariants."""
from pathlib import Path
import argparse,json,mmap,re,sys
import runtime as r
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p6d')
import elf_isa as e

def main():
 ap=argparse.ArgumentParser();ap.add_argument('binary');ap.add_argument('--tag',default='mainline');args=ap.parse_args();e.ROOT=ROOT
 rows=[]
 with Path(args.binary).open('rb') as stream,mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as data:
  fat=next(s for s in e.sections(data) if s['name']=='.hip_fatbin')
  for triple,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
   if 'gfx936' not in triple or code[:4]!=b'\x7fELF':continue
   sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
   selected=[n for n in md if 'DecodeNnMainlineKernel' in n]
   if not selected:continue
   for name in selected:
    match=re.search(r'DecodeNnMainlineKernelILi(\d+)ELi(\d+)ELi(\d+)ELb([01])EE',name);assert match,name
    fragments,depth,waves,overlap=map(int,match.groups());tag=f'{args.tag}_m{fragments*16}_d{depth}_w{waves}_op{overlap}'
    co=ROOT/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
    item=e.dump(co,code,sh,symbols,md,name,tag);m=item['metadata'];op=item['opcodes']
    assert item['unknown_lines']==0 and m.get('.private_segment_fixed_size',0)==0
    assert m.get('.vgpr_spill_count',0)==m.get('.sgpr_spill_count',0)==0
    assert op.get('s_barrier',0)==0 and item['direct_lds_loads']==2*depth
    assert op.get('buffer_load_dwordx2',0)==2*depth*fragments
    assert op.get('buffer_load_ushort',0)==0
    assert op.get('v_mmac_f32_16x16x16_bf16',0)==4*fragments*depth
    assert op.get('ds_read_m32x16_b16',0)==2*depth
    if overlap:assert item['wait_operands'].get('lgkmcnt(1)',0)==2*depth-1
    else:assert item['wait_operands'].get('lgkmcnt(1)',0)==0
    item.update(row_fragments=fragments,depth=depth,waves=waves,operand_lookahead=bool(overlap),dynamic_lds_bytes=depth*waves*1024)
    rows.append(item)
 assert len(rows)==15,len(rows)
 r.write(ROOT/(args.tag+'_isa_audit.json'),dict(ok=True,binary=args.binary,kernels=rows))
 print('MAINLINE_ISA_AUDIT_PASS',args.tag,'kernels',len(rows),flush=True)
 for x in rows:print('NEW_ISA',x['row_fragments']*16,x['depth'],x['waves'],x['operand_lookahead'],'VGPR',x['metadata']['.vgpr_count'],'LDS',x['dynamic_lds_bytes'],'no_spill_no_barrier')

if __name__=='__main__':main()
