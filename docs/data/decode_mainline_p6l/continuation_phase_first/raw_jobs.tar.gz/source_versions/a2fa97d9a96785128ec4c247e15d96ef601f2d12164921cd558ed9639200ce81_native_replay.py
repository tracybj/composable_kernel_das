"""Replay the frozen Native GroupGEMM algorithm on physical GPU4, not per-group BLAS."""
from pathlib import Path
import argparse,json,os,statistics,sys,math
ROOT=Path(__file__).resolve().parent
TUNING=Path('/workspace/Grouped_Geem/blaslt_tuning_tools')
sys.path.insert(0,str(TUNING))
from tuning_common import Desc,Native,restore_inputs,sha

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--id',type=int,required=True);ap.add_argument('--mode',choices=['accuracy','perf','profile'],required=True);args=ap.parse_args()
 assert os.environ['HIP_VISIBLE_DEVICES']==os.environ['CUDA_VISIBLE_DEVICES']=='4'
 case=next(x for x in json.loads((ROOT/'research_plan.json').read_text())['cases'] if x['ID']==args.id)
 cfg=json.loads(Path(case['native_config']).read_text());cfg.update(gpu=4,binary=str(TUNING/'build/libgroupgemm_tune.so'))
 assert cfg['backend']=='groupgemm' and cfg['precision']=='bf16' and cfg['layout']=='NN'
 assert sha(cfg['blas_library'])==cfg['blas_sha256']
 import torch
 torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False;torch.cuda.set_device(0)
 g,m,n,k=[case[z] for z in ['G','M','N','K']]
 a=torch.empty((g,m,k),device='cuda',dtype=torch.bfloat16);b=torch.empty((g,k,n),device='cuda',dtype=torch.bfloat16)
 restore_inputs((a,b),tuple((cfg['seed']+args.id+i)%(1<<64) for i in range(2)))
 raw=torch.full((g,m*n+32),117,device='cuda',dtype=torch.bfloat16);c=raw[:,16:-16].view(g,m,n)
 descs=(Desc*g)(*[Desc(a[i].data_ptr(),b[i].data_ptr(),c[i].data_ptr()) for i in range(g)])
 reference=torch.bmm(a.cpu().float(),b.cpu().float()).to(torch.bfloat16)
 native=Native(cfg,case,descs);comparisons=[]
 try:
  selected=next(x for x in native.candidates if x['algorithm_id']==case['algorithm_id'])
  assert selected['kernel_name']==case['kernel_name'],selected
  print('NATIVE_SELECT '+json.dumps(dict(ID=args.id,algorithm_id=selected['algorithm_id'],kernel_name=selected['kernel_name'],workspace_bytes=selected['workspace_bytes'],binary_sha256=sha(cfg['binary']),blas_sha256=sha(cfg['blas_library']))),flush=True)
  for rep in range(3 if args.mode=='accuracy' else 1):
   c.fill_(float('nan'));native.time(selected['candidate_index'],descs,0,1)
   actual=c.cpu();guards=raw.cpu();finite=bool(torch.isfinite(actual).all());failed=int((actual!=reference).sum());absolute=float((actual.float()-reference.float()).abs().max());guard=bool((guards[:,:16]==117).all() and (guards[:,-16:]==117).all())
   check=dict(repeat=rep,checked=c.numel(),failed=failed,max_abs=absolute,finite=finite,guards_ok=guard);comparisons.append(check);print('NATIVE_ACCURACY '+json.dumps(check),flush=True)
   assert finite and failed==0 and absolute==0 and guard,check
  times=[]
  if args.mode!='accuracy':
   for i in range(30 if args.mode=='perf' else 1):times.append(native.time(selected['candidate_index'],descs,10 if i==0 else 0,1))
  result=dict(ID=args.id,gpu=4,backend='native_groupedgemm',algorithm_id=selected['algorithm_id'],kernel_name=selected['kernel_name'],shape={z:case[z] for z in ['M','N','K','G']},accuracy_pass=True,comparisons=comparisons,timed=args.mode=='perf',capture=args.mode=='profile',repeat=1,warmup=10,samples=len(times),samples_ms=times,
   protocol='HIP-event bracket around one initialized GroupedGemm::run(user_args); no algorithm initialization or allocations inside timed interval')
  if times:result.update(median_ms=statistics.median(times),min_ms=min(times),max_ms=max(times),cv=statistics.pstdev(times)/statistics.mean(times))
  print('RESULT '+json.dumps(result),flush=True)
 finally:native.close()
if __name__=='__main__':main()
