"""Read-only audit of a fixed snapshot while the existing queue continues.

Re-read real benchmark logs, health/kernel journals and paired rounds; do not
change the frozen candidate, controller, raw records or acceptance thresholds.
"""
from pathlib import Path
import datetime,hashlib,json
import acceptance,plan,runtime as r
ROOT=Path(__file__).resolve().parent

def journal(path):return [json.loads(x) for x in Path(path).read_text().splitlines() if x]

def main():
    active=r.read(ROOT/'final_active.json');folder=Path(active['path'])
    data=r.read(folder/'plan.json');rows=r.read(folder/'results.json',[])
    assert rows and data['number']==1
    manifest_sha={x['plan_sha256'] for x in rows};assert len(manifest_sha)==1
    manifest=r.read(ROOT/'manifests'/(next(iter(manifest_sha))+'.json'))
    assert manifest['phase']=='final_confirmation'
    jobs=journal(ROOT/'jobs.jsonl');bykey={x['key']:x for x in jobs};assert len(jobs)==len(bykey)
    gates={x['key']:x for x in journal(ROOT/'gates.jsonl')}
    checks={x['key']:x for x in journal(ROOT/'kernel_checks.jsonl')}
    pairs={x['key']:x for x in data['pairs']};source={x['ID']:x for x in r.read(ROOT/'source_results.json')}
    compared=elements=0;raw=[]
    for row in rows:
        pair=pairs[row['pair']];records=[bykey[k] for k in row['keys']]
        assert len(records)==16 and [x['kind'] for x in records]==['accuracy']*2+['perf']*14
        order=['base','candidate']+sum([['base','candidate'] if b%2 else ['candidate','base'] for b in range(1,8)],[])
        assert [x['variant'] for x in records]==order
        assert [x['block'] for x in records[2:]]==[b for b in range(1,8) for _ in range(2)]
        arms={'base':[],'candidate':[]}
        for rec in records:
            arm=rec['variant'];expected=pair[arm]['expected'];key=rec['key']
            assert rec['ok'] and rec['rc']==0 and rec['selected']==expected
            assert rec['shape']==row['shape'] and rec['physical_gpu']==4
            assert rec['epoch']==data['epoch'] and rec['benchmark_sha256']==data['benchmark_sha256']
            assert rec['plan_sha256']==manifest['plan_sha256'] and not rec['kernel_service_events']
            assert rec['environment']['HIP_VISIBLE_DEVICES']==rec['environment']['CUDA_VISIBLE_DEVICES']=='4'
            gate=gates[key];assert gate['rc']==0 and gate['physical_gpu']==4 and gate['hcu']=='0.0%'
            assert 'MKFD' not in gate['output'].upper() and gate['mem_available_kib']>=64*1024*1024
            assert datetime.datetime.fromisoformat(gate['at'])<=datetime.datetime.fromisoformat(rec['at'])
            for suffix in ['_pre','_post']:
                check=checks[key+suffix];assert check['rc']==0 and not check['events']
            log=Path(rec['path'])/'run.log';text=log.read_text()
            actual=r.parse_output(text,rec['kind'],expected,3 if rec['kind']=='accuracy' else 1)
            if rec['kind']=='accuracy':
                m,n,k,g=(row['shape'][z] for z in ['M','N','K','G'])
                assert len(actual['comparisons'])==3
                assert all(int(x[1])==m*n*g and int(x[2])==0 for x in actual['comparisons'])
                compared+=3;elements+=3*m*n*g
            else:
                assert actual['result']==rec['result'];arms[arm].append(actual['result'])
            raw.append(dict(key=key,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
                selected=actual['selected'],kind=rec['kind']))
        assert row['base_blocks']==arms['base'] and row['candidate_blocks']==arms['candidate']
        classified=acceptance.classify(source[row['ID']] if row['original'] else None,arms['base'],arms['candidate'])
        assert all(row[k]==v for k,v in classified.items())
    assert plan.sha(plan.REPO/'docs/data/decode_depth8_replay_p6k/results.json')=='00c80c665735d59165947e5c9458e4e3cb0327df1a47dee2926fe725af4e9d3d'
    out=ROOT/'readonly_progress'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True,exist_ok=False);r.write(out/'fixed_results_snapshot.json',rows)
    result=dict(at=r.stamp(),ok=True,read_only_audit=True,gpu_submitted=False,
        complete=len(rows)==len(data['pairs']),audited_pairs=len(rows),registered_pairs=len(data['pairs']),
        raw_jobs=len(raw),full_output_comparisons=compared,full_output_elements=elements,
        all_real_guards_redzones_and_raw_rounds_verified=True,all_health_and_kernel_events_verified=True,
        binary_sha256=data['benchmark_sha256'],epoch=data['epoch'],manifest_sha256=manifest['plan_sha256'],
        fixed_snapshot_sha256=plan.sha(out/'fixed_results_snapshot.json'),
        script_sha256=plan.sha(__file__),adoption_or_goal_completion=False)
    r.write(out/'raw_log_sha256.json',raw);r.write(out/'audit.json',result)
    print('READONLY_FINAL_RAW_AUDIT_PASS',out,json.dumps(result),flush=True)

if __name__=='__main__':main()
