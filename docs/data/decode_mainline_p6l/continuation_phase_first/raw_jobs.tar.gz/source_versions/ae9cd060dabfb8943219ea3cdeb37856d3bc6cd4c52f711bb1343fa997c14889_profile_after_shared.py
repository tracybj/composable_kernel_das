"""Wait for the one existing H2 queue, then capture/audit/deliver its SQTT."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
BUILD=json.loads((ROOT/'active_build.json').read_text())

def read(p):return json.loads(Path(p).read_text())
def state(**kw):
    p=ROOT/'post_shared_profile_controller.json';tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n');tmp.replace(p)
def guard(gpu=False):
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
    assert read(ROOT/'active_build.json')==BUILD
    session=read(ROOT/'session.json')
    assert time.time()<session['deadline_epoch']
    if gpu:assert time.time()+60<session['gpu_deadline_epoch']
    assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
def command(args,label,gpu=False):
    guard(gpu);state(state='running',stage=label,command=args)
    p=subprocess.Popen(args,stdin=subprocess.DEVNULL);rc=p.wait()
    state(state='passed' if rc==0 else 'stopped',stage=label,rc=rc,pid=p.pid)
    assert rc==0,(label,rc)
def main():
    state(state='waiting_for_existing_H2_queue',build=BUILD)
    while True:
        guard(True);p=ROOT/'postbuild_shared_controller.json'
        info=read(p) if p.exists() else {}
        assert info.get('state')!='stopped',info
        if info.get('state')=='complete':break
        time.sleep(15)
    command([sys.executable,'-B',str(ROOT/'analyze_shared_discovery.py')],'audit39')
    command([sys.executable,'-B','-u',str(ROOT.parent/'run_stage.py'),'capture','--script','profile_h2.py'],'paired_SQTT',True)
    command([sys.executable,'-B',str(ROOT/'analyze_h2_profiles.py')],'counter_ISA')
    command([sys.executable,'-B',str(ROOT/'deliver_h2.py')],'package')
    state(state='complete',next_action='Interpret all H2 results, deliver link to user, then choose evidence-based refinement or final domain; Goal performance not yet accepted')
    print('H2_AUTOMATIC_PROFILE_DELIVERY_PASS',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:state(state='stopped',error=repr(e));raise
