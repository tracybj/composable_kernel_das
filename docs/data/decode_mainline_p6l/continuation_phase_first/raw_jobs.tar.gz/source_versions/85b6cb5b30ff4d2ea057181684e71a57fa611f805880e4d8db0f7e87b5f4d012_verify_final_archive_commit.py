"""Read-only verification of an already made documentation-only local commit."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def edits(patch):
    out={};current=None
    for line in patch.splitlines():
        if line.startswith('+++ b/'):current=line[6:];out.setdefault(current,[])
        elif current and line[:1] in ['+','-'] and not line.startswith(('+++','---')):
            if re.search(r'(GroupedGemmCandidateIdentity|CandidateExpected), \d+>',line):line=re.sub(r', \d+>',', COUNT>',line)
            out[current].append(line)
    return {k:v for k,v in out.items() if v}
def main():
    session=json.loads((ROOT/'session.json').read_text());assert session['gpu_deadline_epoch']<time.time()<session['deadline_epoch']
    head=git('rev-parse','HEAD').decode().strip();assert head.startswith('5c03d25')
    parent=git('rev-parse','HEAD^').decode().strip()
    assert parent==json.loads((ROOT/'phase_unvalidated_source_commit.json').read_text())['commit']
    changed=git('diff-tree','--no-commit-id','--name-status','-r','HEAD').decode().splitlines()
    assert len(changed)==95 and all(x.startswith('A\tdocs/data/decode_mainline_p6l/') for x in changed)
    files={}
    for folder in ['phase_compiled_only','final_closeout']:
        base=REPO/'docs/data/decode_mainline_p6l'/folder
        rows=json.loads((base/'manifest.json').read_text())
        for x in rows:
            p=base/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
        for p in base.rglob('*'):
            if p.is_file():files[str(p.relative_to(REPO))]=p
    assert {x.split('\t',1)[1] for x in changed}==set(files)
    for n,p in files.items():assert git('show','HEAD:'+n)==p.read_bytes()
    assert not git('diff','--cached','--name-only').strip()
    assert edits(git('diff').decode())==edits((ROOT/'initial_tracked.patch').read_text())
    initial=json.loads((ROOT/'initial_files_sha256.json').read_text())
    expected={x[3:] for x in (ROOT/'initial_status.txt').read_text().splitlines() if x.startswith('?? ')}
    actual={x for x in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if x}
    assert actual==expected and len(actual)==10
    for n in expected:assert sha(REPO/n)==initial[n]
    rf='include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp'
    assert hashlib.md5(git('diff','--',rf)).hexdigest()==session['protected_diff_md5']
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=head,files=len(files),Git_blob_bytes_verified=len(files),only_local=True,push=False,source_changed=False,initial_user_diff_and_untracked_preserved=True,Goal_complete=False,accepted_stable50=0,accepted_cross30=0,receipt_recovered_after_auditor_set_comparison_bug=True,note='The commit succeeded and all95 blobs were verified. Initial receipt compared precommit untracked including own95 new files with postcommit untracked. Corrected check excludes exactly committed own files; no experiment or measurement error.')
    (ROOT/'final_archive_commit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('FINAL_CLOSEOUT_LOCAL_COMMIT_VERIFIED',json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
