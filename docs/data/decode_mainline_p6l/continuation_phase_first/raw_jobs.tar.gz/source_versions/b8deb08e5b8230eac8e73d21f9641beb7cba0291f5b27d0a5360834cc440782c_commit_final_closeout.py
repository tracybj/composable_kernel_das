"""Commit own closeout evidence through a separate index; no experiments."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
BASE=REPO/'docs/data/decode_mainline_p6l'

def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=REPO,env=env)
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    session=json.loads((ROOT/'session.json').read_text())
    assert session['gpu_deadline_epoch']<time.time()<session['deadline_epoch']
    assert not git('diff','--cached','--name-only').strip()
    before=git('diff');untracked=git('ls-files','--others','--exclude-standard','-z')
    source=json.loads((ROOT/'phase_unvalidated_source_commit.json').read_text())
    assert git('rev-parse','HEAD').decode().strip()==source['commit']
    index=ROOT/'final_closeout_git.index';assert not index.exists()
    env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
    subprocess.run(['git','read-tree','HEAD'],cwd=REPO,env=env,check=True)
    files={}
    for folder in [BASE/'phase_compiled_only',BASE/'final_closeout']:
        entries=json.loads((folder/'manifest.json').read_text())
        for row in entries:
            p=folder/row['path'];data=p.read_bytes()
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
        assert {x['path'] for x in entries}=={str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file() and p.name!='manifest.json'}
        for p in sorted(folder.rglob('*')):
            if p.is_file():files[str(p.relative_to(REPO))]=p.read_bytes()
    for n,data in files.items():
        assert n.startswith(('docs/data/decode_mainline_p6l/phase_compiled_only/','docs/data/decode_mainline_p6l/final_closeout/'))
        oid=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=REPO,input=data).decode().strip()
        subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+oid+','+n],cwd=REPO,env=env,check=True)
    staged=git('diff','--cached','--name-only',env=env).decode().splitlines()
    assert set(staged)==set(files)
    subprocess.run(['git','diff','--cached','--check'],cwd=REPO,env=env,check=True)
    subprocess.run(['git','commit','-m','P6l最终审计与未验收调度原型证据：性能目标未达成（实验用，不合入）'],cwd=REPO,env=env,check=True)
    head=git('rev-parse','HEAD').decode().strip()
    for n,data in files.items():
        blob=git('show','HEAD:'+n);assert blob==data
        oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+oid+','+n],cwd=REPO,check=True)
    assert git('diff')==before and not git('diff','--cached','--name-only').strip()
    # Our newly committed evidence is no longer untracked; user files must stay so.
    before_untracked={x for x in untracked.decode().split('\0') if x}
    after_untracked={x for x in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if x}
    assert after_untracked==before_untracked-set(files)
    assert hashlib.md5(git('diff','--','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp')).hexdigest()==session['protected_diff_md5']
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=head,files=len(files),Git_blob_bytes_verified=len(files),only_local=True,push=False,source_changed=False,initial_user_diff_and_untracked_preserved=True,Goal_complete=False,accepted_stable50=0,accepted_cross30=0)
    (ROOT/'final_archive_commit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('FINAL_CLOSEOUT_LOCAL_COMMIT_VERIFIED',json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
