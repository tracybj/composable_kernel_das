"""Reuse checked counter/ELF readers in a separate namespace for H1 captures."""
from pathlib import Path
import json
import analyze_profiles as counters,extract_profile_isa as isa,runtime as r
ROOT=Path(__file__).resolve().parent

def main():
 captures=r.read(ROOT/'tuning_profiles.json',[]);folder=ROOT/'tuning_profile_analysis';folder.mkdir(exist_ok=True)
 assert captures and all(x['stage']=='sqtt' for x in captures)
 # Arm names include the variant so repeated IDs never overwrite another ISA.
 r.write(folder/'profiles.json',captures)
 counters.ROOT=folder;counters.main();isa.ROOT=folder;isa.main()
 print('TUNING_COUNTER_AND_ISA_AUDIT_PASS',len(captures),flush=True)

if __name__=='__main__':main()
