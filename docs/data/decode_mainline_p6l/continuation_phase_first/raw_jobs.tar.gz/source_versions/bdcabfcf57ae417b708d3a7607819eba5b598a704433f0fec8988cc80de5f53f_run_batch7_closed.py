"""Run the fixed four diagnostic pairs after the rejected trial is audited closed."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
SELF=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def read(path):return json.loads(Path(path).read_text())
def main():
    with (ROOT/'regression_diagnosis_controller.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        closure=read(ROOT/'attempt1_closure.json');assert closure['whole_family_rejected'] and closure['original_main_complete']==166
        def event(**kw):
            item=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),script_sha256=SELF,**kw)
            p=ROOT/'batch7_closed_controller_status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(item,indent=2)+'\n');tmp.replace(p)
            with (ROOT/'batch7_closed_controller_events.jsonl').open('a') as out:out.write(json.dumps(item)+'\n');out.flush();os.fsync(out.fileno())
        try:
            for stage in ['freeze','capture','analyze','deliver']:
                assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==SELF
                session=read(ROOT/'session.json');assert time.time()<session['deadline_epoch']
                if stage in ['freeze','capture']:
                    assert time.time()+60<session['gpu_deadline_epoch']
                    assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
                command=[sys.executable,'-B','-u',str(ROOT/'regression_profile_campaign.py'),stage]
                event(state='running',stage=stage,command=command)
                child=subprocess.Popen(command,stdin=subprocess.DEVNULL);rc=child.wait()
                event(state='passed' if rc==0 else 'failed',stage=stage,rc=rc,child_pid=child.pid)
                print('BATCH7_CLOSED_STAGE',stage,'rc',rc,flush=True)
                if rc:raise RuntimeError(f'{stage} failed; no automatic retry or environment recovery')
            event(state='complete',delivery=read(ROOT/'profile_delivery_batch7.json'),adopted=False)
            print('BATCH7_CLOSED_DIAGNOSTIC_COMPLETE',flush=True)
        except BaseException as error:
            event(state='stopped',error=str(error),error_type=type(error).__name__);raise

if __name__=='__main__':main()
