"""Package complete paired SQTT captures with their original relative dependencies."""
from pathlib import Path
import csv,hashlib,json,shutil,tarfile
import runtime as r
ROOT=Path(__file__).resolve().parent

def main():
 captures=r.read(ROOT/'profiles.json',[]);sqtt=[x for x in captures if x['stage']=='sqtt']
 research=r.read(ROOT/'research_plan.json');ids=research['profile_ids']
 assert len(sqtt)==8 and {(x['ID'],x['arm']) for x in sqtt}=={(i,a) for i in ids for a in ['current_best','frozen_native']}
 isa={(x['ID'],x['arm']):x for x in r.read(ROOT/'profile_isa.json')}
 metrics={(x['ID'],x['arm'],x['stage']):x for x in r.read(ROOT/'profile_analysis.json')['rows']}
 target=ROOT/'delivery/batch1_ck_native';assert not target.exists(),'Keep prior download packages immutable'
 target.mkdir(parents=True);manifest=[]
 for x in sqtt:
  folder=Path(next(f['path'] for f in x['files'] if f['path'].endswith('.perf'))).parent
  relative=Path('captures')/folder.name;shutil.copytree(folder,target/relative)
  record=isa[x['ID'],x['arm']];m=metrics[x['ID'],x['arm'],'sqtt']
  entry={k:v for k,v in x.items() if k not in ['files','raw_log']}
  entry.update(kernel_name=record['captured_kernel'],machine_sha256=record['sha256'],resources=m['geometry'],files=[])
  for p in sorted((target/relative).rglob('*')):
   if p.is_file():entry['files'].append(dict(path=str(p.relative_to(target)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
  assert x['raw_token_bytes']>=4096 and record['unknown_lines']==0
  for f in x['files']:
   p=target/relative/Path(f['path']).relative_to(folder)
   assert p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
  manifest.append(entry)
 r.write(target/'profile_manifest.json',manifest)
 fields=['ID','M','N','K','G','arm','actual_instance','algorithm_id','dispatch','XCD','physical_gpu','epoch','sqtt','raw_token_bytes','benchmark_sha256','binary_sha256','perf_path','perf_bytes','perf_sha256','kernel_name']
 with (target/'profile_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fields);w.writeheader()
  for x in manifest:
   perf=next(z for z in x['files'] if z['path'].endswith('.perf'))
   w.writerow(dict(ID=x['ID'],**x['shape'],arm=x['arm'],actual_instance=x['actual_instance'],algorithm_id=x['algorithm_id'],dispatch=x['selected_dispatch'],XCD=0,physical_gpu=4,epoch=x['epoch'],sqtt=True,raw_token_bytes=x['raw_token_bytes'],benchmark_sha256=x['benchmark_sha256'],binary_sha256=x['binary_sha256'],perf_path=perf['path'],perf_bytes=perf['bytes'],perf_sha256=perf['sha256'],kernel_name=x['kernel_name']))
 shutil.copy2(ROOT/'diagnostic_analysis.csv',target/'diagnostic_analysis.csv')
 readme=['# 第一批：当前CK与冻结算法Native GroupGEMM对照','',
 '本包覆盖预先固定的4条代表shape，每条有当前最佳CK和Native两份含SQTT的perf。物理GPU4串行，原始精度与同轮计时另见diagnostic_analysis.csv；profiler时长不作为正式性能成绩。',
 '', '## 打开与观察','',
 '1. 完整解压，保留captures内目录和文件的原始名字与相对位置。用XCompute File → Open打开指定.perf。',
 '2. 在Result选择下面列出的dispatch、kernel；XCD选0。先Summary核对grid、block和资源，再Source搜索指令，最后Wavefronts观察同一wave的执行顺序。',
 '3. Source先将双滑块恢复全范围；比较主循环指令的Hit Count、等待依赖和寄存器，不把不同wave累计Latency相加当墙钟。Wavefronts先缩到全kernel，再放大中段重复K循环，随后查看开头预热与末尾排空。',
 '4. 重点反馈：ds_read与MMAC之间是否有独立计算、vmcnt/lgkmcnt具体依赖什么、barrier前后四个wave是否长期错开。等待长条或MMAC利用率低本身不构成单一根因。',
 '', '本机已检查文件SHA、目标dispatch、实际代码反汇编和有效SQTT token，以及资源与results.txt一致。未在本机实际打开Windows XCompute，尚不能确认GUI解码或精确Source时间轴区间；请反馈无法打开或缺失wave的情况。',
 '', '## 每份文件定位','']
 for x in manifest:
  i=x['ID'];a=x['arm'];perf=next(z for z in x['files'] if z['path'].endswith('.perf'));md=metrics[i,a,'sqtt'];ins=isa[i,a]
  readme.extend([f'### ID{i} {a}', '', f'- MNKG：{x["shape"]}；实际CK实例：{x["actual_instance"]}；Native算法：{x["algorithm_id"]}。', f'- 文件：`{perf["path"]}`；dispatch `{x["selected_dispatch"]}`；XCD0、SE0、active-CU-index0。',f'- kernel：`{x["kernel_name"]}`。',f'- 资源：{md["geometry"]}；SQTT原始token {x["raw_token_bytes"]}字节。',f'- Source搜索：`buffer_load`、`ds_read`、`s_waitcnt`、`s_barrier`、`v_mmac`。本内核静态wait {sum(ins["wait_operands"].values())}处、barrier {ins["opcodes"].get("s_barrier",0)}处；静态数量不等于动态执行次数。', '- 需要检验：CTA数量与资源是否限制并行；A/B搬运和MMAC是否重叠；共享LDS与同步的开销是否已被计算覆盖。HBM总流量不能独自判定重复的是B。', ''])
  readme.append(f'- 包含MMAC的静态后向分支区间：`{ins["main_loop_candidates"]}`。优先在这些PC区间查看高Hit Count主循环，避免把开头参数s_load等待当作B流水瓶颈。')
  anchors=ins['instruction_anchors'][:10]
  for z in anchors:readme.append(f'  指令定位：`{z["text"]}`')
  readme.append('')
 (target/'XCOMPUTE_README.md').write_text('\n'.join(readme),encoding='utf-8')
 package=target.parent/'P6l_batch1_CK_Native_SQTT.tar.gz'
 assert not package.exists()
 with tarfile.open(package,'w:gz') as archive:archive.add(target,arcname=target.name)
 r.write(ROOT/'profile_delivery_batch1.json',dict(at=r.stamp(),path=str(package),bytes=package.stat().st_size,sha256=hashlib.sha256(package.read_bytes()).hexdigest(),captures=len(manifest),gui_verified=False,local_integrity_checked=True))
 print('PROFILE_DELIVERY_PASS',package,package.stat().st_size,flush=True)

if __name__=='__main__':main()
