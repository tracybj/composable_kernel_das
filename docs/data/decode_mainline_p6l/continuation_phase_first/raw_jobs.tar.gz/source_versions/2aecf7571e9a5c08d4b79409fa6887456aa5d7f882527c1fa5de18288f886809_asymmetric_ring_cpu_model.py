"""CPU-only A2/B3 resource-factor model; no C++ edit, compilation, or GPU.

Preserves H3 ownership, N128/K32, four waves and three operand banks.
The VM model assumes the issue-order semantics of the existing buffer-to-LDS
pipeline; actual assembly and GPU validation remain required.
"""
from pathlib import Path
from collections import deque,defaultdict
import json,datetime,hashlib
ROOT=Path(__file__).resolve().parent

def schedule(rows,stages):
    queues=[deque() for _ in range(4)];a=[None]*2;b=[None]*3
    complete=defaultdict(int);issued={'A':set(),'B':set()}
    ds=[];operands=[None]*3;computed=[];reads=[];events=0
    def issue(plane,stage):
        nonlocal events
        assert 0<=stage<stages and stage not in issued[plane],('OOB/duplicate load',plane,stage)
        depth=2 if plane=='A' else 3;slot=stage%depth
        assert not any((r[1] if plane=='A' else r[2])==slot for r in ds),('Overwrite pending LDS reader',plane,stage,ds)
        assert not any(p==plane and t%depth==slot for q in queues for p,t,w,h in q),('Overwrite unretired global',plane,stage)
        issued[plane].add(stage)
        for wave in range(rows if plane=='A' else 4):
            for half in range(1 if plane=='A' else 2):
                queues[wave].append((plane,stage,wave,half));events+=1
    def wait_vm(pending):
        for q in queues:
            while len(q)>pending:
                plane,stage,wave,half=q.popleft();depth=2 if plane=='A' else 3;slot=stage%depth
                assert not any((r[1] if plane=='A' else r[2])==slot for r in ds),('Global completed over live reader',plane,stage)
                complete[plane,stage]+=1
                if complete[plane,stage]==(rows if plane=='A' else 8):
                    (a if plane=='A' else b)[slot]=stage
    def read(stage):
        assert 0<=stage<stages and a[stage%2]==b[stage%3]==stage,('Read unpublished plane',rows,stages,stage,a,b)
        assert not any((p=='A' and t%2==stage%2) or (p=='B' and t%3==stage%3) for q in queues for p,t,w,h in q),('Read while global overwrite pending',stage)
        old=operands[stage%3];assert old is None or old in computed,('Reuse unconsumed operand bank',stage,old)
        ds.append((stage,stage%2,stage%3));reads.append(stage)
    def wait_lg():
        while ds:
            stage,aa,bb=ds.pop(0);assert a[aa]==b[bb]==stage
            old=operands[stage%3];assert old is None or old in computed
            operands[stage%3]=stage
    def calc(stage):
        assert operands[stage%3]==stage,('Unready/wrong operands',rows,stages,stage,operands)
        assert stage==len(computed);computed.append(stage)
    issue('A',0);issue('B',0);issue('A',1);issue('B',1);issue('B',2)
    wait_vm(2);read(0);wait_lg();read(1);wait_lg()
    issue('A',2);issue('B',3)
    def step(t,tail):
        wait_vm(2 if t+3<stages else 0);wait_lg() # then all-wave publication barrier
        if t+2<stages:read(t+2)
        if t+3<stages:issue('A',t+3)
        if t+4<stages:issue('B',t+4)
        if not tail:assert t+4<stages
        calc(t)
    base=0;cycle=6
    while base+cycle+4<stages:
        for j in range(cycle):
            assert (base+j+2)%2==(j+2)%2 and (base+j+2)%3==(j+2)%3
            step(base+j,False)
        base+=cycle
    assert stages-base<=cycle+4
    for j in range(cycle+5):
        if base+j<stages:step(base+j,True)
    wait_vm(0);wait_lg()
    assert all(not q for q in queues) and not ds
    assert issued['A']==issued['B']==set(range(stages))
    assert computed==reads==list(range(stages))
    return events

def addresses(rows):
    padded=rows*16;abytes=padded*32*2;bbytes=8192;base_b=2*abytes
    total=base_b+3*bbytes;assert total<=32768 and 4*1024<=total
    memory={};checks=0
    for slot in range(2):
        for wave in range(rows):
            for lane in range(64):
                row=wave*16+lane//4;chunk=(lane%4)^((row>>2)&3)
                addr=slot*abytes+wave*1024+lane*16
                for e in range(8):
                    assert addr+2*e not in memory;memory[addr+2*e]=('A',slot,row,chunk*8+e)
    for slot in range(3):
        for wave in range(4):
            for lane in range(64):
                row=(wave*64+lane)//16;octet=(lane&15)^((row&1)*4)
                for half in range(2):
                    addr=base_b+slot*bbytes+half*4096+wave*1024+lane*16
                    for e in range(8):
                        assert addr+2*e not in memory;memory[addr+2*e]=('B',slot,half*16+row,octet*8+e)
    assert len(memory)*2==total and min(memory)==0 and max(memory)+2==total
    mg=2 if rows==4 else 1;ng=4//mg;mf=rows//mg;wn=128//ng;br=wn//32
    for wave in range(4):
        for lane in range(64):
            for half in range(2):
                for fragment in range(mf):
                    row=(wave//ng)*(mf*16)+fragment*16+(lane&15)
                    byte=(half*32+(lane>>4)*8)^(((row>>2)&3)*16)
                    for slot in range(2):
                        addr=slot*abytes+row*64+byte;assert addr%8==0
                        for e in range(4):
                            assert memory[addr+2*e]==('A',slot,row,half*16+(lane>>4)*4+e);checks+=1
                for fragment in range(br):
                    row=lane>>2;octet=(wave%ng)*(wn//8)+fragment*4+(lane&3)
                    for slot in range(3):
                        addr=base_b+slot*bbytes+half*4096+row*256+((octet^((row&1)*4))*16);assert addr%16==0
                        for e in range(8):
                            assert memory[addr+2*e]==('B',slot,half*16+row,(wave%ng)*wn+fragment*32+(lane&3)*8+e);checks+=1
    return checks,dict(padded_M=padded,A_stage_bytes=abytes,B_stage_bytes=bbytes,A_depth=2,B_depth=3,total_LDS_bytes=total,within32KiB=True)

def main():
    schedules=events=checks=0;resources=[]
    for rows in [1,2,4]:
        count,resource=addresses(rows);checks+=count;resources.append(resource)
        for stages in range(4,513):events+=schedule(rows,stages);schedules+=1
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),ok=True,cpu_only=True,gpu=False,compilation=False,actual_provider_modified=False,schedules=schedules,global_instruction_events=events,address_checks=checks,resources=resources,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),assumption='VM counter retires older issued buffer-to-LDS operations before the retained youngest future B pair, matching existing code assumptions; validate actual ISA and GPU before use.',not_verified=['compiled registers/spills','actual hardware residency','GPU precision','performance'],not_a_fourth_ownership_architecture=True)
    (ROOT/'asymmetric_ring_cpu_model_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('ASYMMETRIC_RING_CPU_MODEL_PASS',schedules,'schedules',checks,'addresses; no compilation/GPU',flush=True)

if __name__=='__main__':main()
