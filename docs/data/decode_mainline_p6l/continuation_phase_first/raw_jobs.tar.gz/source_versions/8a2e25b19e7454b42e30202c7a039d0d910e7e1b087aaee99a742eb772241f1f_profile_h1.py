"""Paired current-best/candidate SQTT, including observed negative results."""
from pathlib import Path
import argparse,copy,json,re,statistics,uuid
import campaign as c,plan,profile_capture as first,runtime as r
ROOT=Path(__file__).resolve().parent

def category(row):
 d=row['delta_pct'];return 'gain' if d< -2 else 'loss' if d>2 else 'flat'

def select(site):
 all_rows=r.read(ROOT/'mainline_discovery_results.json');rows=[x for x in all_rows if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()]
 assert len(rows)==48,'Finish the registered limited discovery first'
 rule=r.read(ROOT/'h1_profile_selection_rule.json');bykey={x['pair']:x for x in rows}
 chosen=[bykey[k] for k in rule['fixed_pairs']]
 for cat in ['gain','flat','loss']:
  if any(category(x)==cat for x in chosen):continue
  options=sorted([x for x in rows if not x['control'] and category(x)==cat],key=lambda x:(x['delta_pct'],x['ID'],x['variant']))
  if options:chosen.append(options[len(options)//2])
 assert len(chosen)<=rule['max_pairs']
 result=dict(rule_sha256=plan.sha(ROOT/'h1_profile_selection_rule.json'),discovery_sha256=plan.sha(ROOT/'mainline_discovery_results.json'),plan_sha256=site.manifest['plan_sha256'],epoch=site.epoch(),chosen=[dict(pair=x['pair'],ID=x['ID'],variant=x['variant'],category=category(x),delta_pct=x['delta_pct'],high_cv=x['high_cv'],precision_keys=x['keys'][:2]) for x in chosen])
 path=ROOT/'h1_profile_plan.json'
 if path.exists():assert r.read(path)==result
 else:r.write(path,result)
 return rule,result,bykey

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['capture']);ap.parse_args();r.no_core();site=r.Site(ROOT)
 rule,selection,results=select(site);self_sha=plan.sha(__file__);rule_sha=selection['rule_sha256']
 configs={x['key']:x for x in r.read(ROOT/'mainline_discovery_plan.json')['discovery_pairs']}
 captures=r.read(ROOT/'h1_profiles.json',[])
 with r.locked():
  for chosen in selection['chosen']:
   row=results[chosen['pair']];assert row['epoch']==site.epoch()
   for role in ['base','candidate']:
    old=[x for x in captures if x['pair']==row['pair'] and x['role']==role and x['epoch']==site.epoch() and x['benchmark_sha256']==site.manifest['benchmark_sha256']]
    if old:continue
    assert plan.sha(__file__)==self_sha and plan.sha(ROOT/'h1_profile_selection_rule.json')==rule_sha
    case=configs[row['pair']][role];label=role+'_'+row['variant'];name=f'h1_id{row["ID"]}_{label}_{uuid.uuid4().hex[:8]}'
    folder=ROOT/'profiles_h1'/name;folder.mkdir(parents=True,exist_ok=False)
    spec=c.ck(case,'perf',name);app=[a.replace('--samples=30','--samples=1').replace('--validate=1','--validate=0') for a in spec['command']]
    kernel='GroupedGemmV7UniformKernel' if role=='base' else 'DecodeNnMainlineKernel'
    cmd=[str(c.XPROF),'--enable-sqtt','--enable-raw','--target-se','0','--target-cu','0','--dispatches',str(rule['dispatch']),'--kernels',kernel,'--sections',rule['sections'],'--output-dir',str(folder),*app]
    spec.update(kind='profile',command=cmd,variant=label,purpose='h1_profile',sqtt=True,capture_timing_is_formal=False,prior_accuracy_keys=chosen['precision_keys'],capture_script_sha256=self_sha,profile_rule_sha256=rule_sha)
    rec=site.execute(spec);inventory=first.trace_inventory(folder)
    log=Path(rec['path'],'run.log').read_text();dispatches=[int(x) for x in re.findall(r'== dispatch kernel \[(\d+)\]',log)]
    assert dispatches==[rule['dispatch']] and inventory['raw_token_bytes']>=rule['minimum_raw_token_bytes'],'Wrong or sparse capture; preserve attempt and stop'
    entry=dict(ID=row['ID'],pair=row['pair'],role=role,arm=label,variant=row['variant'],shape=row['shape'],dtype='BF16',layout='NN',stage='sqtt',epoch=rec['epoch'],physical_gpu=4,key=rec['key'],actual_instance=case['expected'],algorithm_id=None,kernel_filter=kernel,dispatches=dispatches,selected_dispatch=rule['dispatch'],XCD=0,SE=0,active_CU_index=0,sqtt=True,raw_log=str(Path(rec['path'])/'run.log'),benchmark_sha256=site.manifest['benchmark_sha256'],binary_sha256=rec['binary_sha256'],collection_command=cmd,environment=rec['environment'],prior_accuracy_keys=chosen['precision_keys'],plan_sha256=rec['plan_sha256'],source_sha256=site.manifest['worktree_source_sha256'],script_sha256=rec['script_sha256'],formal_timing=False,point_base_ms=row['base_ms'],point_candidate_ms=row['candidate_ms'],point_delta_pct=row['delta_pct'],**inventory)
    captures.append(entry);r.write(ROOT/'h1_profiles.json',captures);print('H1_PROFILE_PASS',row['pair'],role,'tokens',inventory['raw_token_bytes'],flush=True)
 print('H1_PAIRED_SQTT_BATCH_PASS',len(captures),flush=True)

if __name__=='__main__':main()
