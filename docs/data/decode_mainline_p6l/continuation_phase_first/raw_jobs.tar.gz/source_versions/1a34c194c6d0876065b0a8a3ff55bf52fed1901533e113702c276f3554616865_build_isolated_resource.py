"""Low-priority CPU-only build; never promotes artifacts or submits GPU work."""
from pathlib import Path
import datetime,hashlib,json,os,re,resource,shlex,signal,subprocess,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
ISO=ROOT/'isolated_resource_build'

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.nice(10)
    allowed=sorted(os.sched_getaffinity(0));cpus=allowed[-4:];os.sched_setaffinity(0,cpus)
    prepared=read(ISO/'preparation.json');src=Path(prepared['source']);build=Path(prepared['build'])
    assert not (ISO/'results.json').exists(),'Never overwrite a previous build attempt'
    results=[];pins=prepared['isolated_source_sha256']
    env={k:v for k,v in os.environ.items() if not k.startswith('CK_TILE_GROUPED_GEMM_') and k not in ['LD_PRELOAD','ROCR_VISIBLE_DEVICES','HSA_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL']}
    env.update(HIP_VISIBLE_DEVICES='4',CUDA_VISIBLE_DEVICES='4',OMP_NUM_THREADS='4')
    def event(**extra):
        value=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),gpu=False,
            cpu_affinity=cpus,nice=os.nice(0),original_deadlines_unchanged=True,**extra)
        p=ISO/'status.json';temp=p.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(p)
        with (ISO/'events.jsonl').open('a') as out:out.write(json.dumps(value)+'\n');out.flush();os.fsync(out.fileno())
    def guard():
        deadline=read(ROOT/'session.json')['gpu_deadline_epoch'];assert time.time()+60<deadline
        memory=int(re.search(r'MemAvailable:\s+(\d+)',Path('/proc/meminfo').read_text())[1])
        assert memory>=96*1024*1024,'Require96GiB before CPU compilation to protect GPU64GiB gate'
        assert all(sha(src/n)==s for n,s in pins.items())
        assert all(sha(REPO/n)==s for n,s in prepared['original_source_sha256'].items())
        assert sha(REPO/'build/bin/tile_example_grouped_gemm_device_args_benchmark')==prepared['original_benchmark_sha256']
        return deadline
    def run(label,command,cwd=None):
        deadline=guard();folder=ISO/'commands'/label;folder.mkdir(parents=True,exist_ok=False)
        event(state='running',stage=label,command=command);start=time.monotonic()
        with (folder/'run.log').open('x') as log:
            child=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,start_new_session=True)
            event(state='running',stage=label,command=command,child_pid=child.pid)
            try:rc=child.wait(timeout=max(1,deadline-time.time()-60))
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=30)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                raise RuntimeError('Original compile cutoff reached; stopped own CPU build group')
        item=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stage=label,
            command=command,cwd=str(cwd) if cwd else None,rc=rc,seconds=time.monotonic()-start,gpu=False)
        results.append(item);(folder/'command.json').write_text(json.dumps(item,indent=2)+'\n')
        (ISO/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        event(state='passed' if rc==0 else 'failed',stage=label,rc=rc,seconds=item['seconds'])
        print('ISOLATED_RESOURCE_STAGE',label,'rc',rc,'seconds',item['seconds'],flush=True)
        assert rc==0,(label,str(folder/'run.log'))
        return folder
    event(state='starting',concurrent_original_final=read(ROOT/'final_attempts/attempt_1/progress.json'))
    try:
        run('configure',['cmake','-S',str(src),'-B',str(build),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
        cpu=ISO/'cpu';cpu.mkdir()
        for name in ['grouped_gemm_decode_mainline_selector_test','grouped_gemm_decode_depth8_selector_test','grouped_gemm_selector_test']:
            source=src/'example_hcu/ck_tile/19_grouped_gemm'/(name+'.cpp');exe=cpu/name
            run('compile_cpu_'+name,['g++','-O2','-std=c++17','-I'+str(src/'include'),str(source),'-o',str(exe)])
            folder=run('run_cpu_'+name,[str(exe)])
            assert 'PASS' in (folder/'run.log').read_text()
        old=read(REPO/'build/compile_commands.json')
        def adapted(relative):
            matches=[x for x in old if x['file']==str(REPO/relative)];assert len(matches)==1
            argv=shlex.split(matches[0]['command']);argv=[v.replace(str(REPO/'build'),str(build)).replace(str(REPO),str(src)) for v in argv]
            i=argv.index('-o');del argv[i:i+2]
            return argv
        for label,relative in [('host_api','example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args.cpp'),('host_query','example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args_query_test.cpp')]:
            cmd=adapted(relative);cmd.remove('-c');cmd+=['--offload-host-only','-fsyntax-only']
            run(label,cmd,cwd=build)
        provider='example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_cooperative_device_args.cpp'
        cmd=adapted(provider)+['-o',str(ISO/'cooperative_resource_probe.o')]
        run('standalone_provider',cmd,cwd=build)
        run('official_targets',['cmake','--build',str(build),'--target',
            'tile_example_grouped_gemm_device_args_benchmark','tile_example_grouped_gemm_device_args_query_test',
            'tile_example_grouped_gemm_device_args_smoke','tile_example_grouped_gemm_selector_test',
            'tile_example_grouped_gemm_decode_depth8_selector_test',
            'tile_example_grouped_gemm_decode_mainline_selector_test','-j4'])
        guard()
        event(state='compiled_cpu_only',benchmark=str(build/'bin/tile_example_grouped_gemm_device_args_benchmark'),
            benchmark_sha256=sha(build/'bin/tile_example_grouped_gemm_device_args_benchmark'),
            not_promoted=True,not_gpu_validated=True,not_adopted=True,
            next='Audit shader preservation/resources and wait for original347+batch7 evidence before any promotion/GPU')
        print('ISOLATED_RESOURCE_CPU_BUILD_COMPLETE_NO_GPU',flush=True)
    except BaseException as error:
        event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False)
        raise

if __name__=='__main__':main()
