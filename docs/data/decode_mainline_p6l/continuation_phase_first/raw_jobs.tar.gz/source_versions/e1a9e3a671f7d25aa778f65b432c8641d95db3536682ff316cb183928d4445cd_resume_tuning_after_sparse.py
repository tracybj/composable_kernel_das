"""One reviewed restart after sparse identity trace; no rebuild or gate bypass."""
from pathlib import Path
import json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent

def main():
    assert json.loads((ROOT/'postbuild_tuning_controller.json').read_text())['state']=='stopped'
    assert all(x['rc']==0 for x in json.loads((ROOT/'compile/build4/results.json').read_text()))
    for stage in ['freeze','qualify','representatives']:
        assert time.time()+60<json.loads((ROOT/'session.json').read_text())['gpu_deadline_epoch']
        assert not any((ROOT/n).exists() for n in ['gpu_stop.json','environment_recovery_required.json','user_pause.json'])
        command=[sys.executable,'-B','-u',str(ROOT.parent/'run_stage.py'),stage,'--script','tuning_campaign.py']
        print('REVIEWED_SPARSE_TRACE_REPAIR_STAGE',stage,flush=True)
        child=subprocess.Popen(command,stdin=subprocess.DEVNULL);rc=child.wait()
        assert rc==0,(stage,rc)
    (ROOT/'tuning_repaired_sequence_complete.json').write_text(json.dumps(dict(complete=True,reason='Identity probes G3->32 only; original sparse attempt preserved; no performance result existed before repair'),indent=2)+'\n')
    print('TUNING_REPAIRED_SEQUENCE_PASS',flush=True)

if __name__=='__main__':main()
