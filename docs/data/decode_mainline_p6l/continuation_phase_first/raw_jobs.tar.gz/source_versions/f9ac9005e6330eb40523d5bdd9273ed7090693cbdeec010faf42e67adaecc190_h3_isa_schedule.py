"""Identify real cyclic CFG regions, excluding tail layout back-jumps.
Static instruction/dataflow proof only; SQTT is still needed for timing stalls.
"""
from pathlib import Path
import collections,json,re,sys
ROOT=Path(__file__).resolve().parent

def instructions(path):
 out=[]
 for i,line in enumerate(Path(path).read_text().splitlines()):
  m=re.match(r'^\s*([\w.]+)\s*(.*?)\s*//\s*([0-9A-Fa-f]+):\s*(.*)',line)
  if m:out.append(dict(line=i+1,opcode=m[1],operands=m[2].strip(),address=int(m[3],16),encoding=m[4],text=line.strip()))
 return out

def branch_target(ins):
 word=int(ins['encoding'].split()[0],16);delta=word&65535
 if delta&32768:delta-=65536
 return ins['address']+4+delta*4

def cyclic_regions(ins):
 bypc={x['address']:i for i,x in enumerate(ins)};succ={i:[] for i in range(len(ins))}
 for i,x in enumerate(ins):
  op=x['opcode']
  if op=='s_branch' or op.startswith('s_cbranch_'):
   target=branch_target(x);assert target in bypc,(op,hex(target))
   succ[i].append(bypc[target])
   if op!='s_branch' and i+1<len(ins):succ[i].append(i+1)
  elif op!='s_endpgm' and i+1<len(ins):succ[i].append(i+1)
 # Tarjan on individual instructions is linear and works even when a loop
 # has two entry blocks for active-A/inactive-A VM wait paths.
 sys.setrecursionlimit(max(sys.getrecursionlimit(),len(ins)*3+100))
 index={};low={};stack=[];active=set();groups=[]
 def visit(v):
  index[v]=low[v]=len(index);stack.append(v);active.add(v)
  for w in succ[v]:
   if w not in index:visit(w);low[v]=min(low[v],low[w])
   elif w in active:low[v]=min(low[v],index[w])
  if low[v]==index[v]:
   group=[]
   while True:
    w=stack.pop();active.remove(w);group.append(w)
    if w==v:break
   if len(group)>1 or v in succ[v]:groups.append(sorted(group))
 visit(0)
 return [[ins[i] for i in g] for g in groups]

def vgprs(operand):
 out=set()
 for a,b,c in re.findall(r'v\[(\d+):(\d+)\]|v(\d+)',operand):
  out.update(range(int(a),int(b)+1)) if a else out.add(int(c))
 return out

def audit_one(item):
 match=re.search(r'DecodeNnCooperativeKernelILi(\d+)ELi(\d+)ELi(\d+)EE',item['symbol']);assert match
 rows,k,depth=map(int,match.groups());mg=2 if rows==4 else 1;ng=4//mg;mf=rows//mg;nf=128//ng//16
 expected=3*depth*mf*nf*(k//16)
 ins=instructions(item['assembly']);regions=cyclic_regions(ins)
 loops=[x for x in regions if any(z['opcode'].startswith('v_mmac') for z in x)];assert len(loops)==1,len(loops)
 loop=loops[0];mmac=sum(x['opcode'].startswith('v_mmac') for x in loop);assert mmac==expected,(rows,k,depth,mmac,expected)
 barriers=[i for i,x in enumerate(loop) if x['opcode']=='s_barrier'];assert len(barriers)==3*depth,(rows,k,depth,len(barriers))
 groups=[]
 for j,idx in enumerate(barriers):
  block=loop[idx+1:barriers[j+1] if j+1<len(barriers) else len(loop)]
  ds=[z for z in block if z['opcode'].startswith('ds_read')];calc=[z for z in block if z['opcode'].startswith('v_mmac')]
  assert len(ds)==(mf+nf//2)*(k//16) and len(calc)==mf*nf*(k//16),(rows,k,depth,j,len(ds),len(calc))
  first=next(i for i,z in enumerate(block) if z['opcode'].startswith('ds_read'))
  compute=next(i for i,z in enumerate(block) if z['opcode'].startswith('v_mmac'))
  assert not any(z['opcode']=='s_waitcnt' and 'lgkmcnt' in z['operands'] for z in block[first:compute]),(rows,k,depth,j,'immediate LG wait after lookahead reads')
  writes=set().union(*(vgprs(z['operands'].split(',')[0]) for z in ds));uses=set()
  for z in calc:
   parts=z['operands'].split(',');uses|=vgprs(parts[1])|vgprs(parts[2])
  assert not (writes&uses),(rows,k,depth,j,'lookahead overwritten current operands')
  groups.append(dict(stage_in_cycle=j,read_pcs=[hex(z['address']) for z in ds],read_registers=sorted(writes),current_operand_registers=sorted(uses),mmac_pcs=[hex(z['address']) for z in calc]))
 for j in range(2,len(groups)):
  assert groups[j]['current_operand_registers']==groups[j-2]['read_registers'],(rows,k,depth,j,'not two stages ahead')
 anchors=[dict(line=z['line'],text=z['text']) for z in loop if z['opcode'].startswith(('s_waitcnt','s_barrier','buffer_load','ds_read','v_mmac'))][:30]
 return dict(symbol=item['symbol'],machine_sha256=item['sha256'],rows=rows,block_k=k,depth=depth,operand_banks=3,main_loop=dict(start_pc=hex(loop[0]['address']),end_pc=hex(loop[-1]['address']),line_start=loop[0]['line'],line_end=loop[-1]['line'],static_mmac=mmac,barriers=len(barriers),kind='validated cyclic CFG region; not arbitrary backward layout jump'),wait_operands=dict(collections.Counter(z['operands'] for z in loop if z['opcode']=='s_waitcnt')),two_stage_lookahead_register_matches=len(groups)-2,no_immediate_lg_wait_after_lookahead=True,static_only=True,groups=groups,instruction_anchors=anchors)

def main():
 path=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'h3_probe2_h3_isa_audit.json';data=json.loads(path.read_text());rows=[audit_one(x) for x in data['kernels']]
 output=ROOT/(path.stem+'_schedule.json');output.write_text(json.dumps(dict(ok=True,input=str(path),kernels=rows,note='All9 true cyclic loops checked against source Cycle=3D; two-stage operand register dependencies verified. Static ordering is not proof of measured overlap or speed.'),indent=2)+'\n')
 print('H3_STATIC_SCHEDULE_AUDIT_PASS',len(rows),flush=True)
 for x in rows:print('H3_STATIC_LOOP',x['rows'],x['block_k'],x['depth'],x['main_loop']['start_pc'],x['main_loop']['end_pc'],'MMAC',x['main_loop']['static_mmac'],'twoahead',x['two_stage_lookahead_register_matches'],flush=True)
if __name__=='__main__':main()
