"""Predeclared H3 and identical-GPU-kernel route SQTT pairs, GPU4 serial."""
from pathlib import Path
import argparse,math,re,statistics,uuid
import campaign as c,plan,profile_capture as first,runtime as r
import h3_campaign as hc
ROOT=Path(__file__).resolve().parent

def category(row):
 d=row['delta_pct'];return 'gain' if d< -2 else 'loss' if d>2 else 'flat'

def select(site):
 rows=[x for x in r.read(ROOT/'h3_discovery_results.json') if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()]
 assert len(rows)==85,'Finish all registered H3 pairs first'
 rule=r.read(ROOT/'h3_profile_selection_rule.json');bykey={x['pair']:x for x in rows}
 def choose(names,count):
  def score(name):
   values=[x['candidate_ms']/x['base_ms'] for x in rows if not x['control'] and x['variant']==name];assert len(values)==count
   return math.exp(statistics.mean(math.log(z) for z in values)),name
  return min(names,key=score)
 coop=choose([n for n in hc.VARIANTS if n.startswith('coop_')],8)
 main=choose([n for n,v in hc.VARIANTS.items() if v['family']=='main'],8)
 short=choose([n for n,v in hc.VARIANTS.items() if v['family']=='short'],9)
 chosen=[bykey[f'id{i}_{coop}'] for i in rule['fixed_main_ids']]+[bykey[f'id{rule["fixed_short_id"]}_{short}']]
 if main!=coop:chosen.append(bykey[f'id805_{main}'])
 for cat in ['gain','flat','loss']:
  if any(category(x)==cat for x in chosen):continue
  options=sorted([x for x in rows if not x['control'] and category(x)==cat],key=lambda x:(x['delta_pct'],x['ID'],x['variant']))
  if options:chosen.append(options[len(options)//2])
 chosen += [x for x in rows if x.get('route_compare')]
 assert len(chosen)<=rule['max_pairs'] and len({x['pair'] for x in chosen})==len(chosen)
 result=dict(rule_sha256=plan.sha(ROOT/'h3_profile_selection_rule.json'),discovery_sha256=plan.sha(ROOT/'h3_discovery_results.json'),plan_sha256=site.manifest['plan_sha256'],epoch=site.epoch(),chosen_coop_variant=coop,chosen_main_variant=main,chosen_short_variant=short,chosen=[dict(pair=x['pair'],ID=x['ID'],variant=x['variant'],category=category(x),delta_pct=x['delta_pct'],high_cv=x['high_cv'],route_compare=x.get('route_compare',False),precision_keys=x['keys'][:2]) for x in chosen])
 path=ROOT/'h3_profile_plan.json'
 if path.exists():assert r.read(path)==result
 else:r.write(path,result)
 return rule,result,bykey

def kernel_identity(case):
 ident=case['expected'];m=case['M'];rows=1 if m<=16 else 2 if m<=32 else 4
 if ident in [6020,6021,6022]:
  k,d={6020:(16,4),6021:(16,8),6022:(32,4)}[ident]
  return 'DecodeNnCooperativeKernel',f'DecodeNnCooperativeKernel<{rows},{k},{d}>'
 if 6013<=ident<=6018:
  mode=ident-6013;depth=4 if mode>=3 else 8;early=mode%3>=1;xor=mode%3!=1
 elif ident in [6010,6012]:
  depth=8 if ident==6010 else 4;e=case['env']
  early=e.get(plan.PREFIX+'ENABLE_BF16_NN_DECODE_SHARED_EARLY_B')=='1'
  xor=e.get(plan.PREFIX+'ENABLE_BF16_NN_DECODE_SHARED_XOR_A')=='1'
 else:return 'GroupedGemmV7UniformKernel',None
 expected=f'DecodeNnSharedTunedKernel<{rows},16,{depth},{str(early).lower()},{str(xor).lower()}>'
 return 'DecodeNnSharedTunedKernel',expected

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['capture']);ap.parse_args();r.no_core();site=r.Site(ROOT)
 rule,selection,results=select(site);self_sha=plan.sha(__file__);rule_sha=selection['rule_sha256']
 configs={x['key']:x for x in r.read(ROOT/'h3_discovery_plan.json')['discovery_pairs']};captures=r.read(ROOT/'h3_profiles.json',[])
 with r.locked():
  for chosen in selection['chosen']:
   row=results[chosen['pair']];assert row['epoch']==site.epoch()
   for role in ['base','candidate']:
    old=[x for x in captures if x['pair']==row['pair'] and x['role']==role and x['epoch']==site.epoch() and x['benchmark_sha256']==site.manifest['benchmark_sha256']]
    if old:continue
    assert plan.sha(__file__)==self_sha and plan.sha(ROOT/'h3_profile_selection_rule.json')==rule_sha
    case=configs[row['pair']][role];label=role+'_'+row['variant'];key=f'h3_id{row["ID"]}_{label}_{uuid.uuid4().hex[:8]}'
    folder=ROOT/'profiles_h3'/key;folder.mkdir(parents=True,exist_ok=False)
    spec=c.ck(case,'perf',key);app=[a.replace('--samples=30','--samples=1').replace('--validate=1','--validate=0') for a in spec['command']]
    kernel,expected=kernel_identity(case)
    cmd=[str(c.XPROF),'--enable-sqtt','--enable-raw','--target-se','0','--target-cu','0','--dispatches',str(rule['dispatch']),'--kernels',kernel,'--sections',rule['sections'],'--output-dir',str(folder),*app]
    spec.update(kind='profile',command=cmd,variant=label,purpose='h3_profile',sqtt=True,capture_timing_is_formal=False,prior_accuracy_keys=chosen['precision_keys'],capture_script_sha256=self_sha,profile_rule_sha256=rule_sha)
    rec=site.execute(spec);inventory=first.trace_inventory(folder)
    log=Path(rec['path'],'run.log').read_text();dispatches=[int(x) for x in re.findall(r'== dispatch kernel \[(\d+)\]',log)]
    assert dispatches==[rule['dispatch']] and inventory['raw_token_bytes']>=rule['minimum_raw_token_bytes'],'Wrong/sparse trace; preserve attempt and stop'
    text=(folder/'results.txt').read_text();name=re.search(r'kernel-name\((.*?)\), start_ts',text)[1];normal=re.sub(r'\s+','',name)
    assert expected is None or expected in normal,(expected,name)
    assert 'dispatch[18], gpu-id(4)' in text
    entry=dict(ID=row['ID'],pair=row['pair'],role=role,arm=label,variant=row['variant'],route_compare=row.get('route_compare',False),shape=row['shape'],dtype='BF16',layout='NN',stage='sqtt',epoch=rec['epoch'],physical_gpu=4,key=rec['key'],actual_instance=case['expected'],algorithm_id=None,kernel_filter=kernel,actual_kernel=name,expected_kernel=expected,dispatches=dispatches,selected_dispatch=rule['dispatch'],XCD=0,SE=0,active_CU_index=0,sqtt=True,raw_log=str(Path(rec['path'])/'run.log'),benchmark_sha256=site.manifest['benchmark_sha256'],binary_sha256=rec['binary_sha256'],collection_command=cmd,environment=rec['environment'],prior_accuracy_keys=chosen['precision_keys'],plan_sha256=rec['plan_sha256'],source_sha256=site.manifest['worktree_source_sha256'],script_sha256=rec['script_sha256'],formal_timing=False,point_base_ms=row['base_ms'],point_candidate_ms=row['candidate_ms'],point_delta_pct=row['delta_pct'],**inventory)
    captures.append(entry);r.write(ROOT/'h3_profiles.json',captures);print('H3_PROFILE_PASS',row['pair'],role,'tokens',inventory['raw_token_bytes'],flush=True)
 print('H3_PAIRED_SQTT_BATCH_PASS',len(captures),flush=True)
if __name__=='__main__':main()
