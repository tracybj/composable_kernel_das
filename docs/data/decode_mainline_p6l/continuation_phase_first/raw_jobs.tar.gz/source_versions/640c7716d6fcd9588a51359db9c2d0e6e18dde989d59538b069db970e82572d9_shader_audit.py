"""Read-only GPU machine-code preservation proof across local builds."""
from pathlib import Path
import argparse,hashlib,json,mmap,sys
import runtime as r
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p6d')
import elf_isa as e

def inventory(path):
 out={}
 with Path(path).open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
  fat=next(s for s in e.sections(data) if s['name']=='.hip_fatbin')
  for triple,code in e.bundles(data[fat['off']:fat['off']+fat['size']]):
   if code[:4]!=b'\x7fELF':continue
   sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
   for name,item in md.items():
    sym=symbols[name];sec=sh[sym['section']];start=sym['address'];size=sym['size']
    if not size:
     later=[s['address'] for s in symbols.values() if s['section']==sym['section'] and s['address']>start]
     size=(min(later) if later else sec['addr']+sec['size'])-start
    offset=sec['off']+start-sec['addr'];key=triple+'::'+name
    out[key]=dict(target=triple,symbol=name,machine_sha256=hashlib.sha256(code[offset:offset+size]).hexdigest(),bytes=size,metadata={k:v for k,v in item.items() if k not in ['.args','.unfolded_args']})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['snapshot','compare']);ap.add_argument('--binary',default='/workspace/composable_kernel/build/bin/tile_example_grouped_gemm_device_args_benchmark');ap.add_argument('--output');a=ap.parse_args()
 new=inventory(a.binary);path=ROOT/'initial_shaders.json'
 if a.mode=='snapshot':
  assert not path.exists();r.write(path,dict(binary=a.binary,binary_sha256=hashlib.sha256(Path(a.binary).read_bytes()).hexdigest(),kernels=new));print('INITIAL_SHADER_INVENTORY_PASS',len(new));return
 old=r.read(path)['kernels'];missing=[k for k in old if k not in new];changed=[k for k,v in old.items() if k in new and new[k]['machine_sha256']!=v['machine_sha256']]
 result=dict(ok=not missing and not changed,binary=a.binary,binary_sha256=hashlib.sha256(Path(a.binary).read_bytes()).hexdigest(),original_count=len(old),preserved_count=len(old)-len(missing)-len(changed),missing=missing,changed=changed,added={k:v for k,v in new.items() if k not in old})
 r.write(a.output or ROOT/'shader_preservation.json',result);print('SHADER_PRESERVATION',result['ok'],result['preserved_count'],'added',len(result['added']));assert result['ok'],result

if __name__=='__main__':main()
