"""Extract only captured code for local ISA analysis; vendor text stays outside Git."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
import runtime as r
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p4a')
sys.path.insert(0,'/workspace/v7_coverage/p6d')
from perfdump import zblocks
import elf_isa as e

def main():
 captures=r.read(ROOT/'profiles.json',[]);records=[];e.ROOT=ROOT
 for cap in captures:
  if cap['stage']!='sqtt':continue
  perf=next(x for x in cap['files'] if x['path'].endswith('.perf'))
  blocks=zblocks(Path(perf['path']).read_bytes());code=blocks[0][2];assert code[:4]==b'\x7fELF'
  sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
  text=Path(next(x for x in cap['files'] if x['path'].endswith('/results.txt'))['path']).read_text()
  kernel=re.search(r'kernel-name\((.*?)\), start_ts',text)[1]
  if cap['arm']=='frozen_native':
   selected=[n for n in symbols if n==cap['kernel_filter']]
  else:
   selected=[]
   for name in md:
    if cap['kernel_filter'] not in name:continue
    demangled=subprocess.check_output(['/opt/dtk/aillvm/bin/llvm-cxxfilt',name],text=True).strip()
    if re.sub(r'\s+','',demangled)==re.sub(r'\s+','',kernel):selected.append(name)
   # XCompute may omit a leading return type, so fail visibly rather than pick another variant.
  assert len(selected)==1,dict(ID=cap['ID'],arm=cap['arm'],kernel=kernel,matched=selected)
  name=selected[0];tag=f'id{cap["ID"]}_{cap["arm"]}'
  co=ROOT/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
  item=e.dump(co,code,sh,symbols,md,name,tag);assert item['unknown_lines']==0
  item.update(ID=cap['ID'],arm=cap['arm'],epoch=cap['epoch'],dispatch=cap['selected_dispatch'],captured_kernel=kernel,perf=perf['path'],code_object_sha256=hashlib.sha256(code).hexdigest())
  lines=Path(item['assembly']).read_text().splitlines()
  instructions=[]
  for i,line in enumerate(lines):
   match=re.match(r'^\s*([\w.]+)\s*(.*?)\s*//\s*([0-9A-Fa-f]+):\s*(.*)',line)
   if match:instructions.append(dict(line=i+1,opcode=match[1],operands=match[2].strip(),address=int(match[3],16),encoding=match[4],text=line.strip()))
  loops=[]
  for ins in instructions:
   if ins['opcode']!='s_branch' and not ins['opcode'].startswith('s_cbranch_'):continue
   word=int(ins['encoding'].split()[0],16);delta=word&65535;delta=delta-65536 if delta&32768 else delta
   dest=ins['address']+4+delta*4
   if dest>=ins['address']:continue
   body=[z for z in instructions if dest<=z['address']<=ins['address']]
   mmac=sum(z['opcode'].startswith('v_mmac') for z in body)
   if mmac:loops.append(dict(start_pc=hex(dest),end_pc=hex(ins['address']),static_mmac=mmac,line_start=body[0]['line'],line_end=ins['line']))
  # A generic kernel may loop over logical tiles as well as over K. Prefer
  # MMAC-containing inner loops, not the enclosing loop that also contains
  # parameter decoding and the entire epilogue.
  inner=[x for x in loops if not any(x['line_start']<=y['line_start'] and y['line_end']<x['line_end'] for y in loops if y is not x)]
  loops=sorted(inner,key=lambda x:(-x['static_mmac'],x['line_end']-x['line_start']))+sorted([x for x in loops if x not in inner],key=lambda x:-x['static_mmac'])
  item['main_loop_candidates']=loops[:4]
  if loops:
   lo=loops[0];focus=[z for z in instructions if lo['line_start']<=z['line']<=lo['line_end']]
   first=next(i for i,z in enumerate(focus) if z['opcode'].startswith('v_mmac'));focus=focus[max(0,first-10):first+24]
  else:focus=instructions
  item['instruction_anchors']=[dict(line=z['line'],text=z['text']) for z in focus if re.match(r'(s_waitcnt|s_barrier|buffer_load|ds_read|v_mmac|v_perm_b32)',z['opcode'])][:24]
  records.append(item)
 r.write(ROOT/'profile_isa.json',records)
 print('CAPTURED_ISA_PASS',len(records),flush=True)
 for x in records:print('ISA',x['ID'],x['arm'],'VGPR',x['metadata'].get('.vgpr_count'),'scratch',x['metadata'].get('.private_segment_fixed_size'),'barriers_static',x['opcodes'].get('s_barrier',0),'unknown',x['unknown_lines'])

if __name__=='__main__':main()
