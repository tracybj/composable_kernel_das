"""Predeclared factor SQTT comparisons with bounded, paired CU fallback."""
from pathlib import Path
import argparse,math,re,statistics,uuid
import campaign as c,plan,profile_capture as trace,runtime as r
import h3_factors_campaign as hc
ROOT=Path(__file__).resolve().parent

def category(row):
 d=row['delta_pct'];return 'gain' if d< -2 else 'loss' if d>2 else 'flat'

def select(site):
 rows=[x for x in r.read(ROOT/'h3_factors_discovery_results.json') if x['plan_sha256']==site.manifest['plan_sha256'] and x['epoch']==site.epoch()]
 assert len(rows)==116,'All registered factor pairs must finish first'
 rule=r.read(ROOT/'h3_factors_profile_selection_rule.json');bykey={x['pair']:x for x in rows}
 def choose(names,count):
  def score(name):
   ratios=[x['candidate_ms']/x['base_ms'] for x in rows if not x['control'] and x['variant']==name];assert len(ratios)==count
   return math.exp(statistics.mean(math.log(z) for z in ratios)),name
  return min(names,key=score)
 coop=choose([n for n in hc.VARIANTS if n.startswith('coop_')],8)
 short=choose([n for n,v in hc.VARIANTS.items() if v['family']=='short'],9)
 chosen=[bykey[f'id{i}_{coop}'] for i in rule['fixed_main_ids']]+[bykey[f'id{rule["fixed_short_id"]}_{short}']]
 for cat in ['gain','flat','loss']:
  if any(category(x)==cat for x in chosen):continue
  options=sorted([x for x in rows if not x['control'] and category(x)==cat],key=lambda x:(x['delta_pct'],x['ID'],x['variant']))
  if options:chosen.append(options[len(options)//2])
 chosen += [x for x in rows if x.get('route_compare') or x.get('depth_compare')]
 assert len(chosen)<=rule['max_pairs']==14 and len({x['pair'] for x in chosen})==len(chosen)
 result=dict(rule_sha256=plan.sha(ROOT/'h3_factors_profile_selection_rule.json'),discovery_sha256=plan.sha(ROOT/'h3_factors_discovery_results.json'),plan_sha256=site.manifest['plan_sha256'],epoch=site.epoch(),chosen_coop_variant=coop,chosen_short_variant=short,chosen=[dict(pair=x['pair'],ID=x['ID'],variant=x['variant'],category=category(x),delta_pct=x['delta_pct'],high_cv=x['high_cv'],route_compare=x.get('route_compare',False),depth_compare=x.get('depth_compare',False),precision_keys=x['keys'][:2]) for x in chosen])
 path=ROOT/'h3_factors_profile_plan.json'
 if path.exists():assert r.read(path)==result
 else:r.write(path,result)
 return rule,result,bykey

def kernel_identity(case):
 ident=case['expected'];m=case['M'];rows=1 if m<=16 else 2 if m<=32 else 4
 if ident in [6020,6021,6022,6023]:
  k,d={6020:(16,4),6021:(16,8),6022:(32,4),6023:(32,5)}[ident]
  return 'DecodeNnCooperativeKernel',f'DecodeNnCooperativeKernel<{rows},{k},{d}>'
 if 6013<=ident<=6018:
  mode=ident-6013;depth=4 if mode>=3 else 8;early=mode%3>=1;xor=mode%3!=1
 else:return 'GroupedGemmV7UniformKernel',None
 return 'DecodeNnSharedTunedKernel',f'DecodeNnSharedTunedKernel<{rows},16,{depth},{str(early).lower()},{str(xor).lower()}>'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['capture']);ap.parse_args();r.no_core();site=r.Site(ROOT)
 rule,selection,results=select(site);self_sha=plan.sha(__file__);rule_sha=selection['rule_sha256'];results_sha=selection['discovery_sha256']
 configs={x['key']:x for x in r.read(ROOT/'h3_factors_discovery_plan.json')['discovery_pairs']}
 captures=r.read(ROOT/'h3_factors_profiles.json',[]);attempts=r.read(ROOT/'h3_factors_profile_attempts.json',[])
 with r.locked():
  for chosen in selection['chosen']:
   row=results[chosen['pair']];assert row['epoch']==site.epoch()
   old=[x for x in captures if x['pair']==row['pair']]
   if old:
    assert len(old)==2 and {x['role'] for x in old}=={'base','candidate'} and len({x['active_CU_index'] for x in old})==1
    assert all(x['epoch']==site.epoch() and x['benchmark_sha256']==site.manifest['benchmark_sha256'] for x in old)
    continue
   for cu in rule['target_cu_order']:
    pair_entries=[];sparse=False
    for role in ['base','candidate']:
     assert plan.sha(__file__)==self_sha and plan.sha(ROOT/'h3_factors_profile_selection_rule.json')==rule_sha and plan.sha(ROOT/'h3_factors_discovery_results.json')==results_sha
     case=configs[row['pair']][role];label=role+'_'+row['variant'];key=f'h3f_id{row["ID"]}_{label}_cu{cu}_{uuid.uuid4().hex[:8]}'
     folder=ROOT/'profiles_h3_factors'/key;folder.mkdir(parents=True,exist_ok=False)
     spec=c.ck(case,'perf',key);app=[a.replace('--samples=30','--samples=1').replace('--validate=1','--validate=0') for a in spec['command']]
     kernel,expected=kernel_identity(case)
     cmd=[str(c.XPROF),'--enable-sqtt','--enable-raw','--target-se','0','--target-cu',str(cu),'--dispatches',str(rule['dispatch']),'--kernels',kernel,'--sections',rule['sections'],'--output-dir',str(folder),*app]
     spec.update(kind='profile',command=cmd,variant=label,purpose='h3_factors_profile',sqtt=True,capture_timing_is_formal=False,prior_accuracy_keys=chosen['precision_keys'],capture_script_sha256=self_sha,profile_rule_sha256=rule_sha)
     rec=site.execute(spec);inventory=trace.trace_inventory(folder)
     log=Path(rec['path'],'run.log').read_text();dispatches=[int(x) for x in re.findall(r'== dispatch kernel \[(\d+)\]',log)]
     assert dispatches==[rule['dispatch']],'Dispatch mismatch; no sparse retry'
     txt=(folder/'results.txt').read_text();name=re.search(r'kernel-name\((.*?)\), start_ts',txt)[1];normal=re.sub(r'\s+','',name)
     assert expected is None or expected in normal,('Identity mismatch; no retry',expected,name)
     assert 'dispatch[18], gpu-id(4)' in txt
     valid=inventory['raw_token_bytes']>=rule['minimum_raw_token_bytes']
     attempts.append(dict(pair=row['pair'],role=role,CU_index=cu,job_key=rec['key'],raw_token_bytes=inventory['raw_token_bytes'],accepted_token_gate=valid,inventory=inventory,actual_kernel=name))
     r.write(ROOT/'h3_factors_profile_attempts.json',attempts)
     entry=dict(ID=row['ID'],pair=row['pair'],role=role,arm=label,variant=row['variant'],route_compare=row.get('route_compare',False),depth_compare=row.get('depth_compare',False),shape=row['shape'],dtype='BF16',layout='NN',stage='sqtt',epoch=rec['epoch'],physical_gpu=4,key=rec['key'],actual_instance=case['expected'],algorithm_id=None,kernel_filter=kernel,actual_kernel=name,expected_kernel=expected,dispatches=dispatches,selected_dispatch=18,XCD=0,SE=0,active_CU_index=cu,sqtt=True,raw_log=str(Path(rec['path'])/'run.log'),benchmark_sha256=site.manifest['benchmark_sha256'],binary_sha256=rec['binary_sha256'],collection_command=cmd,environment=rec['environment'],prior_accuracy_keys=chosen['precision_keys'],plan_sha256=rec['plan_sha256'],source_sha256=site.manifest['worktree_source_sha256'],script_sha256=rec['script_sha256'],formal_timing=False,point_base_ms=row['base_ms'],point_candidate_ms=row['candidate_ms'],point_delta_pct=row['delta_pct'],**inventory)
     pair_entries.append(entry)
     if not valid:
      sparse=True;print('H3_FACTORS_SPARSE_ATTEMPT_RETAINED',row['pair'],role,cu,inventory['raw_token_bytes'],flush=True);break
    if not sparse:
     assert len(pair_entries)==2;captures+=pair_entries;r.write(ROOT/'h3_factors_profiles.json',captures)
     print('H3_FACTORS_PROFILE_PAIR_PASS',row['pair'],'CUindex',cu,flush=True);break
   else:raise RuntimeError('Three predeclared CU choices exhausted; retain traces and stop')
 assert len(captures)==2*len(selection['chosen'])
 print('H3_FACTORS_PAIRED_SQTT_PASS',len(captures),flush=True)

if __name__=='__main__':main()
