"""P6l diagnostic commands, pinned identities, serial GPU4 and safe resume."""
from pathlib import Path
import argparse,copy,importlib.util,json,subprocess,sys,time,uuid
import plan
import runtime as r
ROOT=Path(__file__).resolve().parent
XPROF=Path('/opt/rocm-6.3.3/bin/xprof')
NATIVE=Path('/workspace/Grouped_Geem/blaslt_tuning_tools/build/libgroupgemm_tune.so')

def freeze():
 research=r.read(ROOT/'research_plan.json');deps=plan.base.dependencies()
 for name in [NATIVE,XPROF,Path('/workspace/Grouped_Geem/blaslt_tuning_tools/groupgemm_bridge.cpp'),Path('/workspace/Grouped_Geem/blaslt_tuning_tools/tuning_common.py'),plan.ORIGINAL]:deps['sha256'][str(name)]=plan.sha(name)
 for c in research['cases']:deps['sha256'][c['native_config']]=plan.sha(c['native_config'])
 probe=r.read('/workspace/composable_kernel/docs/data/decode_depth8_replay_p6k/frozen_plan.json')['probe']
 files=['include/ck_tile/ops/gemm/grouped_gemm_selector.hpp','include/ck_tile/ops/gemm/grouped_gemm_device_args.h','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_wave.hpp','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_bvector.hpp','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_depth8.hpp','example_hcu/ck_tile/19_grouped_gemm/grouped_gemm_device_args.cpp']
 m=dict(schema=1,research_plan_sha256=research['sha256'],benchmark_sha256=plan.sha(plan.BENCH),blas_sha256=plan.sha(plan.BLAS),selector_sha256=plan.sha(plan.SELECTOR),probe=probe,dependencies=deps,runner_sha256={n:plan.sha(ROOT/n) for n in ['plan.py','runtime.py','health.py','campaign.py','native_replay.py']},worktree_source_sha256={n:plan.sha(plan.REPO/n) for n in files},cases=research['cases'])
 m['plan_sha256']=plan.digest(m);folder=ROOT/'manifests';folder.mkdir(exist_ok=True);r.write(folder/(m['plan_sha256']+'.json'),m);r.write(ROOT/'frozen_plan.json',m)
 # Header-only selector proof, no HIP process.
 check=plan.base.selector_check(dict(cases=research['cases']),ROOT/'cpu_selector')
 r.write(ROOT/'selector_diagnostic_audit.json',check);print('P6L_DIAGNOSTIC_MANIFEST_FROZEN',m['plan_sha256'],'cases',len(research['cases']),flush=True)

def records():return [json.loads(s) for s in (ROOT/'jobs.jsonl').read_text().splitlines()] if (ROOT/'jobs.jsonl').exists() else []
def ck(c,kind,key):
 return dict(ID=c['ID'],shape={z:c[z] for z in ['M','N','K','G']},logical_key=key,kind=kind,env=c['env'],expected=c['expected'],repeats=3 if kind=='accuracy' else 1,command=plan.command(c,kind),binary=str(plan.BENCH),variant='current_best',purpose='diagnostic')
def native(c,mode,key):
 return dict(ID=c['ID'],shape={z:c[z] for z in ['M','N','K','G']},logical_key=key,kind='native_perf',env={},command=[sys.executable,'-B',str(ROOT/'native_replay.py'),'--id',str(c['ID']),'--mode',mode],binary=str(NATIVE),expected_binary_sha256=plan.sha(NATIVE),variant='frozen_native',mode=mode,purpose='diagnostic')

def diagnostics(site):
 completed=r.read(ROOT/'diagnostic_completions.json',[])
 for c in site.manifest['cases']:
  old=next((x for x in completed if x['ID']==c['ID'] and x['plan_sha256']==site.manifest['plan_sha256']),None)
  if old:continue
  attempt=uuid.uuid4().hex[:12];group=[];epoch=site.epoch()
  group.append(site.execute(dict(ck(c,'accuracy',f'diag_id{c["ID"]}_{attempt}_ck_accuracy'),attempt=attempt)))
  group.append(site.execute(dict(native(c,'accuracy',f'diag_id{c["ID"]}_{attempt}_native_accuracy'),attempt=attempt)))
  for rd in range(1,4):
   for arm in (['ck','native'] if rd%2 else ['native','ck']):
    spec=ck(c,'perf',f'diag_id{c["ID"]}_{attempt}_ck_r{rd}') if arm=='ck' else native(c,'perf',f'diag_id{c["ID"]}_{attempt}_native_r{rd}')
    group.append(site.execute(dict(spec,round=rd,attempt=attempt)))
  assert all(x['ok'] and x['epoch']==epoch and x['plan_sha256']==site.manifest['plan_sha256'] for x in group)
  import statistics
  cm=[x['result']['median_ms'] for x in group if x['kind']=='perf'];nm=[x['native']['median_ms'] for x in group if x['kind']=='native_perf' and x['mode']=='perf']
  row=dict(ID=c['ID'],epoch=epoch,attempt=attempt,plan_sha256=site.manifest['plan_sha256'],binary_sha256=site.manifest['benchmark_sha256'],keys=[x['key'] for x in group],CK_ms=statistics.median(cm),Native_ms=statistics.median(nm),R_live=statistics.median(nm)/statistics.median(cm),frozen_BLAS_ms=c['frozen_BLAS_ms'],R_frozen=c['frozen_BLAS_ms']/statistics.median(cm))
  completed.append(row);r.write(ROOT/'diagnostic_completions.json',completed);print('DIAGNOSTIC_SHAPE_PASS',json.dumps(row),flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['freeze','preflight','diagnostics','recover']);args=ap.parse_args()
 if args.stage=='freeze':freeze();return
 site=r.Site(ROOT);r.no_core()
 if args.stage=='recover':
  import health;health.recover(site);return
 with r.locked():
  if args.stage=='preflight':
   site.gate('initial_preflight_'+uuid.uuid4().hex[:8]);print('P6L_PREFLIGHT_PASS',flush=True)
  elif args.stage=='diagnostics':diagnostics(site)
if __name__=='__main__':main()
