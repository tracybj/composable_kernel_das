"""Archive completed H2 factors, including the excluded sparse identity attempt."""
from pathlib import Path
import datetime,hashlib,io,json,shutil,subprocess,tarfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/composable_kernel')
DEST=REPO/'docs/data/decode_mainline_p6l/h2_factors'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 assert not DEST.exists();DEST.mkdir(parents=True)
 results=json.loads((ROOT/'tuning_discovery_analysis.json').read_text());assert results['completed_pairs']==74
 alljobs=[json.loads(x) for x in (ROOT/'jobs.jsonl').read_text().splitlines() if x]
 jobs=[x for x in alljobs if x.get('purpose','').startswith('h2t_')];assert len(jobs)==758
 assert all(x['ok'] and x['epoch']==0 for x in jobs)
 write(DEST/'jobs.json',jobs)
 qual=json.loads((ROOT/'tuning_qualification.json').read_text());assert len(qual)==155
 comps=[c for x in jobs if x['kind']=='accuracy' for c in x['comparisons']]
 summary=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),physical_gpu=4,epoch=0,jobs=len(jobs),full_output_comparisons=len(comps),full_output_elements=sum(int(x[1]) for x in comps),failed_elements=sum(int(x[2]) for x in comps),formal_pairs=74,current_qualification=80,old_plan_qualification_records=75,profiles=14,accepted_paired_sqtt=10,accepted_disable_sqtt=3,excluded_sparse_identity_sqtt=1,formal_seven_block_acceptance=False,performance_goal_complete=False)
 assert summary['failed_elements']==0;write(DEST/'audit_summary.json',summary)
 names=['tuning_hypothesis.json','tuning_discovery_plan.json','tuning_discovery_results.json','tuning_discovery_analysis.json','tuning_discovery_analysis.csv','tuning_qualification.json','tuning_profile_plan.json','tuning_profile_selection_rule.json','profile_delivery_batch4.json','heldout_protocol.json','initial_tracked.patch','initial_files_sha256.json','compile/build4/source_sha256.json','compile/build4/results.json','compile/build4/shader_preservation.json','build4_tuning_isa_audit.json','controller_history/tuning_sparse_identity_attempt1/tuning_discovery_plan.json','controller_history/tuning_sparse_identity_attempt1/frozen_plan.json','controller_history/h2_tuning_terminal/frozen_plan.json']
 for name in names:
  p=ROOT/name
  if not p.exists():raise FileNotFoundError(p)
  target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  if target.suffix=='.csv':target.write_bytes(target.read_bytes().replace(b'\r\n',b'\n'))
 for name in ['profile_analysis.json']:
  shutil.copy2(ROOT/'tuning_profile_analysis'/name,DEST/name)
 # Capture raw bytes once even if another stage later appends to a journal.
 blobs={}
 for name in ['gates.jsonl','started.jsonl','kernel_checks.jsonl','stage_commands.jsonl']:
  blobs['journals/'+name]=(ROOT/name).read_bytes()
 for rec in jobs:
  for p in Path(rec['path']).iterdir():
   if p.is_file():blobs['jobs/'+Path(rec['path']).name+'/'+p.name]=p.read_bytes()
 versions={(name,s) for x in jobs for name,s in x['script_sha256'].items()}
 for name,s in versions:
  p=ROOT/'source_versions'/(s+'_'+name);data=p.read_bytes();assert sha(data)==s;blobs['source_versions/'+p.name]=data
 for s in {x['plan_sha256'] for x in jobs}:
  p=ROOT/'manifests'/(s+'.json');blobs['manifests/'+p.name]=p.read_bytes()
 tar=DEST/'raw_jobs.tar.gz';rawmanifest=[]
 with tarfile.open(tar,'w:gz') as out:
  for name,data in sorted(blobs.items()):
   item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;out.addfile(item,io.BytesIO(data));rawmanifest.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 with tarfile.open(tar) as inp:
  assert len(inp.getmembers())==len(rawmanifest)
  for expected,member in zip(rawmanifest,inp.getmembers()):
   data=inp.extractfile(member).read();assert member.name==expected['path'] and len(data)==expected['bytes'] and sha(data)==expected['sha256']
 write(DEST/'raw_manifest.json',rawmanifest)
 # These two source files were entirely created in P6l, without a user overlay.
 for name in ['include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_shared_tuned.hpp','example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_shared_device_args.cpp']:
  data=subprocess.check_output(['git','show','a383912a73889add0f8bd93096cb95403a9f06a7:'+name],cwd=REPO)
  expected=json.loads((ROOT/'compile/build4/source_sha256.json').read_text())[name];assert sha(data)==expected
  p=DEST/'compiled_sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (DEST/'README.md').write_text('''# H2布局与提前B因素：局部收益，未整域采用

全部74对完成；GPU4、统一锁/MKFD门禁、epoch0。控制与候选来自同一build4正式benchmark/default selector，保留P6k每shape当前可启用配置；每臂先全输出三次及guard，再三轮AB/BA，warmup10/samples30/单launch/include_args_build0。全部正负结果和高CV保留，未做七block稳定性确认。

固定主线K16D8、短线K16D4，对旧控制、XOR_A、EARLY_B及组合做受控比较。主线XOR/组合GM candidate/base为0.964332/0.964208，仍有回退；EARLY单独1.024329。短线各组合GM均>1，不采用、不计入50/30。完整数据见tuning_discovery_analysis.csv/json，不能拼接逐shape最佳值。

Profiler显示XOR+提前B的LDSbankconflict/active在ID621/805/1072约.414/.407/.254，较原H2下降，但不能单独证明整体因果。短76的profile kernel反向更快而正式三轮更慢，保留差别，不能用profiler代替正式计时。下一轮将验证新的协作B/三组操作数结构及同GPU代码的host入口对照；本归档不含其成绩。

最初DISABLE身份探针G3/27CTA只采384字节，实际kernel符合但按4096门槛停止，未做性能；旧75条完成资格记录及原始作业保留。仅三条身份探针G改32后重新冻结并完整重跑80资格，再74对；未修改C++/二进制/门槛，非MKFD。三个有效DISABLE身份SQTT各>700KiB，旧稀疏perf仍在现场，不用于指令分析。

第四批下载包见profile_delivery_batch4.json，含10份成对SQTT及3份有效DISABLE身份trace、XCompute的kernel/dispatch/Source位置和全部依赖。未在本机运行Windows GUI。原1574+H1/H2新增48 shader机器码全部保留，27个新gfx936 tuned kernel无scratch/spill。源码本地实验提交a383912；初始用户overlay保持，原始1193/冻结BLAS/旧Excel不改，无1193全量复测。

raw_jobs.tar.gz包含758个原始作业（含稀疏捕获）、门禁/进程/命令日志、相应冻结manifest与脚本版本；raw_manifest.json逐成员核对SHA。perf、二进制及厂商ISA不入Git。compiled_sources保留本批两份完全自有源码的实际编译字节；source_sha256记录其余实际构建输入，initial_tracked.patch保留用户overlay。
''',encoding='utf-8')
 manifest=[dict(path=str(p.relative_to(DEST)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(DEST.rglob('*')) if p.is_file()]
 write(DEST/'manifest.json',manifest);print('H2_FACTORS_ARCHIVE_PASS',len(jobs),len(rawmanifest),len(manifest));print(summary)
if __name__=='__main__':main()
