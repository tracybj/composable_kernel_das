"""Derive bounded facts from all captured counters; timings are diagnostic only."""
from pathlib import Path
import csv,hashlib,json,math,re,struct,sys
import runtime as r
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p4a')
from perfdump import dispatches,zblocks

def geometry(path):
 data=Path(path).read_bytes();zs=zblocks(data);assert zs and zs[0][2][:4]==b'\x7fELF'
 pos=zs[0][0]+zs[0][1];end=zs[-1][0];out=[]
 while pos+32<=end:
  kind,off,size,_=struct.unpack_from('<4Q',data,pos)
  if not size or size>end-pos:pos+=8;continue
  if kind==9:
   body=data[pos+32:pos+size];assert len(body)>=80
   gx,gy,gz,bx,by,bz,lds,scratch,vgpr,sgpr=struct.unpack_from('<10I',body,40)
   assert bx*by*bz and gx*gy*gz%(bx*by*bz)==0
   out.append(dict(grid_work_items=[gx,gy,gz],block_threads=[bx,by,bz],ctas=gx*gy*gz//(bx*by*bz),lds_bytes=lds,scratch_bytes=scratch,vgpr=vgpr,sgpr=sgpr))
  pos+=size
 return out

def ratio(a,b):return a/b if b else None

def derive(c,g,shape):
 out=dict(geometry=g,gui_cycles=c.get('GRBM_GUI_ACTIVE'),waves=c.get('SQ_WAVES'))
 waves=c.get('SQ_WAVES',0);gui=c.get('GRBM_GUI_ACTIVE',0)
 out.update(waves_per_cta=ratio(waves,g['ctas']),mean_wave_cycles=ratio(c.get('SQ_WAVE_CYCLES',0),waves),wait_any_over_wave_cycles=ratio(c.get('SQ_WAIT_INST_ANY',0),c.get('SQ_WAVE_CYCLES',0)),lds_bank_conflict_over_lds_active=ratio(c.get('SQ_LDS_BANK_CONFLICT',0),c.get('SQ_LDS_IDX_ACTIVE',0)),mean_resident_waves_per_CU=ratio(c.get('SQ_LEVEL_WAVES_accum',0),gui*80),mmop_active_over_80CU_4SIMD_cycles=ratio(c.get('SQ_ACTIVE_INST_MMOP',0),gui*80*4))
 for key in ['SQ_INSTS_SALU','SQ_INSTS_SMEM','SQ_INSTS_VALU','SQ_INSTS_VMEM','SQ_INSTS_LDS','SQ_INSTS_BRANCH','SQ_INSTS_MMOP']:
  if key in c:out[key.lower()]=c[key];out[key.lower()+'_per_wave']=ratio(c[key],waves)
 if all(k in c for k in ['TCC_EA_RDREQ_32B_sum','TCC_EA_RDREQ_sum']):out['hbm_read_bytes']=32*c['TCC_EA_RDREQ_32B_sum']+64*(c['TCC_EA_RDREQ_sum']-c['TCC_EA_RDREQ_32B_sum'])
 if all(k in c for k in ['TCC_EA_WRREQ_sum','TCC_EA_WRREQ_64B_sum']):out['hbm_write_bytes']=32*(c['TCC_EA_WRREQ_sum']-c['TCC_EA_WRREQ_64B_sum'])+64*c['TCC_EA_WRREQ_64B_sum']
 if all(k in c for k in ['TCC_HIT_sum','TCC_MISS_sum']):out['l2_hit_fraction']=ratio(c['TCC_HIT_sum'],c['TCC_HIT_sum']+c['TCC_MISS_sum'])
 m,n,k,batch=(shape[z] for z in ['M','N','K','G'])
 # gfx936 16x16x16 BF16 MMAC is one wave instruction = 8192 FLOPs.
 out['useful_flops']=2*m*n*k*batch
 if c.get('SQ_INSTS_MMOP'):out['useful_over_executed_mmac_flops']=out['useful_flops']/(c['SQ_INSTS_MMOP']*8192)
 out['minimum_input_bytes']=2*batch*(m*k+k*n)
 if 'hbm_read_bytes' in out:out['hbm_read_over_one_copy_inputs']=out['hbm_read_bytes']/out['minimum_input_bytes']
 return out

def main():
 captures=r.read(ROOT/'profiles.json',[]);rows=[];raw=[]
 for x in captures:
  perf=next(f for f in x['files'] if f['path'].endswith('.perf'))
  assert hashlib.sha256(Path(perf['path']).read_bytes()).hexdigest()==perf['sha256']
  counters=dispatches(perf['path']);geometries=geometry(perf['path']);assert len(counters)==len(geometries)==len(x['dispatches'])
  log=Path(x['raw_log']).read_text();spans=[(int(a),int(b)) for a,b in re.findall(r'== dispatch kernel \[(\d+)\].*?execution\((\d+) ns\)',log)]
  assert [a for a,b in spans]==x['dispatches']
  if x['sqtt']:
   textfile=next(f for f in x['files'] if f['path'].endswith('/results.txt'))
   text=Path(textfile['path']).read_text();m=re.search(r'grd\((\d+), (\d+), (\d+)\), wgr\((\d+), (\d+), (\d+)\), lds\((\d+)\), scr\((\d+)\), vgpr\((\d+)\), sgpr\((\d+)\)',text);assert m
   g=geometries[0];assert list(map(int,m.groups()))==g['grid_work_items']+g['block_threads']+[g[k] for k in ['lds_bytes','scratch_bytes','vgpr','sgpr']]
   assert re.search(r'dispatch\['+str(x['selected_dispatch'])+r'\], gpu-id\(4\)',text)
  raw.append(dict(ID=x['ID'],arm=x['arm'],stage=x['stage'],source=perf['path'],dispatches=counters))
  metrics=derive(counters[-1],geometries[-1],x['shape'])
  rows.append(dict(ID=x['ID'],arm=x['arm'],stage=x['stage'],selected_dispatch=x['selected_dispatch'],shape=x['shape'],epoch=x['epoch'],source=perf['path'],sqtt=x['sqtt'],raw_token_bytes=x['raw_token_bytes'],aql_last_dispatch_ns=spans[-1][1],aql_is_formal_performance=False,**metrics))
 r.write(ROOT/'raw_profile_counters.json',raw)
 r.write(ROOT/'profile_analysis.json',dict(at=r.stamp(),layout='Locally inferred HYGPERF type9 metadata, crosschecked against SQTT results.txt when present; not an official interchange parser.',counter_caveats='PMC replay changes cache state; HBM counter traffic is whole-dispatch, not proof that B alone is duplicated. Wave counters aggregate overlapping waves and cannot be summed into kernel wall time. No assumed SCLK used.',rows=rows))
 print('PROFILE_ANALYSIS_PASS',len(rows),flush=True)
 for x in rows:print('PROFILE',x['ID'],x['arm'],x['stage'],'CTA',x['geometry']['ctas'],'vgpr',x['geometry']['vgpr'],'LDS',x['geometry']['lds_bytes'],'MMAC_eff',round(x.get('useful_over_executed_mmac_flops',0),4),'HBM_MB',round(x.get('hbm_read_bytes',0)/1e6,3),'wait_fraction',round(x.get('wait_any_over_wave_cycles',0),3))

if __name__=='__main__':main()
