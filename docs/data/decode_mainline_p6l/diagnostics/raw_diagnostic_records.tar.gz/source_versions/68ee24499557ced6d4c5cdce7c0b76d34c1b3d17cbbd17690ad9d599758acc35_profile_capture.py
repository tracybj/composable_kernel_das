"""Small paired CK/Native counter discovery and exact-dispatch SQTT capture."""
from pathlib import Path
import argparse,csv,hashlib,json,re,sys,uuid
import plan,runtime as r,campaign as c
ROOT=Path(__file__).resolve().parent
SECTIONS='speed_of_light,memory_workload,occupancy,memory_chart,instruction_statistics,compute_workload,scheduler_statistics,wave_state'
def trace_inventory(folder):
 files=[];raw=0
 for p in sorted(folder.rglob('*')):
  if not p.is_file():continue
  item=dict(path=str(p),bytes=p.stat().st_size,sha256=plan.sha(p))
  if p.suffix=='.out':
   lines=p.read_text().splitlines();assert lines and all(re.fullmatch('[0-9a-fA-F]{4}',s) for s in lines),p
   item['raw_token_bytes']=2*len(lines);raw+=2*len(lines)
  files.append(item)
 assert len([x for x in files if x['path'].endswith('.perf')])==1
 return dict(files=files,raw_token_bytes=raw)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['discover','sqtt']);args=ap.parse_args()
 site=r.Site(ROOT);r.no_core();research=r.read(ROOT/'research_plan.json');complete=r.read(ROOT/'diagnostic_completions.json',[])
 assert len(complete)==16 and all(x['binary_sha256']==site.manifest['benchmark_sha256'] for x in complete)
 checks={x['ID']:x for x in complete};case_byid={x['ID']:x for x in research['cases']}
 p=ROOT/'profile_plan.json'
 if not p.exists():
  r.write(p,dict(research_plan_sha256=research['sha256'],shape_ids=research['profile_ids'],arms=['current_best','frozen_native'],stages=['PMC-discovery','single-exact-dispatch-SQTT'],sections=SECTIONS,shader_engine=0,active_cu_index=0,sqtt=True,capture_timing_is_formal=False,selection='Four representative IDs fixed before any GPU; last filtered warm dispatch chosen for SQTT.'))
 output=r.read(ROOT/'profiles.json',[])
 with r.locked():
  for ident in research['profile_ids']:
   case=case_byid[ident];assert checks[ident]['epoch']==site.epoch(),'Revalidate precision/diagnostic pair after epoch change'
   for arm in ['current_best','frozen_native']:
    prior=[x for x in output if x['ID']==ident and x['arm']==arm and x['stage']==args.stage and x['epoch']==site.epoch() and x['benchmark_sha256']==site.manifest['benchmark_sha256']]
    if prior:continue
    if arm=='current_best':
     spec=c.ck(case,'perf',f'profile_{args.stage}_id{ident}_ck')
     app=[a.replace('--samples=30','--samples=1').replace('--validate=1','--validate=0') for a in spec['command']]
     kernel='GroupedGemmV7UniformKernel';binary=plan.BENCH
    else:
     spec=c.native(case,'profile',f'profile_{args.stage}_id{ident}_native');app=spec['command'];kernel=case['kernel_name'];binary=c.NATIVE
    name=f'id{ident}_{arm}_{args.stage}_{uuid.uuid4().hex[:8]}'
    folder=ROOT/'profiles'/name;folder.mkdir(parents=True,exist_ok=False)
    options=[];dispatch=None
    if args.stage=='sqtt':
     discovery=next(x for x in output if x['ID']==ident and x['arm']==arm and x['stage']=='discover' and x['epoch']==site.epoch())
     dispatch=discovery['selected_dispatch']
     options=['--enable-sqtt','--enable-raw','--target-se','0','--target-cu','0','--dispatches',str(dispatch)]
    spec.update(kind='profile',logical_key=name,command=[str(c.XPROF),*options,'--kernels',kernel,'--sections',SECTIONS,'--output-dir',str(folder),*app],binary=str(binary),expected_binary_sha256=plan.sha(binary),sqtt=args.stage=='sqtt',profile_output=str(folder),capture_timing_is_formal=False,prior_accuracy_keys=checks[ident]['keys'][:2],capture_script_sha256=plan.sha(__file__))
    rec=site.execute(spec);inventory=trace_inventory(folder)
    log=(Path(rec['path'])/'run.log').read_text();dispatches=[int(x) for x in re.findall(r'== dispatch kernel \[(\d+)\]',log)]
    assert dispatches,'No filtered target kernel captured'
    if args.stage=='sqtt':assert dispatches==[dispatch] and inventory['raw_token_bytes']>=4096,'Sparse/wrong SQTT; retain attempt, do not call instruction evidence'
    row=dict(ID=ident,shape={z:case[z] for z in ['M','N','K','G']},dtype='BF16',layout='NN',physical_gpu=4,arm=arm,stage=args.stage,key=rec['key'],epoch=rec['epoch'],benchmark_sha256=site.manifest['benchmark_sha256'],binary_sha256=rec['binary_sha256'],actual_instance=case['expected'] if arm=='current_best' else None,algorithm_id=case['algorithm_id'] if arm=='frozen_native' else None,kernel_filter=kernel,dispatches=dispatches,selected_dispatch=max(dispatches),XCD=0,SE=0,active_CU_index=0,sqtt=args.stage=='sqtt',capture_timing_is_formal=False,collection_command=rec['command'],environment=rec['environment'],prior_accuracy_keys=rec['prior_accuracy_keys'],script_sha256=rec['script_sha256'],worktree_source_sha256=site.manifest['worktree_source_sha256'],plan_sha256=site.manifest['plan_sha256'],raw_log=str(Path(rec['path'])/'run.log'),**inventory)
    output.append(row);r.write(ROOT/'profiles.json',output);print('PROFILE_CAPTURE_PASS',ident,arm,args.stage,'dispatch',max(dispatches),'raw',inventory['raw_token_bytes'],flush=True)
 r.write(ROOT/'profile_manifest.json',output)
 fields=['ID','arm','stage','epoch','actual_instance','algorithm_id','selected_dispatch','sqtt','raw_token_bytes','perf_path','perf_bytes','perf_sha256']
 with (ROOT/'profile_manifest.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader()
  for x in output:
   perf=next(z for z in x['files'] if z['path'].endswith('.perf'));w.writerow({k:perf[k[5:]] if k.startswith('perf_') else x.get(k) for k in fields})
 print('PROFILE_BATCH_PASS',args.stage,len(output),flush=True)
if __name__=='__main__':main()
