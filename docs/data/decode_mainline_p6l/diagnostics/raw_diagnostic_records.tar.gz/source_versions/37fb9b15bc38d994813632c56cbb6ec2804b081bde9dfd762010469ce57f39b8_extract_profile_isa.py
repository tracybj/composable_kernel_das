"""Extract only captured code for local ISA analysis; vendor text stays outside Git."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
import runtime as r
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/v7_coverage/p4a')
sys.path.insert(0,'/workspace/v7_coverage/p6d')
from perfdump import zblocks
import elf_isa as e

def main():
 captures=r.read(ROOT/'profiles.json',[]);records=[];e.ROOT=ROOT
 for cap in captures:
  if cap['stage']!='sqtt':continue
  perf=next(x for x in cap['files'] if x['path'].endswith('.perf'))
  blocks=zblocks(Path(perf['path']).read_bytes());code=blocks[0][2];assert code[:4]==b'\x7fELF'
  sh=e.sections(code);symbols=e.symbols(code,sh);md=e.metadata(code,sh)
  text=Path(next(x for x in cap['files'] if x['path'].endswith('/results.txt'))['path']).read_text()
  kernel=re.search(r'kernel-name\((.*?)\), start_ts',text)[1]
  if cap['arm']=='frozen_native':
   selected=[n for n in symbols if n==cap['kernel_filter']]
  else:
   selected=[]
   for name in md:
    if cap['kernel_filter'] not in name:continue
    demangled=subprocess.check_output(['/opt/dtk/aillvm/bin/llvm-cxxfilt',name],text=True).strip()
    if demangled==kernel:selected.append(name)
   # XCompute may omit a leading return type, so fail visibly rather than pick another variant.
  assert len(selected)==1,dict(ID=cap['ID'],arm=cap['arm'],kernel=kernel,matched=selected)
  name=selected[0];tag=f'id{cap["ID"]}_{cap["arm"]}'
  co=ROOT/'isa'/(tag+'.co');co.parent.mkdir(exist_ok=True);co.write_bytes(code)
  item=e.dump(co,code,sh,symbols,md,name,tag);assert item['unknown_lines']==0
  item.update(ID=cap['ID'],arm=cap['arm'],epoch=cap['epoch'],dispatch=cap['selected_dispatch'],captured_kernel=kernel,perf=perf['path'],code_object_sha256=hashlib.sha256(code).hexdigest())
  lines=Path(item['assembly']).read_text().splitlines()
  item['instruction_anchors']=[dict(line=i+1,text=line.strip()) for i,line in enumerate(lines) if re.search(r'\b(s_waitcnt|s_barrier|buffer_load\w*|ds_read\w*|v_mmac\w*|v_perm_b32)\b',line)][:100]
  records.append(item)
 r.write(ROOT/'profile_isa.json',records)
 print('CAPTURED_ISA_PASS',len(records),flush=True)
 for x in records:print('ISA',x['ID'],x['arm'],'VGPR',x['metadata'].get('.vgpr_count'),'scratch',x['metadata'].get('.private_segment_fixed_size'),'barriers_static',x['opcodes'].get('s_barrier',0),'unknown',x['unknown_lines'])

if __name__=='__main__':main()
