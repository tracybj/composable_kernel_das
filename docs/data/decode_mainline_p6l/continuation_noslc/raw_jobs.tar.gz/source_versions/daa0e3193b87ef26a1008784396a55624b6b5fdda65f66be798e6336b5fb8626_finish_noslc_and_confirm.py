"""Wait for the one finite cache experiment, then use the frozen whole-policy gate."""
from pathlib import Path
import fcntl,json,os,subprocess,sys,time
import plan,runtime as r
ROOT=Path(__file__).resolve().parent;SELF=plan.sha(__file__)
def main():
 with (ROOT/'noslc_finish.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  def event(**kw):r.write(ROOT/'noslc_finish_status.json',dict(at=r.stamp(),pid=os.getpid(),controller_sha256=SELF,**kw))
  def command(name,args=()):
   assert plan.sha(__file__)==SELF and time.time()<r.read(ROOT/'session.json')['deadline_epoch']
   cmd=[sys.executable,'-B','-u',str(ROOT/name),*args];event(state='running',command=cmd)
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL);rc=child.wait();event(state='passed' if not rc else 'stopped',script=name,rc=rc)
   assert rc==0,'No automatic retry or seed redraw'
  try:
   while True:
    assert plan.sha(__file__)==SELF and time.time()<r.read(ROOT/'session.json')['deadline_epoch']
    assert not (ROOT/'user_pause.json').exists()
    state=r.read(ROOT/'noslc_controller_status.json',{})
    if state.get('state')=='complete':break
    assert state.get('state') not in ['stopped','failed'],state
    event(state='waiting_finite_cache_phase');time.sleep(10)
   command('commit_noslc_source.py');command('select_noslc_candidate.py')
   selected=r.read(ROOT/'noslc_candidate_selection.json')
   if not selected['eligible_for_confirmation']:
    event(state='complete_rejected_candidate',Goal_complete=False,new_seed_drawn=False);return
   assert time.time()+60<r.read(ROOT/'session.json')['gpu_deadline_epoch']
   command('run_final_confirmation_noslc.py',['--proposal',str(ROOT/'noslc_candidate_proposal.json')])
   event(state='confirmation_and_report_complete',Goal_complete=False,note='Actual50/30 andalltaskdeliverables stillrequireauditing.')
  except BaseException as error:
   event(state='stopped',error=str(error),error_type=type(error).__name__,automatic_retry=False);raise
if __name__=='__main__':main()
