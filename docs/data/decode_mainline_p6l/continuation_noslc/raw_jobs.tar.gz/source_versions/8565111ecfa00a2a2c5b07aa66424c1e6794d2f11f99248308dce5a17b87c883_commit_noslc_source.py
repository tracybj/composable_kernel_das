"""Commit only two owned cache-revision files after the finite GPU phase."""
from pathlib import Path
import hashlib,json,os,subprocess
import plan,runtime as r
ROOT=Path(__file__).resolve().parent;REPO=plan.REPO
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=REPO,env=env)
def main():
 assert r.read(ROOT/'noslc_controller_status.json')['state']=='complete'
 assert (ROOT/'profile_delivery_batch15.json').exists()
 assert len(r.read(ROOT/'noslc_qualification.json'))==35 and len(r.read(ROOT/'noslc_discovery_results.json'))==23
 assert r.read(ROOT/'noslc_qualification_audit.json')['ok']
 assert r.read(ROOT/'noslc_discovery_analysis.json')['complete_phase']
 assert r.read(ROOT/'noslc_build_isa_audit.json')['ok']
 pins=r.read(ROOT/'compile/build15/source_sha256.json');assert all(plan.sha(REPO/n)==h for n,h in pins.items())
 names=['example_hcu/ck_tile/19_grouped_gemm/instances/grouped_gemm_bf16_nn_decode_cooperative_device_args.cpp',
        'include/ck_tile/ops/gemm/pipeline/gemm_pipeline_decode_nn_cooperative_n128_noslc.hpp']
 initial=r.read(ROOT/'initial_files_sha256.json');assert all(n not in initial for n in names)
 user_names=[x[3:] for x in (ROOT/'initial_status.txt').read_text().splitlines() if not x.startswith('?? ') and x[3:]]
 before=git('diff','--',*user_names);assert not git('diff','--cached','--name-only').strip()
 index=ROOT/'noslc_source.index';assert not index.exists();env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
 subprocess.run(['git','read-tree','HEAD'],cwd=REPO,env=env,check=True);blobs={}
 for n in names:
  blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=REPO,input=(REPO/n).read_bytes()).decode().strip();blobs[n]=blob
  subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+n],cwd=REPO,env=env,check=True)
 assert set(git('diff','--cached','--name-only',env=env).decode().splitlines())==set(names)
 subprocess.run(['git','diff','--cached','--check'],cwd=REPO,env=env,check=True)
 subprocess.run(['git','commit','-m','P6l 6035 A加载缓存标志实现修订（实验用，不合入）'],cwd=REPO,env=env,check=True)
 for n,blob in blobs.items():
  assert git('show','HEAD:'+n)==(REPO/n).read_bytes()
  subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+n],cwd=REPO,check=True)
 assert not git('diff','--cached','--name-only').strip() and git('diff','--',*user_names)==before
 old_untracked=[x[3:] for x in (ROOT/'initial_status.txt').read_text().splitlines() if x.startswith('?? ')]
 assert len(old_untracked)==10 and all(plan.sha(REPO/n)==initial[n] for n in old_untracked)
 assert hashlib.md5(git('diff','--','include/ck_tile/ops/gemm/pipeline/gemm_pipeline_v7_uniform.hpp')).hexdigest()=='4c7f49a5c7592767d53195a713db6b8a'
 r.write(ROOT/'noslc_source_commit.json',dict(at=r.stamp(),commit=git('rev-parse','HEAD').decode().strip(),files=names,untracked10_bytes_verified=True,user_tracked_diff_bytes_unchanged=True,source26_SHA_verified=True,Git_blob_verified=True,experimental_instance_revised=6035,geometry_selector_ABI_unchanged=True,adopted=False,default_off=True,push=False))
 print('NOSLC_OWN2_SOURCE_COMMIT_PASS',flush=True)
if __name__=='__main__':main()
