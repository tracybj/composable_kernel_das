"""Apply the one preregistered property-policy gate; no GPU or seed draw."""
from pathlib import Path
import json, math, statistics
import plan, runtime as r
ROOT = Path(__file__).resolve().parent

def main():
    assert r.read(ROOT/'noslc_controller_status.json')['state']=='complete'
    assert r.read(ROOT/'noslc_source_commit.json')['untracked10_bytes_verified']
    assert (ROOT/'profile_delivery_batch15.json').is_file()
    rows=r.read(ROOT/'noslc_discovery_results.json');assert len(rows)==23
    assert r.read(ROOT/'noslc_discovery_analysis.json')['complete_phase']
    rule=r.read(ROOT/'noslc_final_selection_rule.json')
    original=r.read(ROOT/'source_results.json')
    scope=[x for x in original if 17<=x['M']<=64 and 1024<=x['N']<=4096 and x['N']%128==0
           and 2048<=x['K']<=8192 and x['K']%128==0 and 1<=x['G']<=1024]
    assert len(scope)==rule['scope_originals']==96
    assert sum(x['R_frozen']<.99 for x in scope)==rule['scope_weak']==53
    selected=[x for x in rows if not x['control']]
    assert len(selected)==16 and all(x['variant']=='noslc' and x['candidate_instance']==6035 for x in selected)
    assert {x['ID'] for x in selected}<={x['ID'] for x in scope}
    losses=[x['ID'] for x in selected if not x['high_cv'] and
            all(b['median_ms']/a['median_ms']>1.02 for a,b in zip(x['base_rounds'],x['candidate_rounds']))]
    gm=math.exp(statistics.mean(math.log(x['ratio_candidate_over_base']) for x in selected))
    viable=not losses and gm<1
    report=dict(at=r.stamp(),rule_sha256=plan.sha(ROOT/'noslc_final_selection_rule.json'),
                representatives=16,known_three_round_losses=losses,high_cv=sum(x['high_cv'] for x in selected),
                geometric_candidate_over_base=gm,eligible_for_confirmation=viable,
                scope_originals=96,scope_weak_originals=53,point_improve_ge5=sum(x['delta_pct']<=-5 for x in selected),
                not_performance_acceptance=True,new_heldout_seed_drawn=False,
                accepted_stable50=0,accepted_attributable30=0)
    r.write(ROOT/'noslc_candidate_selection.json',report)
    if viable:
        P=plan.PREFIX
        proposal=dict(mechanistic_reason='A-cache-only implementation revision of6035, N128K32D2W4/op3 same geometry/selector/ABI. Current formal A/B same fresh binary; historical6035 timing is diagnostic only. Single preregistered M17..64 property policy, all96 originals and24fresh/sevenblocks still required.',
                      evidence_results=str(ROOT/'noslc_discovery_results.json'),
                      evidence_sha256=plan.sha(ROOT/'noslc_discovery_results.json'),
                      evidence_plan=str(ROOT/'noslc_discovery_plan.json'),
                      evidence_plan_sha256=plan.sha(ROOT/'noslc_discovery_plan.json'),
                      selection_rule=str(ROOT/'noslc_final_selection_rule.json'),
                      selection_rule_sha256=report['rule_sha256'],
                      families=dict(main=dict(candidate_ids=[6035],env={
                          P+'ENABLE_BF16_NN_DECODE_MAINLINE':'1',P+'DISABLE_BF16_NN_DECODE_MAINLINE':'0',
                          P+'BF16_NN_DECODE_MAINLINE_VARIANT':'42',P+'ENABLE_BF16_NN_DECODE_FAST_POLICY':'1',
                          P+'DISABLE_BF16_NN_DECODE_FAST_POLICY':'0'})))
        target=ROOT/'noslc_candidate_proposal.json'
        if target.exists():assert r.read(target)==proposal
        else:r.write(target,proposal)
    print('WAVE4_SINGLE_POLICY_SELECTION',json.dumps(report),flush=True)
    print('NO_GPU_OR_HELDOUT_DRAW',flush=True)

if __name__=='__main__':main()
